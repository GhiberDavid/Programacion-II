#include "Hospital.hpp"
#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

// ============ CONSTRUCTORES ============

Hospital::Hospital() {
    // Inicializar strings vac�os
    nombre[0] = '\0';
    direccion[0] = '\0';
    telefono[0] = '\0';
    
    // Fechas actuales
    time_t ahora = time(nullptr);
    fechaCreacion = ahora;
    fechaModificacion = ahora;
}

Hospital::Hospital(const char* nombre, const char* direccion, const char* telefono) {
    // Usar setters para validaci�n y copia segura
    setNombre(nombre);
    setDireccion(direccion);
    setTelefono(telefono);
    
    // Fechas actuales
    time_t ahora = time(nullptr);
    fechaCreacion = ahora;
    fechaModificacion = ahora;
}

Hospital::Hospital(const Hospital& otro) {
    // Copiar strings
    strcpy(nombre, otro.nombre);
    strcpy(direccion, otro.direccion);
    strcpy(telefono, otro.telefono);
    
    // Copiar fechas
    fechaCreacion = otro.fechaCreacion;
    fechaModificacion = otro.fechaModificacion;
}

Hospital::~Hospital() {
    // No hay recursos din�micos que liberar
}

// ============ GETTERS ============

const char* Hospital::getNombre() const {
    return nombre;
}

const char* Hospital::getDireccion() const {
    return direccion;
}

const char* Hospital::getTelefono() const {
    return telefono;
}

time_t Hospital::getFechaCreacion() const {
    return fechaCreacion;
}

time_t Hospital::getFechaModificacion() const {
    return fechaModificacion;
}

// ============ SETTERS ============

void Hospital::setNombre(const char* nombre) {
    if (nombre != nullptr) {
        strncpy(this->nombre, nombre, 99);
        this->nombre[99] = '\0';
        actualizarFechaModificacion();
    }
}

void Hospital::setDireccion(const char* direccion) {
    if (direccion != nullptr) {
        strncpy(this->direccion, direccion, 149);
        this->direccion[149] = '\0';
        actualizarFechaModificacion();
    }
}

void Hospital::setTelefono(const char* telefono) {
    if (telefono != nullptr) {
        strncpy(this->telefono, telefono, 14);
        this->telefono[14] = '\0';
        actualizarFechaModificacion();
    }
}

// ============ M�TODOS DE ACTUALIZACI�N ============

void Hospital::actualizarFechaModificacion() {
    fechaModificacion = time(nullptr);
}

// ============ M�TODOS DE PRESENTACI�N ============

void Hospital::mostrarInformacion() const {
    cout << "\n=== INFORMACI�N DEL HOSPITAL ===" << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Direcci�n: " << direccion << endl;
    cout << "Tel�fono: " << telefono << endl;
    
    // Formatear fechas
    char fechaCreacionStr[50];
    char fechaModificacionStr[50];
    
    strftime(fechaCreacionStr, sizeof(fechaCreacionStr), 
             "%d/%m/%Y %H:%M:%S", localtime(&fechaCreacion));
    strftime(fechaModificacionStr, sizeof(fechaModificacionStr), 
             "%d/%m/%Y %H:%M:%S", localtime(&fechaModificacion));
    
    cout << "Fecha de creaci�n: " << fechaCreacionStr << endl;
    cout << "�ltima modificaci�n: " << fechaModificacionStr << endl;
}

// ============ M�TODOS DE VALIDACI�N ============

bool Hospital::validarDatos() const {
    if (strlen(nombre) == 0) {
        cerr << "Error: Nombre del hospital vac�o" << endl;
        return false;
    }
    
    if (strlen(direccion) == 0) {
        cerr << "Error: Direcci�n vac�a" << endl;
        return false;
    }
    
    if (strlen(telefono) == 0) {
        cerr << "Error: Tel�fono vac�o" << endl;
        return false;
    }
    
    return true;
}

bool Hospital::tieneDatosBasicos() const {
    return (strlen(nombre) > 0 && strlen(direccion) > 0 && strlen(telefono) > 0);
}

// ============ M�TODO EST�TICO ============

size_t Hospital::obtenerTamano() {
    return sizeof(Hospital);
}
