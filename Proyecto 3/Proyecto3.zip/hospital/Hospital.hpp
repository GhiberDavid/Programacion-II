#ifndef HOSPITAL_HPP
#define HOSPITAL_HPP

#include <cstring>
#include <ctime>

class Hospital {
private:
    // Solo informaci�n b�sica - SIN CONTADORES
    char nombre[100];
    char direccion[150];
    char telefono[15];
    
    // Metadata - SIN ESTAD�STICAS
    time_t fechaCreacion;
    time_t fechaModificacion;

public:
    // ============ CONSTRUCTORES ============
    Hospital(); // Constructor por defecto
    Hospital(const char* nombre, const char* direccion, const char* telefono);
    Hospital(const Hospital& otro); // Constructor de copia
    ~Hospital(); // Destructor
    
    // ============ GETTERS ============
    const char* getNombre() const;
    const char* getDireccion() const;
    const char* getTelefono() const;
    
    time_t getFechaCreacion() const;
    time_t getFechaModificacion() const;
    
    // ============ SETTERS ============
    void setNombre(const char* nombre);
    void setDireccion(const char* direccion);
    void setTelefono(const char* telefono);
    
    // ============ M�TODOS DE ACTUALIZACI�N ============
    void actualizarFechaModificacion();
    
    // ============ M�TODOS DE PRESENTACI�N ============
    void mostrarInformacion() const;
    
    // ============ M�TODOS DE VALIDACI�N ============
    bool validarDatos() const;
    bool tieneDatosBasicos() const;
    
    // ============ M�TODO EST�TICO ============
    static size_t obtenerTamano();
};

#endif
