#ifndef GESTOR_ARCHIVOS_HPP
#define GESTOR_ARCHIVOS_HPP

#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include "ArchivoHeader.hpp"
#include "Constantes.hpp"
#include "../hospital/Hospital.hpp"
#include "../pacientes/Paciente.hpp"
#include "../doctores/Doctor.hpp"
#include "../citas/Cita.hpp"
#include "../historial/HistorialMedico.hpp"

class GestorArchivos {
private:
    // M�todo auxiliar privado
    static size_t calcularPosicion(int indice, size_t tamanoRegistro);
    
public:
    // ============ OPERACIONES DE HEADER ============
    static ArchivoHeader leerHeader(const char* archivo);
    static bool escribirHeader(const char* archivo, const ArchivoHeader& header);
    static bool actualizarContador(const char* archivo, const char* campo, int valor);
    
    // ============ OPERACIONES GEN�RICAS DE REGISTROS ============
    // Funcionan para CUALQUIER tipo (Paciente, Doctor, Cita, etc.)
    
    static bool guardarRegistro(void* registro, size_t tamano, const char* archivo);
    static bool leerRegistroPorIndice(int indice, void* registro, size_t tamano, const char* archivo);
    static bool leerRegistroPorID(int id, void* registro, size_t tamano, const char* archivo);
    static bool actualizarRegistro(void* registro, size_t tamano, const char* archivo, int indice);
    static bool eliminarRegistro(int id, size_t tamano, const char* archivo);
    static void* listarTodosRegistros(int* cantidad, size_t tamano, const char* archivo);
    
    // ============ M�TODOS AUXILIARES ============
    static int contarRegistros(const char* archivo);
    static int contarRegistrosActivos(const char* archivo, size_t tamano);
    static bool compactarArchivo(const char* archivo, size_t tamano);
    static bool inicializarArchivo(const char* archivo);
    static bool verificarIntegridadArchivos();
    
    // ============ M�TODOS DE CONVENIENCIA ESPEC�FICOS ============
    // Para hacer m�s f�cil el uso desde otras partes del c�digo
    static bool inicializarSistemaArchivos();
    static int obtenerProximoID(const char* archivo);
    static bool existeRegistro(int id, const char* archivo, size_t tamano);
    
    // ============ M�TODOS PARA LIBERAR MEMORIA ============
    static void liberarArrayRegistros(void* array);
    
    
    
    
    
	// Para Pacientes
    static Paciente buscarPacientePorCedula(const char* cedula);   
    static Paciente* buscarPacientesPorNombre(const char* nombreBuscado, int* cantidadResultados);	 
	static Paciente buscarPacientePorID(int id);
	static int buscarIndicePacientePorID(int id);
	
	// Para Doctores  
    static Doctor buscarDoctorPorCedula(const char* cedula);
    static Doctor* buscarDoctoresPorNombre(const char* nombreBuscado, int* cantidadResultados); 
    static Doctor* buscarDoctoresPorEspecialidad(const char* especialidadBuscada, int* cantidadResultados);	   
	static Doctor buscarDoctorPorID(int id);
	static int buscarIndiceDoctorPorID(int id);
	
	// Para Citas
	static Cita buscarCitaPorID(int id);
	static int buscarIndiceCitaPorID(int id);
	
	// Para Historial
	static HistorialMedico buscarHistorialPorID(int id);
	static int buscarIndiceHistorialPorID(int id);  
	
    static bool actualizarPaciente(const Paciente& pacienteModificado);
    static bool actualizarDoctor(const Doctor& doctorModificado);
    static bool actualizarCita(const Cita& citaModificada);
    static bool actualizarHistorial(const HistorialMedico& historialModificado);
    
    static Paciente* leerTodosPacientesActivos(int* cantidadActivos);
    static Doctor* leerTodosDoctoresActivos(int* cantidadActivos);
    static Cita* leerTodasCitasActivas(int* cantidadActivas);
    static HistorialMedico* leerTodosHistorialesActivos(int* cantidadActivos);
	
	static bool agregarPaciente(Paciente& nuevoPaciente);
	static bool agregarDoctor(Doctor& nuevoDoctor);
	static bool agregarCita(Cita& nuevaCita);
	static bool agregarHistorial(HistorialMedico& nuevoHistorial);	
	static Cita* buscarCitasPorEstado(const char* estado, int* cantidadResultados);
	static Cita* buscarCitasPorPaciente(int idPaciente, int* cantidadResultados);
	static Cita* buscarCitasPorDoctor(int idDoctor, int* cantidadResultados);
	static Cita* buscarCitasPorFecha(const char* fecha, int* cantidadResultados);
	static bool verificarDisponibilidadDoctor(int idDoctor, const char* fecha, const char* hora);
	static bool atenderCita(int idCita, const char* diagnostico, const char* tratamiento, const char* medicamentos);
	
	static bool eliminarPaciente(int id);
	static bool eliminarDoctor(int id);
	static bool eliminarCita(int id);
	static bool eliminarHistorial(int id);
	
	static bool cargarHospital(Hospital& hospital);
	static bool guardarHospital(const Hospital& hospital);

	static void obtenerEstadisticasSistema(int* totalPacientes, int* totalDoctores, 
	                                      int* totalCitas, int* totalHistoriales);
	static int obtenerProximoIDPaciente();
	static int obtenerProximoIDDoctor();
	static int obtenerProximoIDCita();
	static int obtenerProximoIDHistorial();	
		
	  
    
    
    
    
};

#endif
