#ifndef ARCHIVO_HEADER_HPP
#define ARCHIVO_HEADER_HPP

struct ArchivoHeader {
    int cantidadRegistros;
    int proximoID;
    int registrosActivos;
    int version;
    
    ArchivoHeader() {
        cantidadRegistros = 0;
        proximoID = 1;
        registrosActivos = 0;
        version = 1;
    }
};

#endif
