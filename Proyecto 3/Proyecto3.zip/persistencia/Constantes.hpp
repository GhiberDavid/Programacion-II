#ifndef CONSTANTES_HPP
#define CONSTANTES_HPP

namespace Rutas {
    const char* const HOSPITAL = "datos/hospital.bin";
    const char* const PACIENTES = "datos/pacientes.bin";
    const char* const DOCTORES = "datos/doctores.bin";
    const char* const CITAS = "datos/citas.bin";
    const char* const HISTORIALES = "datos/historiales.bin";
    
    const int VERSION_ARCHIVO = 1;
    const int MAX_REGISTROS = 1000;
    const int TAMANO_BUFFER = 256;
    const int REGISTRO_ACTIVO = 1;
    const int REGISTRO_ELIMINADO = 0;
}

#endif
