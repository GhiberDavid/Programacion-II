#include "GestorArchivos.hpp"
#include "../utilidades/Formatos.hpp"
#include <sys/stat.h>

using namespace std;

// ============ M�TODO AUXILIAR PRIVADO ============

size_t GestorArchivos::calcularPosicion(int indice, size_t tamanoRegistro) {
    return sizeof(ArchivoHeader) + (indice * tamanoRegistro);
}

// ============ OPERACIONES DE HEADER ============

ArchivoHeader GestorArchivos::leerHeader(const char* archivo) {
    ArchivoHeader header;
    
    ifstream file(archivo, ios::binary);
    if (file) {
        file.read(reinterpret_cast<char*>(&header), sizeof(ArchivoHeader));
    }
    
    return header;
}

bool GestorArchivos::escribirHeader(const char* archivo, const ArchivoHeader& header) {
    fstream file(archivo, ios::binary | ios::in | ios::out);
    
    if (!file) {
        return false;
    }
    
    file.seekp(0);
    file.write(reinterpret_cast<const char*>(&header), sizeof(ArchivoHeader));
    file.close();
    
    return file.good();
}

bool GestorArchivos::actualizarContador(const char* archivo, const char* campo, int valor) {
    ArchivoHeader header = leerHeader(archivo);
    
    if (strcmp(campo, "cantidadRegistros") == 0) {
        header.cantidadRegistros = valor;
    } else if (strcmp(campo, "proximoID") == 0) {
        header.proximoID = valor;
    } else if (strcmp(campo, "registrosActivos") == 0) {
        header.registrosActivos = valor;
    } else if (strcmp(campo, "version") == 0) {
        header.version = valor;
    } else {
        return false; // Campo no v�lido
    }
    
    return escribirHeader(archivo, header);
}

// ============ OPERACIONES GEN�RICAS DE REGISTROS ============

bool GestorArchivos::guardarRegistro(void* registro, size_t tamano, const char* archivo) {
    // Abrir archivo en modo append
    ofstream file(archivo, ios::binary | ios::app);
    if (!file) {
        return false;
    }
    
    // Leer header actual
    ArchivoHeader header = leerHeader(archivo);
    
    // Asignar el pr�ximo ID al registro
    // Esto funciona si el primer campo del struct/clase es 'int id'
    int* idPtr = reinterpret_cast<int*>(registro);
    int idOriginal = *idPtr;  // Guardar el ID original (por si acaso)
    *idPtr = header.proximoID;  // Asignar el nuevo ID
    
    // Escribir registro al final
    file.write(reinterpret_cast<const char*>(registro), tamano);
    file.close();
    
    if (!file.good()) {
        *idPtr = idOriginal;  // Restaurar ID si fall�
        return false;
    }
    
    // Actualizar header
    header.cantidadRegistros++;
    header.registrosActivos++;
    header.proximoID++;  // �INCREMENTAR para el pr�ximo registro!
    
    // Guardar header actualizado
    return escribirHeader(archivo, header);
}

bool GestorArchivos::leerRegistroPorIndice(int indice, void* registro, 
                                           size_t tamano, const char* archivo) {
    ifstream file(archivo, ios::binary);
    if (!file) {
        return false;
    }
    
    // Calcular posici�n
    size_t posicion = calcularPosicion(indice, tamano);
    
    // Verificar que la posici�n sea v�lida
    ArchivoHeader header = leerHeader(archivo);
    if (indice < 0 || indice >= header.cantidadRegistros) {
        return false;
    }
    
    // Moverse a la posici�n y leer
    file.seekg(posicion);
    file.read(reinterpret_cast<char*>(registro), tamano);
    file.close();
    
    return file.good();
}

bool GestorArchivos::leerRegistroPorID(int id, void* registro, 
                                       size_t tamano, const char* archivo) {
    ifstream file(archivo, ios::binary);
    if (!file) {
        return false;
    }
    
    ArchivoHeader header = leerHeader(archivo);
    
    // Buscar secuencialmente por ID
    for (int i = 0; i < header.cantidadRegistros; i++) {
        size_t posicion = calcularPosicion(i, tamano);
        file.seekg(posicion);
        
        // Leer solo el ID primero para verificar
        int idLeido;
        file.read(reinterpret_cast<char*>(&idLeido), sizeof(int));
        
        if (idLeido == id) {
            // Volver al inicio del registro y leerlo completo
            file.seekg(posicion);
            file.read(reinterpret_cast<char*>(registro), tamano);
            file.close();
            return true;
        }
    }
    
    file.close();
    return false;
}

bool GestorArchivos::actualizarRegistro(void* registro, size_t tamano, 
                                        const char* archivo, int indice) {
    fstream file(archivo, ios::binary | ios::in | ios::out);
    if (!file) {
        return false;
    }
    
    // Calcular posici�n
    size_t posicion = calcularPosicion(indice, tamano);
    
    // Verificar que la posici�n sea v�lida
    ArchivoHeader header = leerHeader(archivo);
    if (indice < 0 || indice >= header.cantidadRegistros) {
        file.close();
        return false;
    }
    
    // Moverse a la posici�n y sobrescribir
    file.seekp(posicion);
    file.write(reinterpret_cast<const char*>(registro), tamano);
    file.close();
    
    return file.good();
}

bool GestorArchivos::eliminarRegistro(int id, size_t tamano, const char* archivo) {
    fstream file(archivo, ios::binary | ios::in | ios::out);
    if (!file) {
        return false;
    }
    
    ArchivoHeader header = leerHeader(archivo);
    
    // Buscar registro por ID
    for (int i = 0; i < header.cantidadRegistros; i++) {
        size_t posicion = calcularPosicion(i, tamano);
        file.seekg(posicion);
        
        // Leer solo el ID
        int idLeido;
        file.read(reinterpret_cast<char*>(&idLeido), sizeof(int));
        
        if (idLeido == id) {
            // Marcar como eliminado (poner ID negativo)
            file.seekp(posicion);
            int idNegativo = -id;
            file.write(reinterpret_cast<const char*>(&idNegativo), sizeof(int));
            
            // Actualizar header
            header.registrosActivos--;
            escribirHeader(archivo, header);
            
            file.close();
            return true;
        }
    }
    
    file.close();
    return false;
}

void* GestorArchivos::listarTodosRegistros(int* cantidad, size_t tamano, const char* archivo) {
    *cantidad = 0;
    
    ifstream file(archivo, ios::binary);
    if (!file) {
        return nullptr;
    }
    
    ArchivoHeader header = leerHeader(archivo);
    
    // Array temporal para todos los registros activos
    char* array = new char[header.registrosActivos * tamano];
    int index = 0;
    
    // Leer todos los registros
    for (int i = 0; i < header.cantidadRegistros; i++) {
        size_t posicion = calcularPosicion(i, tamano);
        file.seekg(posicion);
        
        // Leer registro temporal
        char* buffer = new char[tamano];
        file.read(buffer, tamano);
        
        // VERIFICACI�N ESPEC�FICA SEG�N EL TIPO DE ARCHIVO
        bool esActivo = false;
        
        if (strcmp(archivo, Rutas::DOCTORES) == 0) {
            // Para Doctor: verificar id > 0 y campo eliminado
            Doctor* doctor = reinterpret_cast<Doctor*>(buffer);
            if (doctor->getId() > 0 && !doctor->getEliminado() && doctor->getActivo()) {
                esActivo = true;
            }
        }
        else if (strcmp(archivo, Rutas::PACIENTES) == 0) {
            // Para Paciente: verificar id > 0 y campo eliminado
            Paciente* paciente = reinterpret_cast<Paciente*>(buffer);
            if (paciente->getId() > 0 && !paciente->getEliminado() && paciente->getActivo()) {
                esActivo = true;
            }
        }
        else if (strcmp(archivo, Rutas::CITAS) == 0) {
            // Para Cita: verificar id > 0 y campo eliminada
            Cita* cita = reinterpret_cast<Cita*>(buffer);
            if (cita->getId() > 0 && !cita->getEliminada()) {
                esActivo = true;
            }
        }
        else if (strcmp(archivo, Rutas::HISTORIALES) == 0) {
            // Para Historial: verificar id > 0 y campo eliminado
            HistorialMedico* historial = reinterpret_cast<HistorialMedico*>(buffer);
            if (historial->getId() > 0 && !historial->getEliminado()) {
                esActivo = true;
            }
        }
        else {
            // Para otros tipos, solo verificar ID positivo
            int* idPtr = reinterpret_cast<int*>(buffer);
            if (*idPtr > 0) {
                esActivo = true;
            }
        }
        
        if (esActivo) {
            memcpy(&array[index * tamano], buffer, tamano);
            index++;
        }
        
        delete[] buffer;
    }
    
    file.close();
    
    // Verificar que encontramos la cantidad correcta
    if (index != header.registrosActivos) {
        // Posible inconsistencia en el header
        // Podemos actualizar el header si queremos
        // header.registrosActivos = index;
        // escribirHeader(archivo, header);
    }
    
    *cantidad = index;
    
    // Si no hay registros activos, liberar memoria y retornar nullptr
    if (index == 0) {
        delete[] array;
        return nullptr;
    }
    
    return array;
}

// ============ M�TODOS AUXILIARES ============

int GestorArchivos::contarRegistros(const char* archivo) {
    ArchivoHeader header = leerHeader(archivo);
    return header.cantidadRegistros;
}

int GestorArchivos::contarRegistrosActivos(const char* archivo, size_t tamano) {
    ifstream file(archivo, ios::binary);
    if (!file) {
        return 0;
    }
    
    ArchivoHeader header = leerHeader(archivo);
    int activos = 0;
    
    // Contar registros con ID positivo
    for (int i = 0; i < header.cantidadRegistros; i++) {
        size_t posicion = calcularPosicion(i, tamano);
        file.seekg(posicion);
        
        int id;
        file.read(reinterpret_cast<char*>(&id), sizeof(int));
        
        if (id > 0) {
            activos++;
        }
    }
    
    file.close();
    return activos;
}

bool GestorArchivos::compactarArchivo(const char* archivo, size_t tamano) {
    // Crear archivo temporal
    string tempFile = string(archivo) + ".tmp";
    ofstream temp(tempFile, ios::binary);
    
    if (!temp) {
        return false;
    }
    
    // Obtener todos los registros activos
    int cantidad;
    void* registros = listarTodosRegistros(&cantidad, tamano, archivo);
    
    if (!registros) {
        return false;
    }
    
    // Crear nuevo header
    ArchivoHeader nuevoHeader;
    nuevoHeader.cantidadRegistros = cantidad;
    nuevoHeader.registrosActivos = cantidad;
    nuevoHeader.proximoID = obtenerProximoID(archivo);
    nuevoHeader.version = Rutas::VERSION_ARCHIVO;
    
    // Escribir nuevo header
    temp.write(reinterpret_cast<const char*>(&nuevoHeader), sizeof(ArchivoHeader));
    
    // Escribir todos los registros activos
    char* registrosChar = reinterpret_cast<char*>(registros);
    for (int i = 0; i < cantidad; i++) {
        temp.write(&registrosChar[i * tamano], tamano);
    }
    
    temp.close();
    
    // Liberar memoria
    liberarArrayRegistros(registros);
    
    // Reemplazar archivo original
    remove(archivo);
    rename(tempFile.c_str(), archivo);
    
    return true;
}

bool GestorArchivos::inicializarArchivo(const char* archivo) {
    ofstream file(archivo, ios::binary);
    if (!file) {
        return false;
    }
    
    // Escribir header por defecto
    ArchivoHeader header;
    file.write(reinterpret_cast<const char*>(&header), sizeof(ArchivoHeader));
    file.close();
    
    return file.good();
}

bool GestorArchivos::verificarIntegridadArchivos() {
    cout << "\n=== VERIFICACI�N DE INTEGRIDAD ===" << endl;
    
    const char* archivos[] = {
        Rutas::PACIENTES,
        Rutas::DOCTORES,
        Rutas::CITAS,
        Rutas::HISTORIALES,
        nullptr
    };
    
    bool todoOk = true;
    
    for (int i = 0; archivos[i] != nullptr; i++) {
        const char* archivo = archivos[i];
        
        ifstream file(archivo, ios::binary);
        if (!file) {
            cout << "? " << archivo << " - No existe" << endl;
            todoOk = false;
            continue;
        }
        
        // Verificar que se pueda leer el header
        ArchivoHeader header;
        if (file.read(reinterpret_cast<char*>(&header), sizeof(ArchivoHeader))) {
            if (header.cantidadRegistros >= 0 && 
                header.registrosActivos >= 0 && 
                header.registrosActivos <= header.cantidadRegistros) {
                cout << "? " << archivo << " - OK" << endl;
            } else {
                cout << "? " << archivo << " - Header inconsistente" << endl;
                todoOk = false;
            }
        } else {
            cout << "? " << archivo << " - No se pudo leer header" << endl;
            todoOk = false;
        }
        
        file.close();
    }
    
    return todoOk;
}

// ============ M�TODOS DE CONVENIENCIA ============

bool GestorArchivos::inicializarSistemaArchivos() {
    cout << "Inicializando sistema de archivos..." << endl;
    
    // Crear directorio datos si no existe
    #ifdef _WIN32
        system("mkdir datos 2>nul");
    #else
        system("mkdir -p datos 2>/dev/null");
    #endif
    
    // Inicializar cada archivo
    const char* archivos[] = {
        Rutas::HOSPITAL,
        Rutas::PACIENTES,
        Rutas::DOCTORES,
        Rutas::CITAS,
        Rutas::HISTORIALES,
        nullptr
    };
    
    bool todoOk = true;
    
    for (int i = 0; archivos[i] != nullptr; i++) {
        const char* archivo = archivos[i];
        
        ifstream test(archivo, ios::binary);
        if (!test) {
            cout << "Creando: " << archivo << endl;
            if (!inicializarArchivo(archivo)) {
                cerr << "  Error al crear: " << archivo << endl;
                todoOk = false;
            }
        }
        test.close();
    }
    
    return todoOk;
}

int GestorArchivos::obtenerProximoID(const char* archivo) {
    ArchivoHeader header = leerHeader(archivo);
    return header.proximoID;
}

bool GestorArchivos::existeRegistro(int id, const char* archivo, size_t tamano) {
    ifstream file(archivo, ios::binary);
    if (!file) {
        return false;
    }
    
    ArchivoHeader header = leerHeader(archivo);
    
    for (int i = 0; i < header.cantidadRegistros; i++) {
        size_t posicion = calcularPosicion(i, tamano);
        file.seekg(posicion);
        
        int idLeido;
        file.read(reinterpret_cast<char*>(&idLeido), sizeof(int));
        
        if (idLeido == id) {
            file.close();
            return true;
        }
    }
    
    file.close();
    return false;
}

// ============ M�TODOS PARA LIBERAR MEMORIA ============

void GestorArchivos::liberarArrayRegistros(void* array) {
    if (array) {
        delete[] reinterpret_cast<char*>(array);
    }
}




// ============ FUNCIONES PARA PACIENTES ============

Paciente GestorArchivos::buscarPacientePorCedula(const char* cedula) {
    Paciente vacio;
    vacio.setId(-1); // Usando setter
    
    if (cedula == nullptr || strlen(cedula) == 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::PACIENTES, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    }
    
    // 1. Leer header
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    // 2. Saltar header
    archivo.seekg(sizeof(ArchivoHeader));
    
    // 3. Buscar en todos los pacientes
    Paciente temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Paciente));
        
        // Usar getters en lugar de acceso directo
        if (!temp.getEliminado() && temp.getActivo()) {
            // Comparar c�dulas usando getter
            if (strcmp(temp.getCedula(), cedula) == 0) {
                archivo.close();
                return temp; // Encontrado
            }
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}


  

Paciente* GestorArchivos::buscarPacientesPorNombre(const char* nombreBuscado, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (nombreBuscado == nullptr || strlen(nombreBuscado) == 0) {
        return nullptr;
    }
    
    // Obtener todos los pacientes
    int cantidadTotal;
    void* registrosRaw = listarTodosRegistros(&cantidadTotal, sizeof(Paciente), Rutas::PACIENTES);
    
    if (registrosRaw == nullptr || cantidadTotal == 0) {
        return nullptr;
    }
    
    Paciente* todosPacientes = reinterpret_cast<Paciente*>(registrosRaw);
    
    // Contar coincidencias
    int contador = 0;
    for (int i = 0; i < cantidadTotal; i++) {
        char nombreCompleto[101];
        strcpy(nombreCompleto, todosPacientes[i].getNombre());
        strcat(nombreCompleto, " ");
        strcat(nombreCompleto, todosPacientes[i].getApellido());
        
        if (contieneSubstringCaseInsensitive(nombreCompleto, nombreBuscado)) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(registrosRaw);
        return nullptr;
    }
    
    // Crear array con resultados
    Paciente* resultados = new Paciente[contador];
    int index = 0;
    
    for (int i = 0; i < cantidadTotal; i++) {
        char nombreCompleto[101];
        strcpy(nombreCompleto, todosPacientes[i].getNombre());
        strcat(nombreCompleto, " ");
        strcat(nombreCompleto, todosPacientes[i].getApellido());
        
        if (contieneSubstringCaseInsensitive(nombreCompleto, nombreBuscado)) {
            resultados[index++] = todosPacientes[i];
        }
    }
    
    liberarArrayRegistros(registrosRaw);
    *cantidadResultados = contador;
    return resultados;
}


Paciente GestorArchivos::buscarPacientePorID(int id) {
    Paciente vacio;
    vacio.setId(-1); // Usando setter
    
    if (id <= 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::PACIENTES, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    }
    
    // 1. Leer header
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    // 2. Saltar header
    archivo.seekg(sizeof(ArchivoHeader));
    
    // 3. Buscar en todos los pacientes
    Paciente temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Paciente));
        
        // Usar getters
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return temp; // Encontrado
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}

int GestorArchivos::buscarIndicePacientePorID(int id) {
    if (id <= 0) {
        return -1;
    }
    
    ifstream archivo(Rutas::PACIENTES, ios::binary);
    if (!archivo.is_open()) {
        return -1;
    }
    
    // Leer header
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    // Buscar en todos los registros
    Paciente temp;
    archivo.seekg(sizeof(ArchivoHeader));
    
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Paciente));
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return i;  // Retorna el �ndice
        }
    }
    
    archivo.close();
    return -1;  // No encontrado
}

// ============ FUNCIONES PARA DOCTORES ============


Doctor GestorArchivos::buscarDoctorPorCedula(const char* cedula) {
    Doctor vacio;
    vacio.setId(-1); // Usando setter
    
    if (cedula == nullptr || strlen(cedula) == 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::DOCTORES, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    } 
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    archivo.seekg(sizeof(ArchivoHeader));
    
    Doctor temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Doctor));
        
        if (!temp.getEliminado() && temp.getActivo()) {
            if (strcmp(temp.getCedula(), cedula) == 0) {
                archivo.close();
                return temp; // Encontrado
            }
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}

Doctor* GestorArchivos::buscarDoctoresPorNombre(const char* nombreBuscado, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (nombreBuscado == nullptr || strlen(nombreBuscado) == 0) {
        return nullptr;
    }
    
    // Obtener todos los doctores
    int cantidadTotal;
    void* registrosRaw = listarTodosRegistros(&cantidadTotal, sizeof(Doctor), Rutas::DOCTORES);
    
    if (registrosRaw == nullptr || cantidadTotal == 0) {
        return nullptr;
    }
    
    Doctor* todosDoctores = reinterpret_cast<Doctor*>(registrosRaw);
    
    // Contar coincidencias
    int contador = 0;
    for (int i = 0; i < cantidadTotal; i++) {
        char nombreCompleto[101]; // nombre(50) + espacio + apellido(50) + null = 101
        strcpy(nombreCompleto, todosDoctores[i].getNombre());
        strcat(nombreCompleto, " ");
        strcat(nombreCompleto, todosDoctores[i].getApellido());
        
        if (contieneSubstringCaseInsensitive(nombreCompleto, nombreBuscado)) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(registrosRaw);
        return nullptr;
    }
    
    // Crear array con resultados
    Doctor* resultados = new Doctor[contador];
    int index = 0;
    
    for (int i = 0; i < cantidadTotal; i++) {
        char nombreCompleto[101];
        strcpy(nombreCompleto, todosDoctores[i].getNombre());
        strcat(nombreCompleto, " ");
        strcat(nombreCompleto, todosDoctores[i].getApellido());
        
        if (contieneSubstringCaseInsensitive(nombreCompleto, nombreBuscado)) {
            resultados[index++] = todosDoctores[i];
        }
    }
    
    liberarArrayRegistros(registrosRaw);
    *cantidadResultados = contador;
    return resultados;
}

Doctor* GestorArchivos::buscarDoctoresPorEspecialidad(const char* especialidadBuscada, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (especialidadBuscada == nullptr || strlen(especialidadBuscada) == 0) {
        return nullptr;
    }
    
    // Obtener todos los doctores usando m�todo existente
    int cantidad;
    void* registrosRaw = listarTodosRegistros(&cantidad, sizeof(Doctor), Rutas::DOCTORES);
    
    if (registrosRaw == nullptr || cantidad == 0) {
        return nullptr;
    }
    
    Doctor* todosDoctores = reinterpret_cast<Doctor*>(registrosRaw);
    
    // Contar cu�ntos doctores coinciden con la especialidad
    int contador = 0;
    for (int i = 0; i < cantidad; i++) {
        if (contieneSubstringCaseInsensitive(todosDoctores[i].getEspecialidad(), especialidadBuscada)) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(registrosRaw);
        return nullptr;
    }
    
    // Crear array din�mico solo con resultados
    Doctor* resultados = new Doctor[contador];
    int index = 0;
    
    for (int i = 0; i < cantidad; i++) {
        if (contieneSubstringCaseInsensitive(todosDoctores[i].getEspecialidad(), especialidadBuscada)) {
            resultados[index++] = todosDoctores[i];
        }
    }
    
    // Liberar memoria del array temporal
    liberarArrayRegistros(registrosRaw);
    *cantidadResultados = contador;
    return resultados;
}



Doctor GestorArchivos::buscarDoctorPorID(int id) {
    Doctor vacio;
    vacio.setId(-1); // Usando setter
    
    if (id <= 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::DOCTORES, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    archivo.seekg(sizeof(ArchivoHeader));
    
    Doctor temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Doctor));
        
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return temp; // Encontrado
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}

int GestorArchivos::buscarIndiceDoctorPorID(int id) {
    if (id <= 0) {
        return -1;
    }
    
    ifstream archivo(Rutas::DOCTORES, ios::binary);
    if (!archivo.is_open()) {
        return -1;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    Doctor temp;
    archivo.seekg(sizeof(ArchivoHeader));
    
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Doctor));
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return i;  // Retorna el �ndice
        }
    }
    
    archivo.close();
    return -1;  // No encontrado
}

// ============ FUNCIONES PARA CITAS ============

Cita GestorArchivos::buscarCitaPorID(int id) {
    Cita vacio;
    vacio.setId(-1); // Usando setter
    
    if (id <= 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::CITAS, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    archivo.seekg(sizeof(ArchivoHeader));
    
    Cita temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Cita));
        
        if (temp.getId() == id && !temp.getEliminada()) {
            archivo.close();
            return temp; // Encontrado
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}

int GestorArchivos::buscarIndiceCitaPorID(int id) {
    if (id <= 0) {
        return -1;
    }
    
    ifstream archivo(Rutas::CITAS, ios::binary);
    if (!archivo.is_open()) {
        return -1;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    Cita temp;
    archivo.seekg(sizeof(ArchivoHeader));
    
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(Cita));
        if (temp.getId() == id && !temp.getEliminada()) {
            archivo.close();
            return i;  // Retorna el �ndice
        }
    }
    
    archivo.close();
    return -1;  // No encontrado
}

// ============ FUNCIONES PARA HISTORIAL ============

HistorialMedico GestorArchivos::buscarHistorialPorID(int id) {
    HistorialMedico vacio;
    vacio.setId(-1); // Usando setter
    
    if (id <= 0) {
        return vacio;
    }
    
    ifstream archivo(Rutas::HISTORIALES, ios::binary);
    if (!archivo.is_open()) {
        return vacio;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    archivo.seekg(sizeof(ArchivoHeader));
    
    HistorialMedico temp;
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(HistorialMedico));
        
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return temp; // Encontrado
        }
    }
    
    archivo.close();
    return vacio; // No encontrado
}

int GestorArchivos::buscarIndiceHistorialPorID(int id) {
    if (id <= 0) {
        return -1;
    }
    
    ifstream archivo(Rutas::HISTORIALES, ios::binary);
    if (!archivo.is_open()) {
        return -1;
    }
    
    ArchivoHeader header;
    archivo.read((char*)&header, sizeof(ArchivoHeader));
    
    HistorialMedico temp;
    archivo.seekg(sizeof(ArchivoHeader));
    
    for (int i = 0; i < header.cantidadRegistros; i++) {
        archivo.read((char*)&temp, sizeof(HistorialMedico));
        if (temp.getId() == id && !temp.getEliminado()) {
            archivo.close();
            return i;  // Retorna el �ndice
        }
    }
    
    archivo.close();
    return -1;  // No encontrado
}


bool GestorArchivos::actualizarPaciente(const Paciente& pacienteModificado) {
    int indice = buscarIndicePacientePorID(pacienteModificado.getId());
    if (indice == -1) return false;
    
    Paciente pacienteActualizado = pacienteModificado;
    return actualizarRegistro(
        (void*)&pacienteActualizado,
        sizeof(Paciente),
        Rutas::PACIENTES,
        indice
    );
}

bool GestorArchivos::actualizarDoctor(const Doctor& doctorModificado) {
    int indice = buscarIndiceDoctorPorID(doctorModificado.getId());
    if (indice == -1) return false;
    
    Doctor doctorActualizado = doctorModificado;
    return actualizarRegistro(
        (void*)&doctorActualizado,
        sizeof(Doctor),
        Rutas::DOCTORES,
        indice
    );
}

bool GestorArchivos::actualizarCita(const Cita& citaModificada) {
    int indice = buscarIndiceCitaPorID(citaModificada.getId());
    if (indice == -1) return false;
    
    Cita citaActualizada = citaModificada;
    return actualizarRegistro(
        (void*)&citaActualizada,
        sizeof(Cita),
        Rutas::CITAS,
        indice
    );
}

bool GestorArchivos::actualizarHistorial(const HistorialMedico& historialModificado) {
    int indice = buscarIndiceHistorialPorID(historialModificado.getId());
    if (indice == -1) return false;
    
    HistorialMedico historialActualizado = historialModificado;
    return actualizarRegistro(
        (void*)&historialActualizado,
        sizeof(HistorialMedico),
        Rutas::HISTORIALES,
        indice
    );
}


Paciente* GestorArchivos::leerTodosPacientesActivos(int* cantidadActivos) {
    if (cantidadActivos) *cantidadActivos = 0;
    
    int cantidad;
    void* registrosRaw = listarTodosRegistros(&cantidad, sizeof(Paciente), Rutas::PACIENTES);
    
    if (registrosRaw == nullptr || cantidad == 0) {
        return nullptr;
    }
    
    Paciente* pacientesActivos = reinterpret_cast<Paciente*>(registrosRaw);
    
    if (cantidadActivos) {
        *cantidadActivos = cantidad;
    }
    
    return pacientesActivos;
}

Doctor* GestorArchivos::leerTodosDoctoresActivos(int* cantidadActivos) {
    if (cantidadActivos) *cantidadActivos = 0;
    
    int cantidad;
    void* registrosRaw = listarTodosRegistros(&cantidad, sizeof(Doctor), Rutas::DOCTORES);
    
    if (registrosRaw == nullptr || cantidad == 0) {
        return nullptr;
    }
    
    Doctor* doctoresActivos = reinterpret_cast<Doctor*>(registrosRaw);
    
    if (cantidadActivos) {
        *cantidadActivos = cantidad;
    }
    
    return doctoresActivos;
}

Cita* GestorArchivos::leerTodasCitasActivas(int* cantidadActivas) {
    if (cantidadActivas) *cantidadActivas = 0;
    
    int cantidad;
    void* registrosRaw = listarTodosRegistros(&cantidad, sizeof(Cita), Rutas::CITAS);
    
    if (registrosRaw == nullptr || cantidad == 0) {
        return nullptr;
    }
    
    Cita* citasActivas = reinterpret_cast<Cita*>(registrosRaw);
    
    if (cantidadActivas) {
        *cantidadActivas = cantidad;
    }
    
    return citasActivas;
}

HistorialMedico* GestorArchivos::leerTodosHistorialesActivos(int* cantidadActivos) {
    if (cantidadActivos) *cantidadActivos = 0;
    
    int cantidad;
    void* registrosRaw = listarTodosRegistros(&cantidad, sizeof(HistorialMedico), Rutas::HISTORIALES);
    
    if (registrosRaw == nullptr || cantidad == 0) {
        return nullptr;
    }
    
    HistorialMedico* historialesActivos = reinterpret_cast<HistorialMedico*>(registrosRaw);
    
    if (cantidadActivos) {
        *cantidadActivos = cantidad;
    }
    
    return historialesActivos;
}


bool GestorArchivos::agregarPaciente(Paciente& nuevoPaciente) {
    // Obtener pr�ximo ID
    ArchivoHeader header = leerHeader(Rutas::PACIENTES);
    
    // Configurar datos del paciente usando setters
    nuevoPaciente.setId(header.proximoID);
    nuevoPaciente.setActivo(true);
    nuevoPaciente.setEliminado(false);
    nuevoPaciente.setCantidadConsultas(0);
    nuevoPaciente.setPrimerConsultaID(-1);
    nuevoPaciente.setCantidadCitas(0);
    
    // Inicializar array de citas
    nuevoPaciente.limpiarCitas();
    
    // Timestamps se configuran autom�ticamente en el constructor
    // Los setters ya actualizan fechaModificacion
    
    // Usar m�todo gen�rico guardarRegistro
    bool resultado = guardarRegistro(
        (void*)&nuevoPaciente,
        sizeof(Paciente),
        Rutas::PACIENTES
    );
    
    if (resultado) {
        // Actualizar contadores del hospital
        // (si tienes una funci�n para esto)
        return true;
    }
    
    return false;
}

bool GestorArchivos::agregarDoctor(Doctor& nuevoDoctor) {
    ArchivoHeader header = leerHeader(Rutas::DOCTORES);
    
    // Configurar datos del doctor
    nuevoDoctor.setId(header.proximoID);
    nuevoDoctor.setActivo(true);
    nuevoDoctor.setEliminado(false);
    nuevoDoctor.setCantidadPacientes(0);
    nuevoDoctor.setCantidadCitas(0);
    nuevoDoctor.setDisponible(true);
    
    // Inicializar arrays
    nuevoDoctor.limpiarPacientes();
    nuevoDoctor.limpiarCitas();
    
    // Usar m�todo gen�rico
    bool resultado = guardarRegistro(
        (void*)&nuevoDoctor,
        sizeof(Doctor),
        Rutas::DOCTORES
    );
    
    return resultado;
}

bool GestorArchivos::agregarCita(Cita& nuevaCita) {
    ArchivoHeader header = leerHeader(Rutas::CITAS);
    
    // Configurar datos de la cita
    nuevaCita.setId(header.proximoID);
    nuevaCita.setAtendida(false);
    nuevaCita.setEliminada(false);
    nuevaCita.setIdHistorialAsociado(-1);
    
    // Asegurar estado por defecto
    if (strlen(nuevaCita.getEstado()) == 0) {
        nuevaCita.setEstado("Agendada");
    }
    
    // Usar m�todo gen�rico
    bool resultado = guardarRegistro(
        (void*)&nuevaCita,
        sizeof(Cita),
        Rutas::CITAS
    );
    
    return resultado;
}

bool GestorArchivos::agregarHistorial(HistorialMedico& nuevoHistorial) {
    ArchivoHeader header = leerHeader(Rutas::HISTORIALES);
    
    // Configurar datos del historial
    nuevoHistorial.setId(header.proximoID);
    nuevoHistorial.setEliminado(false);
    
    // Verificar ID de consulta
    if (nuevoHistorial.getIdConsulta() <= 0) {
        nuevoHistorial.setIdConsulta(-1);
    }
    
    // Usar m�todo gen�rico
    bool resultado = guardarRegistro(
        (void*)&nuevoHistorial,
        sizeof(HistorialMedico),
        Rutas::HISTORIALES
    );
    
    return resultado;
}

bool GestorArchivos::eliminarPaciente(int id) {
    Paciente paciente = buscarPacientePorID(id);
    if (paciente.getId() == -1) return false;
    if (paciente.getEliminado()) return false;
    
    paciente.setEliminado(true);
    paciente.setActivo(false);
    
    return actualizarPaciente(paciente);
}

bool GestorArchivos::eliminarDoctor(int id) {
    Doctor doctor = buscarDoctorPorID(id);
    if (doctor.getId() == -1) return false;
    if (doctor.getEliminado()) return false;
    if (doctor.getCantidadPacientes() > 0) return false;
    
    doctor.setEliminado(true);
    doctor.setActivo(false);
    doctor.setDisponible(false);
    
    return actualizarDoctor(doctor);
}

bool GestorArchivos::eliminarCita(int id) {
    Cita cita = buscarCitaPorID(id);
    if (cita.getId() == -1) return false;
    if (cita.getEliminada()) return false;
    
    cita.setEliminada(true);
    cita.setEstado("Cancelada");
    
    return actualizarCita(cita);
}

bool GestorArchivos::eliminarHistorial(int id) {
    HistorialMedico historial = buscarHistorialPorID(id);
    if (historial.getId() == -1) return false;
    if (historial.getEliminado()) return false;
    
    historial.setEliminado(true);
    
    return actualizarHistorial(historial);
}


Cita* GestorArchivos::buscarCitasPorEstado(const char* estado, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (estado == nullptr || strlen(estado) == 0) {
        return nullptr;
    }
    
    // Leer todas las citas activas usando m�todo existente
    int totalCitas = 0;
    Cita* todasCitas = leerTodasCitasActivas(&totalCitas);
    
    if (todasCitas == nullptr || totalCitas == 0) {
        return nullptr;
    }
    
    // Contar cu�ntas citas tienen el estado buscado
    int contador = 0;
    for (int i = 0; i < totalCitas; i++) {
        if (strcmp(todasCitas[i].getEstado(), estado) == 0) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(todasCitas);
        return nullptr;
    }
    
    // Crear array con las citas del estado buscado
    Cita* resultados = new Cita[contador];
    int index = 0;
    
    for (int i = 0; i < totalCitas; i++) {
        if (strcmp(todasCitas[i].getEstado(), estado) == 0) {
            resultados[index++] = todasCitas[i];
        }
    }
    
    liberarArrayRegistros(todasCitas);
    *cantidadResultados = contador;
    return resultados;
}

Cita* GestorArchivos::buscarCitasPorPaciente(int idPaciente, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (idPaciente <= 0) {
        return nullptr;
    }
    
    // Leer todas las citas activas
    int totalCitas = 0;
    Cita* todasCitas = leerTodasCitasActivas(&totalCitas);
    
    if (todasCitas == nullptr || totalCitas == 0) {
        return nullptr;
    }
    
    // Contar cu�ntas citas tiene el paciente
    int contador = 0;
    for (int i = 0; i < totalCitas; i++) {
        if (todasCitas[i].getIdPaciente() == idPaciente) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(todasCitas);
        return nullptr;
    }
    
    // Crear array con las citas del paciente
    Cita* resultados = new Cita[contador];
    int index = 0;
    
    for (int i = 0; i < totalCitas; i++) {
        if (todasCitas[i].getIdPaciente() == idPaciente) {
            resultados[index++] = todasCitas[i];
        }
    }
    
    liberarArrayRegistros(todasCitas);
    *cantidadResultados = contador;
    return resultados;
}

Cita* GestorArchivos::buscarCitasPorDoctor(int idDoctor, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (idDoctor <= 0) {
        return nullptr;
    }
    
    // Leer todas las citas activas
    int totalCitas = 0;
    Cita* todasCitas = leerTodasCitasActivas(&totalCitas);
    
    if (todasCitas == nullptr || totalCitas == 0) {
        return nullptr;
    }
    
    // Contar cu�ntas citas tiene el doctor
    int contador = 0;
    for (int i = 0; i < totalCitas; i++) {
        if (todasCitas[i].getIdDoctor() == idDoctor) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(todasCitas);
        return nullptr;
    }
    
    // Crear array con las citas del doctor
    Cita* resultados = new Cita[contador];
    int index = 0;
    
    for (int i = 0; i < totalCitas; i++) {
        if (todasCitas[i].getIdDoctor() == idDoctor) {
            resultados[index++] = todasCitas[i];
        }
    }
    
    liberarArrayRegistros(todasCitas);
    *cantidadResultados = contador;
    return resultados;
}

Cita* GestorArchivos::buscarCitasPorFecha(const char* fecha, int* cantidadResultados) {
    *cantidadResultados = 0;
    
    if (fecha == nullptr || strlen(fecha) == 0) {
        return nullptr;
    }
    
    // Leer todas las citas activas
    int totalCitas = 0;
    Cita* todasCitas = leerTodasCitasActivas(&totalCitas);
    
    if (todasCitas == nullptr || totalCitas == 0) {
        return nullptr;
    }
    
    // Contar cu�ntas citas hay en esa fecha
    int contador = 0;
    for (int i = 0; i < totalCitas; i++) {
        if (strcmp(todasCitas[i].getFecha(), fecha) == 0) {
            contador++;
        }
    }
    
    if (contador == 0) {
        liberarArrayRegistros(todasCitas);
        return nullptr;
    }
    
    // Crear array con las citas de esa fecha
    Cita* resultados = new Cita[contador];
    int index = 0;
    
    for (int i = 0; i < totalCitas; i++) {
        if (strcmp(todasCitas[i].getFecha(), fecha) == 0) {
            resultados[index++] = todasCitas[i];
        }
    }
    
    liberarArrayRegistros(todasCitas);
    *cantidadResultados = contador;
    return resultados;
}

bool GestorArchivos::verificarDisponibilidadDoctor(int idDoctor, const char* fecha, const char* hora) {
    // Verificar si el doctor existe y est� activo
    Doctor doctor = buscarDoctorPorID(idDoctor);
    if (doctor.getId() == -1 || !doctor.getActivo() || doctor.getEliminado()) {
        return false; // Doctor no existe o no est� activo
    }
    
    if (!doctor.getDisponible()) {
        return false; // Doctor no est� disponible en general
    }
    
    // Buscar citas agendadas del doctor
    int cantidadCitas = 0;
    Cita* citasDoctor = buscarCitasPorDoctor(idDoctor, &cantidadCitas);
    
    if (citasDoctor == nullptr || cantidadCitas == 0) {
        return true; // No tiene citas, est� disponible
    }
    
    // Verificar conflicto de horario
    bool disponible = true;
    for (int i = 0; i < cantidadCitas && disponible; i++) {
        Cita cita = citasDoctor[i];
        
        // Solo verificar citas "Agendadas" (no canceladas ni atendidas)
        if (strcmp(cita.getEstado(), "Agendada") == 0) {
            if (strcmp(cita.getFecha(), fecha) == 0 && 
                strcmp(cita.getHora(), hora) == 0) {
                disponible = false; // Horario ocupado
            }
        }
    }
    
    delete[] citasDoctor;
    return disponible;
}

bool GestorArchivos::atenderCita(int idCita, const char* diagnostico,
                               const char* tratamiento, const char* medicamentos) {
    
    if (diagnostico == nullptr || tratamiento == nullptr || medicamentos == nullptr) {
        return false;
    }
    
    // PASO 1: Buscar la cita por ID
    Cita cita = buscarCitaPorID(idCita);
    if (cita.getId() == -1) {
        return false;
    }
    
    // PASO 2: Verificar que est� en estado "Agendada"
    if (strcmp(cita.getEstado(), "Agendada") != 0) {
        return false; // Ya fue atendida o cancelada
    }
    
    // PASO 3: Obtener paciente y doctor
    Paciente paciente = buscarPacientePorID(cita.getIdPaciente());
    Doctor doctor = buscarDoctorPorID(cita.getIdDoctor());
    
    if (paciente.getId() == -1 || doctor.getId() == -1) {
        return false;
    }
    
    // PASO 4: Crear historial m�dico
    HistorialMedico historial;
    
    // Configurar datos del historial
    historial.setIdPaciente(cita.getIdPaciente());
    historial.setIdDoctor(cita.getIdDoctor());
    historial.setIdConsulta(idCita);
    historial.setFecha(cita.getFecha());
    historial.setHora(cita.getHora());
    historial.setDiagnostico(diagnostico);
    historial.setTratamiento(tratamiento);
    historial.setMedicamentos(medicamentos);
    historial.setCosto(doctor.getCostoConsulta());
    
    // Guardar historial
    bool historialCreado = agregarHistorial(historial);
    if (!historialCreado) {
        return false;
    }
    
    // PASO 5: Actualizar cita - marcar como atendida y vincular historial
    cita.marcarComoAtendida();
    cita.setIdHistorialAsociado(historial.getId());
    
    // Agregar observaciones con resumen del diagn�stico
    char obsTemp[200];
    snprintf(obsTemp, sizeof(obsTemp), "Atendida - Diagn�stico: %s", diagnostico);
    cita.setObservaciones(obsTemp);
    
    bool citaActualizada = actualizarCita(cita);
    if (!citaActualizada) {
        return false;
    }
    
    // PASO 6: Actualizar paciente - incrementar contador de consultas
    paciente.setCantidadConsultas(paciente.getCantidadConsultas() + 1);
    
    // Si es la primera consulta, guardar el ID
    if (paciente.getPrimerConsultaID() == -1) {
        paciente.setPrimerConsultaID(historial.getId());
    }
    
    bool pacienteActualizado = actualizarPaciente(paciente);
    if (!pacienteActualizado) {
        return false;
    }
    
    // PASO 7: Actualizar doctor (opcional - estad�sticas)
    // Puedes agregar contador de consultas atendidas al doctor
    
    return true;
}


bool GestorArchivos::cargarHospital(Hospital& hospital) {
    int cantidad;
    void* registros = listarTodosRegistros(&cantidad, sizeof(Hospital), Rutas::HOSPITAL);
    
    if (registros == nullptr || cantidad == 0) {
        return false; // No hay hospital guardado
    }
    
    Hospital* hospitales = reinterpret_cast<Hospital*>(registros);
    hospital = hospitales[0]; // Tomar el primer (y �nico) hospital
    
    liberarArrayRegistros(registros);
    return true;
}

bool GestorArchivos::guardarHospital(const Hospital& hospital) {
    // Para hospital, siempre sobrescribimos (solo hay uno)
    ofstream archivo(Rutas::HOSPITAL, ios::binary);
    if (!archivo.is_open()) {
        return false;
    }
    
    // Escribir header vac�o primero
    ArchivoHeader header;
    archivo.write(reinterpret_cast<const char*>(&header), sizeof(ArchivoHeader));
    
    // Escribir el hospital
    archivo.write(reinterpret_cast<const char*>(&hospital), sizeof(Hospital));
    archivo.close();
    
    return true;
}

void GestorArchivos::obtenerEstadisticasSistema(int* totalPacientes, int* totalDoctores,
                                               int* totalCitas, int* totalHistoriales) {
    if (totalPacientes) {
        ArchivoHeader headerPac = leerHeader(Rutas::PACIENTES);
        *totalPacientes = headerPac.registrosActivos;
    }
    
    if (totalDoctores) {
        ArchivoHeader headerDoc = leerHeader(Rutas::DOCTORES);
        *totalDoctores = headerDoc.registrosActivos;
    }
    
    if (totalCitas) {
        ArchivoHeader headerCit = leerHeader(Rutas::CITAS);
        *totalCitas = headerCit.registrosActivos;
    }
    
    if (totalHistoriales) {
        ArchivoHeader headerHist = leerHeader(Rutas::HISTORIALES);
        *totalHistoriales = headerHist.registrosActivos;
    }
}

int GestorArchivos::obtenerProximoIDPaciente() {
    ArchivoHeader header = leerHeader(Rutas::PACIENTES);
    return header.proximoID;
}

int GestorArchivos::obtenerProximoIDDoctor() {
    ArchivoHeader header = leerHeader(Rutas::DOCTORES);
    return header.proximoID;
}

int GestorArchivos::obtenerProximoIDCita() {
    ArchivoHeader header = leerHeader(Rutas::CITAS);
    return header.proximoID;
}

int GestorArchivos::obtenerProximoIDHistorial() {
    ArchivoHeader header = leerHeader(Rutas::HISTORIALES);
    return header.proximoID;
}
