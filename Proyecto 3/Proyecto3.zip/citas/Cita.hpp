#ifndef CITA_HPP
#define CITA_HPP

#include <cstring>
#include <ctime>

class Cita {
private:
    // Atributos (PRIVADOS)
    int id;
    int idPaciente;
    int idDoctor;
    char fecha[11];        // DD-MM-YYYY
    char hora[6];          // HH:MM
    char motivo[150];
    char estado[20];       // "Agendada", "Atendida", "Cancelada"
    char observaciones[200];
    bool atendida;
    
    // Metadata
    bool eliminada;
    time_t fechaCreacion;
    time_t fechaModificacion;
    int idHistorialAsociado;

public:
    // ============ CONSTRUCTORES ============
    Cita(); // Constructor por defecto
    Cita(int id, int idPaciente, int idDoctor, const char* fecha, const char* hora);
    ~Cita(); // Destructor
    
    // ============ GETTERS ============
    int getId() const;
    int getIdPaciente() const;
    int getIdDoctor() const;
    const char* getFecha() const;
    const char* getHora() const;
    const char* getMotivo() const;
    const char* getEstado() const;
    const char* getObservaciones() const;
    bool getAtendida() const;
    
    bool getEliminada() const;
    time_t getFechaCreacion() const;
    time_t getFechaModificacion() const;
    int getIdHistorialAsociado() const;
    
    // ============ SETTERS ============
    void setId(int id);
    void setIdPaciente(int idPaciente);
    void setIdDoctor(int idDoctor);
    void setFecha(const char* fecha);
    void setHora(const char* hora);
    void setMotivo(const char* motivo);
    void setEstado(const char* estado);
    void setObservaciones(const char* observaciones);
    void setAtendida(bool atendida);
    
    void setEliminada(bool eliminada);
    void setFechaCreacion(time_t fecha);
    void setFechaModificacion(time_t fecha);
    void setIdHistorialAsociado(int id);
    
    // ============ M�TODOS DE GESTI�N DE ESTADO ============
    void marcarComoAtendida();
    void marcarComoCancelada();
    void marcarComoAgendada();
    
 
    
    // ============ M�TODO EST�TICO ============
    static size_t obtenerTamano();
};

#endif
