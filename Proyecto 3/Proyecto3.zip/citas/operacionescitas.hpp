#ifndef OPERACION_CITA_HPP
#define OPERACION_CITA_HPP

#include "Cita.hpp"
#include <ctime>


void agendarCitaVisual();
void listarCitasPendientes();
void cancelarCitaVisual();
void atenderCitaVisual();
void obtenerCitasDeDoctorVisual();
void obtenerCitasPorFechaVisual();
void mostrarHistorialMedicoVisual();


#endif

