#include "Cita.hpp"
#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

// ============ CONSTRUCTORES ============

Cita::Cita() {
    // Inicializar valores por defecto
    id = -1;
    idPaciente = -1;
    idDoctor = -1;
    fecha[0] = '\0';
    hora[0] = '\0';
    motivo[0] = '\0';
    strcpy(estado, "Agendada");
    observaciones[0] = '\0';
    atendida = false;
    
    eliminada = false;
    fechaCreacion = time(nullptr);
    fechaModificacion = time(nullptr);
    idHistorialAsociado = -1;
}

Cita::Cita(int id, int idPaciente, int idDoctor, const char* fecha, const char* hora) {
    // Llamar al constructor por defecto primero
    *this = Cita();
    
    // Asignar valores principales
    this->id = id;
    this->idPaciente = idPaciente;
    this->idDoctor = idDoctor;
    setFecha(fecha);
    setHora(hora);
}

Cita::~Cita() {
    // No hay memoria din�mica que liberar
}

// ============ GETTERS ============

int Cita::getId() const {
    return id;
}

int Cita::getIdPaciente() const {
    return idPaciente;
}

int Cita::getIdDoctor() const {
    return idDoctor;
}

const char* Cita::getFecha() const {
    return fecha;
}

const char* Cita::getHora() const {
    return hora;
}

const char* Cita::getMotivo() const {
    return motivo;
}

const char* Cita::getEstado() const {
    return estado;
}

const char* Cita::getObservaciones() const {
    return observaciones;
}

bool Cita::getAtendida() const {
    return atendida;
}

bool Cita::getEliminada() const {
    return eliminada;
}

time_t Cita::getFechaCreacion() const {
    return fechaCreacion;
}

time_t Cita::getFechaModificacion() const {
    return fechaModificacion;
}

int Cita::getIdHistorialAsociado() const {
    return idHistorialAsociado;
}

// ============ SETTERS ============

void Cita::setId(int id) {
    this->id = id;
    fechaModificacion = time(nullptr);
}

void Cita::setIdPaciente(int idPaciente) {
    this->idPaciente = idPaciente;
    fechaModificacion = time(nullptr);
}

void Cita::setIdDoctor(int idDoctor) {
    this->idDoctor = idDoctor;
    fechaModificacion = time(nullptr);
}

void Cita::setFecha(const char* fecha) {
    if (fecha) {
        strncpy(this->fecha, fecha, 10);
        this->fecha[10] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Cita::setHora(const char* hora) {
    if (hora) {
        strncpy(this->hora, hora, 5);
        this->hora[5] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Cita::setMotivo(const char* motivo) {
    if (motivo) {
        strncpy(this->motivo, motivo, 149);
        this->motivo[149] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Cita::setEstado(const char* estado) {
    if (estado) {
        strncpy(this->estado, estado, 19);
        this->estado[19] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Cita::setObservaciones(const char* observaciones) {
    if (observaciones) {
        strncpy(this->observaciones, observaciones, 199);
        this->observaciones[199] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Cita::setAtendida(bool atendida) {
    this->atendida = atendida;
    fechaModificacion = time(nullptr);
}

void Cita::setEliminada(bool eliminada) {
    this->eliminada = eliminada;
    fechaModificacion = time(nullptr);
}

void Cita::setFechaCreacion(time_t fecha) {
    fechaCreacion = fecha;
}

void Cita::setFechaModificacion(time_t fecha) {
    fechaModificacion = fecha;
}

void Cita::setIdHistorialAsociado(int id) {
    idHistorialAsociado = id;
    fechaModificacion = time(nullptr);
}

// ============ M�TODOS DE GESTI�N DE ESTADO ============

void Cita::marcarComoAtendida() {
    strcpy(estado, "Atendida");
    atendida = true;
    fechaModificacion = time(nullptr);
}

void Cita::marcarComoCancelada() {
    strcpy(estado, "Cancelada");
    atendida = false;
    fechaModificacion = time(nullptr);
}

void Cita::marcarComoAgendada() {
    strcpy(estado, "Agendada");
    atendida = false;
    fechaModificacion = time(nullptr);
}



// ============ M�TODO EST�TICO ============

size_t Cita::obtenerTamano() {
    return sizeof(Cita);
}
