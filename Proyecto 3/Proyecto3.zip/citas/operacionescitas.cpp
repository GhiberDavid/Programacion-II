#include "operacionescitas.hpp"
#include "../doctores/Doctor.hpp"
#include "../pacientes/operacionesPacientes.hpp"
#include "../utilidades/Formatos.hpp"
#include <cstring>
#include <string>
#include <conio.h> 


using namespace std;  // O usar std::to_string 

void agendarCitaVisual() {
    // Verificar si hay pacientes y doctores usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalPacientes == 0 || totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "AGENDAR CITA", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes o doctores registrados!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 16);
    
    textoColor(25, 3, "AGENDAR NUEVA CITA", 14, 1);
    
    // FORMULARIO DE CAPTURA
    textoColor(10, 5, "Datos de la Cita:", 14, 1);
    textoColor(10, 6, "C�dula del Paciente: ", 15, 1);
    textoColor(10, 7, "C�dula del Doctor: ", 15, 1);
    textoColor(10, 8, "Fecha (DD-MM-YYYY): ", 15, 1);
    textoColor(10, 9, "Hora (HH:MM): ", 15, 1);
    textoColor(10, 10, "Motivo: ", 15, 1);
    
    textoColor(10, 12, "Ejemplo: 15-01-2025, 09:30", 8, 1);
    textoColor(10, 14, "Presione ESC en cualquier campo para cancelar", 14, 1);
    
    // VARIABLES PARA CAPTURA
    char cedulaPaciente[20], cedulaDoctor[20], fecha[11], hora[6], motivo[150];
    memset(cedulaPaciente, 0, sizeof(cedulaPaciente));
    memset(cedulaDoctor, 0, sizeof(cedulaDoctor));
    memset(fecha, 0, sizeof(fecha));
    memset(hora, 0, sizeof(hora));
    memset(motivo, 0, sizeof(motivo));
    
    // CAPTURAR DATOS
    string temp;
    Paciente paciente;
    Doctor doctor;
    
    // C�dula del Paciente
    do {
        temp = leerCampo(32, 6, 19);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            paciente = GestorArchivos::buscarPacientePorCedula(temp.c_str());
            // CAMBIADO: usar getters
            if (paciente.getId() != -1 && paciente.getActivo() && !paciente.getEliminado()) {
                strcpy(cedulaPaciente, temp.c_str());
                break;
            } else {
                mostrarError(10, 15, "Error: No se encontr� paciente activo con esa c�dula!");
            }
        } else {
            mostrarError(10, 15, "Error: La c�dula del paciente no puede estar vac�a!");
        }
    } while (true);
    
    // C�dula del Doctor
    do {
        temp = leerCampo(32, 7, 19);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            doctor = GestorArchivos::buscarDoctorPorCedula(temp.c_str());
            // CAMBIADO: usar getters
            if (doctor.getId() != -1 && doctor.getActivo() && !doctor.getEliminado()) {
                strcpy(cedulaDoctor, temp.c_str());
                break;
            } else {
                mostrarError(10, 15, "Error: No se encontr� doctor activo con esa c�dula!");
            }
        } else {
            mostrarError(10, 15, "Error: La c�dula del doctor no puede estar vac�a!");
        }
    } while (true);
    
    // Fecha
    do {
        temp = leerCampo(32, 8, 10);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            // CAMBIADO: usar Validaciones si existe, o crear funci�n temporal
            if (validarFecha(temp.c_str())) { // Necesitar�s implementar esta funci�n
                strcpy(fecha, temp.c_str());
                break;
            } else {
                mostrarError(10, 15, "Error: Formato de fecha inv�lido! Use DD-MM-YYYY");
            }
        } else {
            mostrarError(10, 15, "Error: La fecha no puede estar vac�a!");
        }
    } while (true);
    
    // Hora
    do {
        temp = leerCampo(32, 9, 5);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            if (validarHora(temp.c_str())) { // Necesitar�s implementar esta funci�n
                strcpy(hora, temp.c_str());
                break;
            } else {
                mostrarError(10, 15, "Error: Formato de hora inv�lido! Use HH:MM");
            }
        } else {
            mostrarError(10, 15, "Error: La hora no puede estar vac�a!");
        }
    } while (true);
    
    // Motivo
    do {
        temp = leerCampo(32, 10, 149);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            strcpy(motivo, temp.c_str());
            break;
        } else {
            mostrarError(10, 15, "Error: El motivo no puede estar vac�o!");
        }
    } while (true);
    
    // Verificar disponibilidad del doctor usando GestorArchivos
    // CAMBIADO: usar GestorArchivos
    if (!GestorArchivos::verificarDisponibilidadDoctor(doctor.getId(), fecha, hora)) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "AGENDAR CITA", 14, 1);
        textoColor(10, 5, "Error: El doctor no est� disponible en esa fecha y hora!", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 7, "Fecha: " + string(fecha) + " Hora: " + string(hora), 15, 1);
        textoColor(10, 8, "Por favor, seleccione otra fecha u horario.", 14, 1);
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // AGENDAR LA CITA usando GestorArchivos
    // Primero crear la cita
    Cita nuevaCita;
    nuevaCita.setIdPaciente(paciente.getId());
    nuevaCita.setIdDoctor(doctor.getId());
    nuevaCita.setFecha(fecha);
    nuevaCita.setHora(hora);
    nuevaCita.setMotivo(motivo);
    nuevaCita.setEstado("Agendada");
    nuevaCita.setObservaciones("");
    nuevaCita.setIdHistorialAsociado(-1);
    nuevaCita.setAtendida(false);
    nuevaCita.setEliminada(false);
    
    bool resultado = GestorArchivos::agregarCita(nuevaCita);
    
    // MOSTRAR RESULTADO
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    textoColor(25, 3, "AGENDAR CITA", 14, 1);
    
    if (resultado) {
        int idCita = nuevaCita.getId(); // O usar GestorArchivos::obtenerProximoIDCita() - 1
        textoColor(10, 5, "�Cita agendada exitosamente!", 10, 1);
        textoColor(10, 6, "ID de Cita: " + to_string(idCita), 15, 1);
        // CAMBIADO: usar getters
        textoColor(10, 7, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
        textoColor(10, 8, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 9, "Fecha: " + string(fecha) + " Hora: " + string(hora), 15, 1);
        textoColor(10, 10, "Motivo: " + string(motivo), 15, 1);
        
        // Actualizar paciente y doctor con la nueva cita
        paciente.agregarCitaID(idCita);
        doctor.agregarCitaID(idCita);
        GestorArchivos::actualizarPaciente(paciente);
        GestorArchivos::actualizarDoctor(doctor);
    } else {
        textoColor(10, 5, "Error: No se pudo agendar la cita!", 12, 1);
        textoColor(10, 6, "Posibles causas:", 14, 1);
        textoColor(10, 7, "- El paciente ya tiene demasiadas citas (l�mite: 20)", 14, 1);
        textoColor(10, 8, "- El doctor ya tiene demasiadas citas (l�mite: 30)", 14, 1);
        textoColor(10, 9, "- Error en el sistema de archivos", 14, 1);
        textoColor(10, 10, "Por favor, verifique los datos e intente nuevamente.", 14, 1);
    }
    
    textoColor(10, 11, "Presione cualquier tecla para continuar...", 14, 1);
    _getch();
}


void mostrarCitasEnTabla(Cita** citas, int cantidad, const string& titulo) {
    int startX = -6; 
    int startY = 0;
    
    // VERIFICACI�N DE SEGURIDAD
    if (citas == nullptr || cantidad <= 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ERROR", 14, 1);
        textoColor(10, 5, "Error: No hay datos para mostrar!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    system("cls");
    system("color 1F");
    
    int y = startY;
    int pagina = 0;
    const int CITAS_POR_PAGINA = 10; // 10 citas por p�gina
    
    // CALCULAR P�GINAS
    int totalPaginas = (cantidad + CITAS_POR_PAGINA - 1) / CITAS_POR_PAGINA;
    
    do {
        // LIMPIAR PANTALLA PARA NUEVA P�GINA
        system("cls");
        system("color 1F");
        y = startY;
        
        // CABECERA DE LA TABLA 
        textoColor(startX + 10, y++, ES_SU_IZ + replicar(LINEA_HO[0], 72) + ES_SU_DE, 14, 1);
        
        // T�TULO CON N�MERO DE P�GINA
        string tituloPagina = titulo;
        if (totalPaginas > 1) {
            tituloPagina += " - P�g " + to_string(pagina + 1) + "/" + to_string(totalPaginas);
        }
        textoColor(startX + 10, y, LINEA_VE + "                    " + tituloPagina, 14, 1);
        textoColor(startX + 83, y++, LINEA_VE, 14, 1);
        
        textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 19) + 
                  CRUZ_SUP + replicar(LINEA_HO[0], 19) + CRUZ_SUP + replicar(LINEA_HO[0], 12) + 
                  CRUZ_SUP + replicar(LINEA_HO[0], 7) + CRUZ_SUP + replicar(LINEA_HO[0], 6) + CRUZ_DER, 14, 1);
        
        // ENCABEZADO DE COLUMNAS 
        textoColor(startX + 12, y, "ID", 14, 1);
        textoColor(startX + 18, y, "Paciente", 14, 1);
        textoColor(startX + 38, y, "Doctor", 14, 1);
        textoColor(startX + 57, y, "Fecha", 14, 1);
        textoColor(startX + 70, y, "Hora", 14, 1);
        textoColor(startX + 77, y, "Estado", 14, 1);

        // L�neas verticales del encabezado 
        textoColor(startX + 10, y, LINEA_VE, 14, 1);
        textoColor(startX + 15, y, LINEA_VE, 14, 1);
        textoColor(startX + 35, y, LINEA_VE, 14, 1);
        textoColor(startX + 55, y, LINEA_VE, 14, 1);
        textoColor(startX + 68, y, LINEA_VE, 14, 1);
        textoColor(startX + 76, y, LINEA_VE, 14, 1);
        textoColor(startX + 83, y, LINEA_VE, 14, 1);
        y++;
        
        textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 19) + 
                  CRUZ_CEN + replicar(LINEA_HO[0], 19) + CRUZ_CEN + replicar(LINEA_HO[0], 12) + 
                  CRUZ_CEN + replicar(LINEA_HO[0], 7) + CRUZ_CEN + replicar(LINEA_HO[0], 6) + CRUZ_DER, 14, 1);
        
        // CALCULAR RANGO PARA ESTA P�GINA
        int inicio = pagina * CITAS_POR_PAGINA;
        int fin = min(inicio + CITAS_POR_PAGINA, cantidad);
        int citasMostradasEnPagina = 0;
        
        // LISTA DE CITAS PARA ESTA P�GINA
        for (int i = inicio; i < fin; i++) {
            Cita* cita = citas[i];
            
            // VERIFICAR PUNTERO NULO
            if (cita == nullptr) {
                continue;
            }
            
            // Obtener nombres del paciente y doctor usando GestorArchivos
            Paciente paciente = GestorArchivos::buscarPacientePorID(cita->getIdPaciente());
            Doctor doctor = GestorArchivos::buscarDoctorPorID(cita->getIdDoctor());
            
            string nombrePaciente = "No encontrado";
            string nombreDoctor = "No encontrado";
            
            if (paciente.getId() != -1 && paciente.getActivo() && !paciente.getEliminado()) {
                nombrePaciente = string(paciente.getNombre()) + " " + string(paciente.getApellido());
            }
            
            if (doctor.getId() != -1 && doctor.getActivo() && !doctor.getEliminado()) {
                nombreDoctor = "Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido());
            }
            
            // Acortar nombres 
            if (nombrePaciente.length() > 16) {
                nombrePaciente = nombrePaciente.substr(0, 13) + "...";
            }
            if (nombreDoctor.length() > 16) {
                nombreDoctor = nombreDoctor.substr(0, 13) + "...";
            }
            
            // ABREVIAR ESTADOS
            string estadoAbreviado;
            int colorEstado = 15; // Blanco por defecto
            
            const char* estado = cita->getEstado();
            
            if (strcmp(estado, "Agendada") == 0) {
                estadoAbreviado = "AGEN";
                colorEstado = 11; // Azul claro
            } else if (strcmp(estado, "Atendida") == 0) {
                estadoAbreviado = "ATEN";
                colorEstado = 10; // Verde
            } else if (strcmp(estado, "Cancelada") == 0) {
                estadoAbreviado = "CANC";
                colorEstado = 12; // Rojo
            } else if (strcmp(estado, "Eliminada") == 0) {
                estadoAbreviado = "ELIM";
                colorEstado = 8; // Gris
            } else {
                estadoAbreviado = estado;
            }
            
            // Alternar colores para mejor legibilidad
            int colorFila = (citasMostradasEnPagina % 2 == 0) ? 15 : 7;
            
            // L�nea lateral izquierda
            textoColor(startX + 10, y, LINEA_VE, 14, 1);
            
            // ID
            textoColor(startX + 12, y, to_string(cita->getId()), colorFila, 1);
            
            // Paciente 
            textoColor(startX + 18, y, nombrePaciente, colorFila, 1);
            
            // Doctor 
            textoColor(startX + 38, y, nombreDoctor, colorFila, 1);
            
            // Fecha
            textoColor(startX + 57, y, cita->getFecha(), colorFila, 1);
            
            // Hora
            textoColor(startX + 70, y, cita->getHora(), colorFila, 1);
            
            // Estado 
            textoColor(startX + 78, y, estadoAbreviado, colorEstado, 1);
            
            // L�neas verticales 
            textoColor(startX + 15, y, LINEA_VE, 14, 1);
            textoColor(startX + 35, y, LINEA_VE, 14, 1);
            textoColor(startX + 55, y, LINEA_VE, 14, 1);
            textoColor(startX + 68, y, LINEA_VE, 14, 1);
            textoColor(startX + 76, y, LINEA_VE, 14, 1);
            textoColor(startX + 83, y, LINEA_VE, 14, 1);
            
            y++;
            citasMostradasEnPagina++;
        }
        
        // PIE DE TABLA PARA ESTA P�GINA
        textoColor(startX + 10, y++, ES_IN_IZ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 19) + 
                  CRUZ_INF + replicar(LINEA_HO[0], 19) + CRUZ_INF + replicar(LINEA_HO[0], 12) + 
                  CRUZ_INF + replicar(LINEA_HO[0], 7) + CRUZ_INF + replicar(LINEA_HO[0], 6) + ES_IN_DE, 14, 1);
        
        // INFORMACI�N DE P�GINA
        textoColor(startX + 15, y++, "Citas " + to_string(inicio + 1) + "-" + to_string(fin) + 
                  " de " + to_string(cantidad), 14, 1);
        
        // INSTRUCCIONES DE NAVEGACI�N
        if (totalPaginas > 1) {
            textoColor(startX + 15, y++, "? Anterior [A] | Siguiente [S] | Salir [ESC]", 14, 1);
        } else {
            textoColor(startX + 15, y++, "Presione ESC para salir, cualquier tecla para continuar...", 14, 1);
        }
        
        // ESPERAR TECLA DEL USUARIO
        char tecla = _getch();
        
        if (tecla == 27 || tecla == 'q' || tecla == 'Q') { // ESC o Q
            break; // Salir
        } else if (totalPaginas > 1) {
            if ((tecla == 'a' || tecla == 'A') && pagina > 0) {
                pagina--; // P�gina anterior
            } else if ((tecla == 's' || tecla == 'S') && pagina < totalPaginas - 1) {
                pagina++; // P�gina siguiente
            } else if (tecla == 13 || tecla == 32) { // ENTER o ESPACIO
                // Avanzar autom�ticamente a la siguiente p�gina
                if (pagina < totalPaginas - 1) {
                    pagina++;
                } else {
                    break; // �ltima p�gina, salir
                }
            }
        } else {
            // Solo una p�gina, cualquier tecla para salir
            break;
        }
        
    } while (pagina < totalPaginas);
}

//---------------------------------------------
// ATENDER CITA (INTERFAZ DE USUARIO) - VERSI�N GESTORARCHIVOS
//---------------------------------------------
void atenderCitaVisual() {
    // Verificar si hay citas usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        textoColor(10, 5, "Error: No hay citas registradas en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 10);
    
    textoColor(25, 3, "ATENDER CITA", 14, 1);
    textoColor(10, 5, "Ingrese el ID de la cita a atender: ", 15, 1);
    textoColor(10, 7, "Nota: Solo se pueden atender citas en estado 'AGEN'", 14, 1);
    textoColor(10, 9, "Presione ESC para cancelar", 14, 1);
    
    // Leer ID de la cita
    string temp = leerCampoNumerico(45, 5, 5);
    
    if (temp == "ESC") {
        return; 
    }
    
    if (temp.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        textoColor(10, 5, "Error: El ID no puede estar vacio!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    int idCita = atoi(temp.c_str());
    
    // Buscar la cita usando GestorArchivos
    Cita cita = GestorArchivos::buscarCitaPorID(idCita);
    
    // CAMBIADO: usar getter getId()
    if (cita.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        textoColor(10, 5, "Error: No se encontro la cita con ID: " + to_string(idCita), 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Verificar que la cita est� en estado agendada
    // CAMBIADO: usar getter getEstado()
    if (strcmp(cita.getEstado(), "Agendada") != 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        textoColor(10, 5, "Error: La cita no esta en estado 'Agendada'!", 12, 1);
        // CAMBIADO: usar getter getId()
        textoColor(10, 6, "ID Cita: " + to_string(cita.getId()), 15, 1);
        textoColor(10, 7, "Estado actual: " + string(cita.getEstado()), 15, 1);
        textoColor(10, 8, "Solo se pueden atender citas en estado 'Agendada'", 14, 1);
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Obtener informaci�n del paciente y doctor usando GestorArchivos
    // CAMBIADO: usar getters
    Paciente paciente = GestorArchivos::buscarPacientePorID(cita.getIdPaciente());
    Doctor doctor = GestorArchivos::buscarDoctorPorID(cita.getIdDoctor());
    
    // CAMBIADO: usar getters
    if (paciente.getId() == -1 || doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        textoColor(10, 5, "Error: No se pudo encontrar paciente o doctor!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // MOSTRAR INFORMACI�N DE LA CITA
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 18);
    
    textoColor(25, 3, "REGISTRAR ATENCI�N M�DICA", 14, 1);
    textoColor(10, 5, "Informacion de la Cita:", 14, 1);
    // CAMBIADO: usar getters
    textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    textoColor(10, 7, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
    textoColor(10, 8, "Fecha: " + string(cita.getFecha()) + " Hora: " + string(cita.getHora()), 15, 1);
    textoColor(10, 9, "Motivo: " + string(cita.getMotivo()), 15, 1);
    textoColor(10, 10, "Costo de consulta: $" + to_string(doctor.getCostoConsulta()), 15, 1);
    
    textoColor(10, 12, "Datos M�dicos de la Consulta:", 14, 1);
    textoColor(10, 13, "Diagnostico: ", 15, 1);
    textoColor(10, 14, "Tratamiento: ", 15, 1);
    textoColor(10, 15, "Medicamentos: ", 15, 1);
    textoColor(10, 17, "Presione ESC en cualquier campo para cancelar", 14, 1);
    
    // CAPTURAR DATOS MEDICOS
    char diagnostico[200], tratamiento[200], medicamentos[150];
    memset(diagnostico, 0, sizeof(diagnostico));
    memset(tratamiento, 0, sizeof(tratamiento));
    memset(medicamentos, 0, sizeof(medicamentos));
    
    string tempStr;
    
    // Diagn�stico
    do {
        tempStr = leerCampo(25, 13, 49);
        if (tempStr == "ESC") return;
        
        if (!tempStr.empty()) {
            strcpy(diagnostico, tempStr.c_str());
            break;
        } else {
            mostrarError(10, 18, "Error: El diagnostico no puede estar vacio!");
        }
    } while (true);
    
    // Tratamiento
    do {
        tempStr = leerCampo(25, 14, 49);
        if (tempStr == "ESC") return;
        
        if (!tempStr.empty()) {
            strcpy(tratamiento, tempStr.c_str());
            break;
        } else {
            mostrarError(10, 18, "Error: El tratamiento no puede estar vacio!");
        }
    } while (true);
    
    // Medicamentos
    tempStr = leerCampo(25, 15, 49, "", false);
    if (tempStr == "ESC") return;
    strcpy(medicamentos, tempStr.c_str());
    
    // CONFIRMAR ATENCI�N
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    textoColor(25, 3, "CONFIRMAR ATENCI�N", 14, 1);
    textoColor(10, 5, "�Confirmar atenci�n de la cita?", 15, 1);
    textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    textoColor(10, 7, "Diagnostico: " + string(diagnostico), 15, 1);
    textoColor(10, 8, "Tratamiento: " + string(tratamiento), 15, 1);
    textoColor(10, 9, "Costo: $" + to_string(doctor.getCostoConsulta()), 15, 1);
    textoColor(10, 10, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    
    char confirmacion = _getch();
    
    if (confirmacion == 'S' || confirmacion == 's') {
        // Atender la cita usando GestorArchivos
        // CAMBIADO: usar GestorArchivos
        bool resultado = GestorArchivos::atenderCita(idCita, diagnostico, tratamiento, medicamentos);
        
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "ATENDER CITA", 14, 1);
        
        if (resultado) {
            textoColor(10, 5, "�Cita atendida exitosamente!", 10, 1);
            textoColor(10, 6, "Se ha generado el historial m�dico del paciente.", 10, 1);
            textoColor(10, 7, "Estado actualizado: ATEN", 15, 1);
        } else {
            textoColor(10, 5, "Error: No se pudo atender la cita!", 12, 1);
        }
        
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
}

//---------------------------------------------
// CANCELAR CITA (INTERFAZ DE USUARIO) - VERSI�N GESTORARCHIVOS
//---------------------------------------------
void cancelarCitaVisual() {
    // Verificar si hay citas usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        textoColor(10, 5, "Error: No hay citas registradas en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 10);
    
    textoColor(25, 3, "CANCELAR CITA", 14, 1);
    textoColor(10, 5, "Ingrese el ID de la cita a cancelar: ", 15, 1);
    textoColor(10, 7, "Nota: Solo se pueden cancelar citas en estado 'AGEN'", 14, 1);
    textoColor(10, 9, "Presione ESC para cancelar", 14, 1);
    
    // Leer ID de la cita
    string temp = leerCampoNumerico(46, 5, 5);
    
    if (temp == "ESC") {
        return; 
    }
    
    if (temp.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        textoColor(10, 5, "Error: El ID no puede estar vacio!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    int idCita = atoi(temp.c_str());
    
    // Buscar la cita usando GestorArchivos
    Cita cita = GestorArchivos::buscarCitaPorID(idCita);
    
    // CAMBIADO: usar getter getId()
    if (cita.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        textoColor(10, 5, "Error: No se encontro la cita con ID: " + to_string(idCita), 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Verificar que la cita est� en estado agendada
    // CAMBIADO: usar getter getEstado()
    if (strcmp(cita.getEstado(), "Agendada") != 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        textoColor(10, 5, "Error: La cita no esta en estado 'Agendada'!", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "ID Cita: " + to_string(cita.getId()), 15, 1);
        textoColor(10, 7, "Estado actual: " + string(cita.getEstado()), 15, 1);
        textoColor(10, 8, "Solo se pueden cancelar citas en estado 'Agendada'", 14, 1);
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Obtener informaci�n del paciente y doctor usando GestorArchivos
    // CAMBIADO: usar getters
    Paciente paciente = GestorArchivos::buscarPacientePorID(cita.getIdPaciente());
    Doctor doctor = GestorArchivos::buscarDoctorPorID(cita.getIdDoctor());
    
    // CAMBIADO: usar getters
    if (paciente.getId() == -1 || doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        textoColor(10, 5, "Error: No se pudo encontrar paciente o doctor!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // MOSTRAR INFORMACI�N DE LA CITA Y CONFIRMAR
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    
    textoColor(25, 3, "CONFIRMAR CANCELACI�N", 14, 1);
    textoColor(10, 5, "�Est� seguro que desea cancelar la siguiente cita?", 15, 1);
    // CAMBIADO: usar getters
    textoColor(10, 6, "ID Cita: " + to_string(cita.getId()), 15, 1);
    textoColor(10, 7, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    textoColor(10, 8, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
    textoColor(10, 9, "Fecha: " + string(cita.getFecha()) + " Hora: " + string(cita.getHora()), 15, 1);
    textoColor(10, 10, "Motivo: " + string(cita.getMotivo()), 15, 1);
    textoColor(10, 11, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    
    char confirmacion = _getch();
    
    if (confirmacion == 'S' || confirmacion == 's') {
        // Cancelar la cita usando GestorArchivos
        // CAMBIADO: usar GestorArchivos
        bool resultado = GestorArchivos::eliminarCita(idCita);
        
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "CANCELAR CITA", 14, 1);
        
        if (resultado) {
            textoColor(10, 5, "�Cita cancelada exitosamente!", 10, 1);
            // CAMBIADO: usar getters
            textoColor(10, 6, "ID Cita: " + to_string(cita.getId()), 15, 1);
            textoColor(10, 7, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
            textoColor(10, 8, "Estado actualizado: CANC", 15, 1);
        } else {
            textoColor(10, 5, "Error: No se pudo cancelar la cita!", 12, 1);
        }
        
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
}

//---------------------------------------------
// OBTENER CITAS DE PACIENTE (INTERFAZ DE USUARIO) - VERSI�N GESTORARCHIVOS
//---------------------------------------------
void obtenerCitasDePacienteVisual() {
    // Verificar si hay pacientes usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalPacientes == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
    textoColor(10, 5, "Ingrese la c�dula del paciente: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula del paciente
    string cedula = leerCampo(42, 5, 19);
    
    if (cedula == "ESC") {
        return; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
        textoColor(10, 5, "Error: La c�dula no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar paciente por c�dula usando GestorArchivos
    Paciente paciente = GestorArchivos::buscarPacientePorCedula(cedula.c_str());
    
    // CAMBIADO: usar getter getId()
    if (paciente.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
        textoColor(10, 5, "Error: No se encontr� paciente con c�dula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // CAMBIADO: usar getters
    if (!paciente.getActivo() || paciente.getEliminado()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
        textoColor(10, 5, "Error: El paciente est� inactivo en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Obtener todas las citas del paciente usando GestorArchivos
    int cantidadCitas = 0;
    Cita* citasPaciente = GestorArchivos::buscarCitasPorPaciente(paciente.getId(), &cantidadCitas);
    
    if (cantidadCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE PACIENTE", 14, 1);
        textoColor(10, 5, "El paciente no tiene citas registradas.", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Crear array de punteros para compatibilidad con mostrarCitasEnTabla
    Cita** citasPtr = new Cita*[cantidadCitas];
    for (int i = 0; i < cantidadCitas; i++) {
        citasPtr[i] = &citasPaciente[i];
    }
    
    // Mostrar citas en tabla
    string titulo = "CITAS DE: " + string(paciente.getNombre()) + " " + string(paciente.getApellido());
    mostrarCitasEnTabla(citasPtr, cantidadCitas, titulo);
    
    // Liberar memoria usando GestorArchivos
    GestorArchivos::liberarArrayRegistros(citasPaciente);
    delete[] citasPtr;
}

//---------------------------------------------
// OBTENER CITAS DE DOCTOR (INTERFAZ DE USUARIO) - VERSI�N GESTORARCHIVOS
//---------------------------------------------
void obtenerCitasDeDoctorVisual() {
    // Verificar si hay doctores usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No hay doctores registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "CITAS DE DOCTOR", 14, 1);
    textoColor(10, 5, "Ingrese la c�dula del doctor: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula del doctor
    string cedula = leerCampo(42, 5, 19);
    
    if (cedula == "ESC") {
        return; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE DOCTOR", 14, 1);
        textoColor(10, 5, "Error: La c�dula no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar doctor por c�dula usando GestorArchivos
    Doctor doctor = GestorArchivos::buscarDoctorPorCedula(cedula.c_str());
    
    // CAMBIADO: usar getter getId()
    if (doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No se encontr� doctor con c�dula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Obtener todas las citas del doctor usando GestorArchivos
    int cantidadCitas = 0;
    Cita* citasDoctor = GestorArchivos::buscarCitasPorDoctor(doctor.getId(), &cantidadCitas);
    
    if (cantidadCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS DE DOCTOR", 14, 1);
        textoColor(10, 5, "El doctor no tiene citas registradas.", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Crear array de punteros para compatibilidad
    Cita** citasPtr = new Cita*[cantidadCitas];
    for (int i = 0; i < cantidadCitas; i++) {
        citasPtr[i] = &citasDoctor[i];
    }
    
    // Mostrar citas en tabla
    string titulo = "CITAS DR: " + string(doctor.getNombre()) + " " + string(doctor.getApellido());
    mostrarCitasEnTabla(citasPtr, cantidadCitas, titulo);
    
    // Liberar memoria usando GestorArchivos
    GestorArchivos::liberarArrayRegistros(citasDoctor);
    delete[] citasPtr;
}

//---------------------------------------------
// OBTENER CITAS POR FECHA (INTERFAZ DE USUARIO) 
//---------------------------------------------
void obtenerCitasPorFechaVisual() {
    // Verificar si hay citas usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS POR FECHA", 14, 1);
        textoColor(10, 5, "Error: No hay citas registradas en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 10);
    
    textoColor(25, 3, "CITAS POR FECHA", 14, 1);
    textoColor(10, 5, "Ingrese la fecha (DD-MM-YYYY): ", 15, 1);
    textoColor(10, 7, "Ejemplo: 15-01-2025", 8, 1);
    textoColor(10, 9, "Presione ESC para cancelar", 14, 1);
    
    // Leer fecha
    string fecha = leerCampo(42, 5, 10);
    
    if (fecha == "ESC") {
        return; 
    }
    
    if (fecha.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS POR FECHA", 14, 1);
        textoColor(10, 5, "Error: La fecha no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Validar formato de fecha
    if (!validarFecha(fecha.c_str())) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS POR FECHA", 14, 1);
        textoColor(10, 5, "Error: Formato de fecha inv�lido! Use DD-MM-YYYY", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Obtener citas por fecha usando GestorArchivos
    int cantidadCitas = 0;
    Cita* citasFechaArray = GestorArchivos::buscarCitasPorFecha(fecha.c_str(), &cantidadCitas);
    
    if (cantidadCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS POR FECHA", 14, 1);
        textoColor(10, 5, "No hay citas registradas para la fecha: " + fecha, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Crear array de punteros para compatibilidad
    Cita** citasFecha = new Cita*[cantidadCitas];
    for (int i = 0; i < cantidadCitas; i++) {
        citasFecha[i] = &citasFechaArray[i];
    }
    
    // Mostrar citas en tabla
    string tituloTabla = "CITAS DEL " + fecha;
    mostrarCitasEnTabla(citasFecha, cantidadCitas, tituloTabla);
    
    // Liberar memoria usando GestorArchivos
    GestorArchivos::liberarArrayRegistros(citasFechaArray);
    delete[] citasFecha;
}

//---------------------------------------------
// MOSTRAR HISTORIAL M�DICO EN TABLA (VERSI�N GESTORARCHIVOS)
//---------------------------------------------
void mostrarHistorialMedicoEnTabla(const Paciente& paciente, const string& titulo) {
    
    int startX = -6; 
    int startY = 0;

    // Obtener el historial m�dico del paciente usando GestorArchivos
    int cantidadConsultas = 0;
    HistorialMedico* historialPaciente = GestorArchivos::leerTodosHistorialesActivos(&cantidadConsultas);
    
    // Filtrar por paciente espec�fico
    int contadorPaciente = 0;
    for (int i = 0; i < cantidadConsultas; i++) {
        // CAMBIADO: usar getter getIdPaciente()
        if (historialPaciente[i].getIdPaciente() == paciente.getId()) {
            contadorPaciente++;
        }
    }
    
    if (contadorPaciente == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
        textoColor(10, 5, "El paciente no tiene consultas en su historial", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        
        // Liberar memoria
        GestorArchivos::liberarArrayRegistros(historialPaciente);
        return;
    }

    system("cls");
    system("color 1F");
    
    int y = startY;
    
    // CABECERA DE LA TABLA
    textoColor(startX + 10, y++, ES_SU_IZ + replicar(LINEA_HO[0], 58) + ES_SU_DE, 14, 1);
    textoColor(startX + 10, y++, LINEA_VE + "              " + titulo + "               " + LINEA_VE, 14, 1);
    textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 12) + CRUZ_SUP + replicar(LINEA_HO[0], 15) + CRUZ_SUP + replicar(LINEA_HO[0], 15) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_DER, 14, 1);
    
    // ENCABEZADO DE COLUMNAS (CON DOCTOR)
    textoColor(startX + 12, y, "Fecha/Hora", 14, 1);
    textoColor(startX + 25, y, "Diagn�stico", 14, 1);
    textoColor(startX + 42, y, "Tratamiento", 14, 1);
    textoColor(startX + 59, y, "Doctor", 14, 1);

    // L�neas verticales del encabezado
    textoColor(startX + 10, y, LINEA_VE, 14, 1);
    textoColor(startX + 23, y, LINEA_VE, 14, 1);
    textoColor(startX + 40, y, LINEA_VE, 14, 1);
    textoColor(startX + 57, y, LINEA_VE, 14, 1);
    textoColor(startX + 69, y, LINEA_VE, 14, 1);
    y++;
    
    textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 12) + CRUZ_CEN + replicar(LINEA_HO[0], 15) + CRUZ_CEN + replicar(LINEA_HO[0], 15) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_DER, 14, 1);
    
    // LISTA DE CONSULTAS (del m�s reciente al m�s antiguo)
    int consultasMostradas = 0;
    for (int i = cantidadConsultas - 1; i >= 0; i--) {
        HistorialMedico consulta = historialPaciente[i];
        
        // Verificar si es del paciente actual
        // CAMBIADO: usar getter getIdPaciente()
        if (consulta.getIdPaciente() != paciente.getId()) {
            continue;
        }
        
        // Obtener doctor usando GestorArchivos
        Doctor doctor = GestorArchivos::buscarDoctorPorID(consulta.getIdDoctor());
        string nombreDoctor = "N/E"; // No encontrado
        // CAMBIADO: usar getters
        if (doctor.getId() != -1) {
            nombreDoctor = "Dr. " + string(doctor.getApellido());
            // Acortar nombre si es muy largo
            if (nombreDoctor.length() > 10) {
                nombreDoctor = nombreDoctor.substr(0, 8) + ".";
            }
        }
        
        // Fecha y hora juntas 
        // CAMBIADO: usar getters
        string fechaHora = string(consulta.getFecha()).substr(5, 5) + " " + string(consulta.getHora()); 
        
        // Acortar diagn�stico 
        // CAMBIADO: usar getter
        string diagnosticoAbreviado = consulta.getDiagnostico();
        if (diagnosticoAbreviado.length() > 13) {
            diagnosticoAbreviado = diagnosticoAbreviado.substr(0, 11) + "..";
        }
        
        // Acortar tratamiento (incluye medicina si cabe)
        // CAMBIADO: usar getters
        string tratamientoAbreviado = consulta.getTratamiento();
        string medicamentos = consulta.getMedicamentos();
        
        // Si hay medicamentos, agregarlos al tratamiento
        if (!medicamentos.empty() && medicamentos != "-") {
            if (tratamientoAbreviado.length() + medicamentos.length() + 3 <= 13) {
                tratamientoAbreviado = tratamientoAbreviado + " (" + medicamentos + ")";
            } else {
                // Acortar tratamiento solo
                if (tratamientoAbreviado.length() > 13) {
                    tratamientoAbreviado = tratamientoAbreviado.substr(0, 11) + "..";
                }
            }
        } else {
            // Solo tratamiento
            if (tratamientoAbreviado.length() > 13) {
                tratamientoAbreviado = tratamientoAbreviado.substr(0, 11) + "..";
            }
        }
        
        // Alternar colores
        int colorFila = (consultasMostradas % 2 == 0) ? 15 : 7;
        
        // L�nea lateral izquierda
        textoColor(startX + 10, y, LINEA_VE, 14, 1);
        
        // Fecha/Hora (juntas)
        textoColor(startX + 12, y, fechaHora, colorFila, 1);
        
        // Diagn�stico (corto)
        textoColor(startX + 25, y, diagnosticoAbreviado, colorFila, 1);
        
        // Tratamiento (con medicina si cabe)
        textoColor(startX + 42, y, tratamientoAbreviado, colorFila, 1);
        
        // Doctor (nombre)
        textoColor(startX + 59, y, nombreDoctor, colorFila, 1);
        
        // L�neas verticales
        textoColor(startX + 23, y, LINEA_VE, 14, 1);
        textoColor(startX + 40, y, LINEA_VE, 14, 1);
        textoColor(startX + 57, y, LINEA_VE, 14, 1);
        textoColor(startX + 69, y, LINEA_VE, 14, 1);
        
        y++;
        consultasMostradas++;
        
        // Paginaci�n (cada 20 consultas)
        if (y >= (startY + 20) && i > 0) {
            textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 12) + CRUZ_INF + replicar(LINEA_HO[0], 15) + CRUZ_INF + replicar(LINEA_HO[0], 15) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_DER, 14, 1);
            textoColor(startX + 15, y++, "Presione cualquier tecla para ver m�s...", 14, 1);
            _getch();
            
            // Nueva p�gina
            system("cls");
            system("color 1F");
            y = startY;
            textoColor(startX + 10, y++, ES_SU_IZ + replicar(LINEA_HO[0], 58) + ES_SU_DE, 14, 1);
            textoColor(startX + 10, y++, LINEA_VE + "              " + titulo + " (Cont.)          " + LINEA_VE, 14, 1);
            textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 12) + CRUZ_SUP + replicar(LINEA_HO[0], 15) + CRUZ_SUP + replicar(LINEA_HO[0], 15) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_DER, 14, 1);
            
            // Re-dibujar encabezado
            textoColor(startX + 12, y, "Fecha/Hora", 14, 1);
            textoColor(startX + 25, y, "Diagn�stico", 14, 1);
            textoColor(startX + 42, y, "Tratamiento", 14, 1);
            textoColor(startX + 59, y, "Doctor", 14, 1);
            
            textoColor(startX + 10, y, LINEA_VE, 14, 1);
            textoColor(startX + 23, y, LINEA_VE, 14, 1);
            textoColor(startX + 40, y, LINEA_VE, 14, 1);
            textoColor(startX + 57, y, LINEA_VE, 14, 1);
            textoColor(startX + 69, y, LINEA_VE, 14, 1);
            y++;
            
            textoColor(startX + 10, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 12) + CRUZ_CEN + replicar(LINEA_HO[0], 15) + CRUZ_CEN + replicar(LINEA_HO[0], 15) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_DER, 14, 1);
        }
    }
    
    // PIE DE TABLA
    textoColor(startX + 10, y++, ES_IN_IZ + replicar(LINEA_HO[0], 12) + CRUZ_INF + replicar(LINEA_HO[0], 15) + CRUZ_INF + replicar(LINEA_HO[0], 15) + CRUZ_INF + replicar(LINEA_HO[0], 14) + ES_IN_DE, 14, 1);
    textoColor(startX + 15, y++, "Total consultas: " + to_string(consultasMostradas), 14, 1);
    // CAMBIADO: usar getters
    textoColor(startX + 15, y++, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    textoColor(startX + 15, y++, "Presione cualquier tecla para continuar...", 14, 1);
    
    _getch();
    
    // Liberar memoria usando GestorArchivos
    GestorArchivos::liberarArrayRegistros(historialPaciente);
}

void listarCitasPendientes() {
    // Verificar si hay citas usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalCitas == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS PENDIENTES", 14, 1);
        textoColor(10, 5, "No hay citas registradas en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    // Obtener citas pendientes usando GestorArchivos
    // CAMBIADO: usar GestorArchivos
    int cantidadResultados = 0;
    Cita* citasPendientesArray = GestorArchivos::buscarCitasPorEstado("Agendada", &cantidadResultados);
    
    if (cantidadResultados == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "CITAS PENDIENTES", 14, 1);
        textoColor(10, 5, "�Excelente! No hay citas pendientes en el sistema.", 10, 1);
        textoColor(10, 6, "Todas las citas han sido atendidas o canceladas.", 10, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Crear array de punteros para compatibilidad
    Cita** citasPendientes = new Cita*[cantidadResultados];
    for (int i = 0; i < cantidadResultados; i++) {
        citasPendientes[i] = &citasPendientesArray[i];
    }
    
    // Mostrar resultados en tabla
    string titulo = "CITAS PENDIENTES (" + to_string(cantidadResultados) + ")";
    mostrarCitasEnTabla(citasPendientes, cantidadResultados, titulo);
    
    // Liberar memoria usando GestorArchivos
    // CAMBIADO: usar GestorArchivos para liberar memoria
    GestorArchivos::liberarArrayRegistros(citasPendientesArray);
    delete[] citasPendientes;
}

//---------------------------------------------
// MOSTRAR HISTORIAL M�DICO (INTERFAZ DE USUARIO) - VERSI�N GESTORARCHIVOS
//---------------------------------------------
void mostrarHistorialMedicoVisual() {
    // Verificar si hay pacientes usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalPacientes == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
    textoColor(10, 5, "Ingrese la c�dula del paciente: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula del paciente
    string cedula = leerCampo(42, 5, 19);
    
    if (cedula == "ESC") {
        return; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
        textoColor(10, 5, "Error: La c�dula no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar paciente por c�dula usando GestorArchivos
    Paciente paciente = GestorArchivos::buscarPacientePorCedula(cedula.c_str());
    
    // CAMBIADO: usar getter getId()
    if (paciente.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
        textoColor(10, 5, "Error: No se encontr� paciente con c�dula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // CAMBIADO: usar getters
    if (!paciente.getActivo() || paciente.getEliminado()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "HISTORIAL M�DICO", 14, 1);
        textoColor(10, 5, "Error: El paciente est� inactivo en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Mostrar historial m�dico
    // CAMBIADO: usar getters
    string titulo = "HISTORIAL - " + string(paciente.getNombre()) + " " + string(paciente.getApellido());
    mostrarHistorialMedicoEnTabla(paciente, titulo);
}

