#ifndef INTERFAZ_PACIENTES_HPP
#define INTERFAZ_PACIENTES_HPP

#include "Paciente.hpp"
#include "operacionesPacientes.hpp"
#include <ctime>




#endif

