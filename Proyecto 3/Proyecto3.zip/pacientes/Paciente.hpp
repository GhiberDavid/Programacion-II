#ifndef PACIENTE_HPP
#define PACIENTE_HPP

#include <cstring>
#include <ctime>

class Paciente {
private:
    // Atributos (PRIVADOS)
    int id;
    char nombre[50];
    char apellido[50];
    char cedula[20];
    int edad;
    char sexo;
    char tipoSangre[5];
    char telefono[15];
    char direccion[100];
    char email[50];
    
    // Historial m�dico
    int cantidadConsultas;
    int primerConsultaID;
    
    // Citas
    int cantidadCitas;
    int citasIDs[20];
    
    // Informaci�n adicional
    char alergias[500];
    char observaciones[500];
    bool activo;
    bool eliminado;
    
    // Metadata
    time_t fechaCreacion;
    time_t fechaModificacion;

public:
    // ============ CONSTRUCTORES ============
    Paciente(); // Constructor por defecto
    Paciente(int id, const char* nombre, const char* apellido, const char* cedula);
    ~Paciente(); // Destructor
    
    // ============ GETTERS ============
    int getId() const;
    const char* getNombre() const;
    const char* getApellido() const;
    const char* getCedula() const;
    int getEdad() const;
    char getSexo() const;
    const char* getTipoSangre() const;
    const char* getTelefono() const;
    const char* getDireccion() const;
    const char* getEmail() const;
    
    int getCantidadConsultas() const;
    int getPrimerConsultaID() const;
    int getCantidadCitas() const;
    const int* getCitasIDs() const;
    
    const char* getAlergias() const;
    const char* getObservaciones() const;
    bool getActivo() const;
    bool getEliminado() const;
    
    time_t getFechaCreacion() const;
    time_t getFechaModificacion() const;
    
    // ============ SETTERS ============
    void setId(int id);
    void setNombre(const char* nombre);
    void setApellido(const char* apellido);
    void setCedula(const char* cedula);
    void setEdad(int edad);
    void setSexo(char sexo);
    void setTipoSangre(const char* tipoSangre);
    void setTelefono(const char* telefono);
    void setDireccion(const char* direccion);
    void setEmail(const char* email);
    
    void setCantidadConsultas(int cantidad);
    void setPrimerConsultaID(int id);
    void setCantidadCitas(int cantidad);
    void setCitaID(int index, int id);
    
    void setAlergias(const char* alergias);
    void setObservaciones(const char* observaciones);
    void setActivo(bool activo);
    void setEliminado(bool eliminado);
    
    void setFechaCreacion(time_t fecha);
    void setFechaModificacion(time_t fecha);
    
    // ============ M�TODOS DE GESTI�N DE CITAS ============
    bool agregarCitaID(int idCita);
    bool eliminarCitaID(int idCita);
    bool tieneCitaID(int idCita) const;
    void limpiarCitas();
    
    
    // ============ M�TODO EST�TICO ============
    static size_t obtenerTamano();
};

#endif
