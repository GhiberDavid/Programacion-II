#include "interfazPacientes.hpp"
#include "Paciente.hpp"
#include "operacionesPacientes.hpp"
#include "../utilidades/Formatos.hpp"
#include <cstring>
#include <string>
#include <conio.h> 


using namespace std;  // O usar std::to_string 


void mostrarPacientesEnTabla(Paciente* pacientes, int cantidad, const string& titulo) {
   
   int startX = -5; int startY = 1;

    if (pacientes == nullptr || cantidad == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ERROR", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes para mostrar!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    
    int y = startY;
    
    // CABECERA DE LA TABLA CON T�TULO DIN�MICO
    textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
    textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + "                     " + LINEA_VE, 14, 1);
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 6) + CRUZ_SUP + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
    
    // ENCABEZADO DE COLUMNAS
    textoColor(startX + 16, y, "Id", 14, 1);
    textoColor(startX + 22, y, "Nombre Completo", 14, 1);
    textoColor(startX + 44, y, "Cedula", 14, 1);
    textoColor(startX + 57, y, "Edad", 14, 1);
    textoColor(startX + 64, y, "Consultas", 14, 1);

    // L�neas verticales del encabezado
    textoColor(startX + 14, y, LINEA_VE, 14, 1);
    textoColor(startX + 19, y, LINEA_VE, 14, 1);
    textoColor(startX + 41, y, LINEA_VE, 14, 1);
    textoColor(startX + 56, y, LINEA_VE, 14, 1);
    textoColor(startX + 63, y, LINEA_VE, 14, 1);
    textoColor(startX + 74, y, LINEA_VE, 14, 1);
    y++;
    
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 6) + CRUZ_CEN + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
    
    // LISTA DE PACIENTES
    for (int i = 0; i < cantidad; i++) {
        Paciente paciente = pacientes[i];  // Cambio: paciente por valor, no puntero
        
        // Solo mostrar pacientes activos y no eliminados - USAR GETTERS
        if (!paciente.getActivo() || paciente.getEliminado()) continue;
        
        // Alternar colores para mejor legibilidad
        int colorFila = (i % 2 == 0) ? 15 : 7;
        
        // L�nea lateral izquierda
        textoColor(startX + 14, y, LINEA_VE, 14, 1);
        
        // ID - USAR GETTER
        textoColor(startX + 16, y, to_string(paciente.getId()), colorFila, 1);
        
        // Nombre completo - USAR GETTERS
        string nombreCompleto = string(paciente.getNombre()) + " " + string(paciente.getApellido());
        if (nombreCompleto.length() > 19) {
            nombreCompleto = nombreCompleto.substr(0, 16) + "...";
        }
        textoColor(startX + 22, y, nombreCompleto, colorFila, 1);
        
        // Cedula - USAR GETTER
        textoColor(startX + 44, y, paciente.getCedula(), colorFila, 1);
        
        // Edad - USAR GETTER
        textoColor(startX + 59, y, to_string(paciente.getEdad()), colorFila, 1);
        
        // Consultas - USAR GETTER
        textoColor(startX + 67, y, to_string(paciente.getCantidadConsultas()), colorFila, 1);
        
        // L�neas verticales
        textoColor(startX + 19, y, LINEA_VE, 14, 1);
        textoColor(startX + 41, y, LINEA_VE, 14, 1);
        textoColor(startX + 56, y, LINEA_VE, 14, 1);
        textoColor(startX + 63, y, LINEA_VE, 14, 1);
        textoColor(startX + 74, y, LINEA_VE, 14, 1);
        
        y++;
        
        // Paginaci�n (cada 10 pacientes)
        if (y >= (startY + 15) && i < cantidad - 1) {
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 6) + CRUZ_INF + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
            textoColor(startX + 19, y++, "Presione cualquier tecla para ver mas...", 14, 1);
            _getch();
            
            // Nueva p�gina
            system("cls");
            system("color 1F");
            y = startY;
            textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
            textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + " (Cont.)             " + LINEA_VE, 14, 1);
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 6) + CRUZ_SUP + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
            
            // Re-dibujar encabezado
            textoColor(startX + 16, y, "Id", 14, 1);
            textoColor(startX + 22, y, "Nombre Completo", 14, 1);
            textoColor(startX + 44, y, "Cedula", 14, 1);
            textoColor(startX + 57, y, "Edad", 14, 1);
            textoColor(startX + 64, y, "Consultas", 14, 1);
            
            textoColor(startX + 14, y, LINEA_VE, 14, 1);
            textoColor(startX + 19, y, LINEA_VE, 14, 1);
            textoColor(startX + 41, y, LINEA_VE, 14, 1);
            textoColor(startX + 56, y, LINEA_VE, 14, 1);
            textoColor(startX + 63, y, LINEA_VE, 14, 1);
            textoColor(startX + 74, y, LINEA_VE, 14, 1);
            y++;
            
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 6) + CRUZ_CEN + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
        }
    }
    
    // PIE DE TABLA
    textoColor(startX + 14, y++, ES_IN_IZ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 6) + CRUZ_INF + replicar(LINEA_HO[0], 10) + ES_IN_DE, 14, 1);
    textoColor(startX + 15, y++, "Total encontrados: " + to_string(cantidad), 14, 1);
    textoColor(startX + 15, y++, "Presione cualquier tecla para continuar...", 14, 1);
    
    _getch();
}


//---------------------------------------------
// CAPTURAR DATOS DE PACIENTE Y CREARLO
//---------------------------------------------
void capturarDatosPacienteVisual(Paciente* pacienteExistente, bool soloLectura) {
    // Variables locales para capturar datos
    char nombre[50], apellido[50], cedula[20], tipoSangre[5];
    char alergias[500], telefono[15], direccion[100], email[50];
    int edad;
    char sexo;
    
    // Si estamos editando, cargar los datos existentes
    bool esEdicion = (pacienteExistente != nullptr);

    system("cls");
    system("color 1F");

    if (esEdicion) {
        // USAR GETTERS
        strcpy(nombre, pacienteExistente->getNombre());
        strcpy(apellido, pacienteExistente->getApellido());
        strcpy(cedula, pacienteExistente->getCedula());
        strcpy(tipoSangre, pacienteExistente->getTipoSangre());
        strcpy(alergias, pacienteExistente->getAlergias());
        strcpy(telefono, pacienteExistente->getTelefono());
        strcpy(direccion, pacienteExistente->getDireccion());
        strcpy(email, pacienteExistente->getEmail());
        edad = pacienteExistente->getEdad();
        sexo = pacienteExistente->getSexo();
        
        leerCampo(25, 5, 49, nombre ,true);        
        leerCampo(25, 6, 49, apellido ,true);        
        leerCampo(25, 7, 19, cedula ,true); 
        leerCampo(25, 8, 3, to_string(edad), true);
        leerCampo(25, 9, 1, string(1, sexo), true);
        leerCampo(25, 12, 4,  tipoSangre, true);
        leerCampo(25, 13, 50, alergias, true);
        leerCampo(25, 16, 14, telefono, true);
        leerCampo(25, 17, 50, direccion, true);
        leerCampo(25, 18, 49, email, true);        
        
    } else {
        // Inicializar vacios para nuevo paciente
        memset(nombre, 0, sizeof(nombre));
        memset(apellido, 0, sizeof(apellido));
        memset(cedula, 0, sizeof(cedula));
        memset(tipoSangre, 0, sizeof(tipoSangre));
        memset(alergias, 0, sizeof(alergias));
        memset(telefono, 0, sizeof(telefono));
        memset(direccion, 0, sizeof(direccion));
        memset(email, 0, sizeof(email));
        edad = 0;
        sexo = ' ';
    }
    
    system("color 1F");
    dibujarCuadro(2, 3, 75, 21);
    
    string titulo;
    if (soloLectura) {
        titulo = "INFORMACION DEL PACIENTE";
    } else {
        titulo = esEdicion ? "MODIFICAR DATOS DEL PACIENTE" : "REGISTRO DE NUEVO PACIENTE";
    }
    textoColor(25 - titulo.length()/2, 3, titulo, 14, 1);
    
    // FORMULARIO DE CAPTURA
    textoColor(10, 4, "Datos Personales:", 14, 1);
    textoColor(10, 5, "Nombre:", 15, 1);
    textoColor(10, 6, "Apellido:", 15, 1);
    textoColor(10, 7, "Cedula:", 15, 1);
    textoColor(10, 8, "Edad:", 15, 1);
    textoColor(10, 9, "Sexo (M/F):", 15, 1);
    
    textoColor(10, 11, "Datos Medicos:", 14, 1);
    textoColor(10, 12, "Tipo de Sangre:", 15, 1);
    textoColor(10, 13, "Alergias:", 15, 1);
    
    textoColor(10, 15, "Contacto:", 14, 1);
    textoColor(10, 16, "Telefono:", 15, 1);
    textoColor(10, 17, "Direccion:", 15, 1);
    textoColor(10, 18, "Email:", 15, 1);
    
    if (!soloLectura) {
        textoColor(10, 20, "Presione ESC en cualquier campo para cancelar", 14, 1);
    } else {
        textoColor(10, 20, "Presione cualquier tecla para continuar...", 14, 1);
    }
    
    // CAPTURAR DATOS
    string temp;
    
    // Nombre
    do {
        temp = leerCampo(25, 5, 49, esEdicion ? nombre : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(nombre, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: El nombre no puede estar vacio!");
    } while (true);
    
    // Apellido
    do {
        temp = leerCampo(25, 6, 49, esEdicion ? apellido : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(apellido, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: El apellido no puede estar vacio!");
    } while (true);
    
    // Cedula (solo validar duplicados si es nuevo paciente)
    do {
        temp = leerCampo(25, 7, 19, esEdicion ? cedula : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            if (!esEdicion) {
                // Solo verificar duplicados para nuevos pacientes
                Paciente existente = buscarPacientePorCedula(temp.c_str());
                if (existente.getId() != -1) { // CAMBIADO: usar getId()
                    mostrarError(10, 20, "Error: Ya existe un paciente con esta cedula!");
                    continue;
                }
            }
            strcpy(cedula, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: La cedula no puede estar vacia!");
    } while (true);
    
    // Edad
    do {
        string edadInicial = esEdicion ? to_string(edad) : "";
        temp = leerCampoNumerico(25, 8, 3, edadInicial, soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            edad = atoi(temp.c_str());
            if (edad >= 0 && edad <= 120) {
                break;
            }
        }
        mostrarError(10, 20, "Error: Edad debe estar entre 0 y 120 anos!");
    } while (true);
    
    // Sexo
    do {
        string sexoInicial = esEdicion ? string(1, sexo) : "";
        temp = leerCampo(25, 9, 1, sexoInicial, soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty() && (temp == "M" || temp == "m" || temp == "F" || temp == "f")) {
            sexo = toupper(temp[0]);
            break;
        }
        mostrarError(10, 20, "Error: Sexo debe ser M o F!");
    } while (true);
    
    // Tipo de Sangre
    do {
        temp = leerCampo(26, 12, 4, esEdicion ? tipoSangre : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(tipoSangre, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: El tipo de sangre no puede estar vacio!");
    } while (true);
    
    // Alergias
    temp = leerCampo(25, 13, 50, esEdicion ? alergias : "", soloLectura);
    if (temp == "ESC" && !soloLectura) return;
    if (!soloLectura) {
        strcpy(alergias, temp.c_str());
    }
    
    // Tel�fono
    do {
        temp = leerCampo(25, 16, 14, esEdicion ? telefono : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(telefono, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: El telefono no puede estar vacio!");
    } while (true);
    
    // Direcci�n
    do {
        temp = leerCampo(25, 17, 50, esEdicion ? direccion : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(direccion, temp.c_str());
            break;
        }
        mostrarError(10, 20, "Error: La direccion no puede estar vacia!");
    } while (true);

    // Email
    do {
        temp = leerCampo(25, 18, 49, esEdicion ? email : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            size_t posArroba = temp.find('@');
            if (posArroba != string::npos) {
                // Verificar que hay al menos un punto despu�s del @
                size_t posPunto = temp.find('.', posArroba);
                if (posPunto != string::npos && posPunto > posArroba + 1 && posPunto < temp.length() - 1) {
                    strcpy(email, temp.c_str());
                    break;
                } else {
                    mostrarError(10, 20, "Error: Email valido (ej: usuario@dominio.com)!");
                }
            } else {
                mostrarError(10, 20, "Error: Email debe contener @!");
            }
        } else {
            mostrarError(10, 20, "Error: El email no puede estar vacio!");
        }
    } while (true);
    
    // CREAR O ACTUALIZAR PACIENTE (solo si no es solo lectura)
    if (!soloLectura) {
        if (esEdicion) {
            // Actualizar paciente existente USANDO SETTERS
            pacienteExistente->setNombre(nombre);
            pacienteExistente->setApellido(apellido);
            pacienteExistente->setCedula(cedula);
            pacienteExistente->setEdad(edad);
            pacienteExistente->setSexo(sexo);
            pacienteExistente->setTipoSangre(tipoSangre);
            pacienteExistente->setAlergias(alergias);
            pacienteExistente->setTelefono(telefono);
            pacienteExistente->setDireccion(direccion);
            pacienteExistente->setEmail(email);
            pacienteExistente->setFechaModificacion(time(0));
            
            // Guardar en archivo
            if (actualizarPaciente(*pacienteExistente)) {
                mostrarMensajeExito(10, 20,"Datos actualizados exitosamente!");
            } else {
                mostrarError(10, 20, "Error al actualizar paciente en archivo!");
            }
        } else {
            // Crear nuevo paciente usando la funci�n que ya tenemos
            if (registrarPacienteCompleto(nombre, apellido, cedula, edad, sexo, tipoSangre, 
                                        alergias, telefono, direccion, email)) {
                mostrarMensajeExito(10, 20,"Paciente registrado exitosamente!");
            } else {
                mostrarError(10, 20, "Error al registrar paciente en archivo!");
            }
        }
    }
    
    if (soloLectura) {
        textoColor(10, 20, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
}

void buscarPacientePorCedulaVisual(bool soloLectura) {
    string titulo = soloLectura ? "BUSCAR PACIENTE POR CEDULA" : "MODIFICAR DATOS DE PACIENTE";
    
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, titulo, 14, 1);
    textoColor(10, 5, "Ingrese la cedula del paciente: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula
    string cedula = leerCampo(42, 5, 19);
    
    if (cedula == "ESC") {
        return; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, titulo, 14, 1);
        textoColor(10, 5, "Error: La cedula no puede estar vacia!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar paciente por c�dula 
    Paciente paciente = buscarPacientePorCedula(cedula.c_str());
    
    // CAMBIADO: usar getId() en lugar de .id
    if (paciente.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, titulo, 14, 1);
        textoColor(10, 5, "Error: No se encontro ningun paciente con cedula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // CAMBIADO: usar getActivo() en lugar de .activo
    if (!paciente.getActivo()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, titulo, 14, 1);
        textoColor(10, 5, "Error: El paciente esta inactivo en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Llamar a capturarDatosPacienteVisual con el modo correspondiente
    capturarDatosPacienteVisual(&paciente, soloLectura);
}

//---------------------------------------------
// BUSCAR Y MOSTRAR PACIENTES POR NOMBRE (INTERFAZ DE USUARIO)
//---------------------------------------------
void buscarPacientesPorNombreVisual() {
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "BUSCAR PACIENTES POR NOMBRE", 14, 1);
    textoColor(10, 5, "Ingrese el nombre o parte del nombre a buscar: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer nombre a buscar
    char nombreBuscado[100];
    string temp = leerCampo(57, 5, 18);
    
    if (temp == "ESC") {
        return; 
    }
    
    if (temp.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR PACIENTES POR NOMBRE", 14, 1);
        textoColor(10, 5, "Error: El nombre no puede estar vacio!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    strcpy(nombreBuscado, temp.c_str());
    
    // Buscar pacientes (USANDO LA NUEVA VERSI�N PARA ARCHIVOS)
    int cantidadResultados = 0;
    Paciente* resultados = buscarPacientesPorNombre(nombreBuscado, &cantidadResultados);
    
    if (resultados == nullptr || cantidadResultados == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR PACIENTES POR NOMBRE", 14, 1);
        textoColor(10, 5, "No se encontraron pacientes con: '" + string(nombreBuscado) + "'", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Mostrar resultados en tabla
    string titulo = "RESULTADOS PARA: '" + string(nombreBuscado) + "'";
    mostrarPacientesEnTabla(resultados, cantidadResultados, titulo);
    
    // Liberar memoria del array din�mico
    delete[] resultados;
}

void listarPacientesVisual() {
    int cantidadActivos = 0;
    
    // Leer todos los pacientes activos del archivo (pasando cantidadActivos por referencia)
    Paciente* todosPacientes = leerTodosPacientesActivos(&cantidadActivos);
    
    if (todosPacientes == nullptr || cantidadActivos == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "LISTA DE PACIENTES", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    mostrarPacientesEnTabla(todosPacientes, cantidadActivos, "LISTA DE PACIENTES");
    
    // Liberar memoria
    delete[] todosPacientes;
}


bool eliminarPacienteVisual() {
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 10);
    
    textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
    textoColor(10, 5, "Ingrese la cedula del paciente a eliminar: ", 15, 1);
    textoColor(10, 7, "ADVERTENCIA: Esta accion no se puede deshacer!", 12, 1);
    textoColor(10, 8, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula
    string cedula = leerCampo(52, 5, 19);
    
    if (cedula == "ESC") {
        return false; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");        
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
        textoColor(10, 5, "Error: La cedula no puede estar vacia!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // Buscar paciente por cedula (NUEVA VERSI�N para archivos)
    Paciente paciente = buscarPacientePorCedula(cedula.c_str());
    
    // CAMBIADO: usar getId() en lugar de .id
    if (paciente.getId() == -1) {
        system("cls");
        system("color 1F");        
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
        textoColor(10, 5, "Error: No se encontro ningun paciente con cedula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // Verificar si ya est� eliminado - CAMBIADO: usar getEliminado()
    if (paciente.getEliminado()) {
        system("cls");
        system("color 1F");        
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
        textoColor(10, 5, "Error: El paciente ya fue eliminado anteriormente!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // Mostrar confirmacion
    system("cls");
    system("color 1F");    
    dibujarCuadro(2, 3, 75, 12);
    textoColor(25, 3, "CONFIRMAR ELIMINACION", 14, 1);
    textoColor(10, 5, "�Esta seguro que desea eliminar al siguiente paciente?", 15, 1);
    // CAMBIADO: usar getId() en lugar de .id
    textoColor(10, 6, "ID: " + to_string(paciente.getId()), 15, 1);
    // CAMBIADO: usar getNombre() y getApellido()
    textoColor(10, 7, "Nombre: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    // CAMBIADO: usar getCedula()
    textoColor(10, 8, "Cedula: " + string(paciente.getCedula()), 15, 1);
    textoColor(10, 9, "NOTA: Esta accion es un borrado logico (se puede recuperar)", 14, 1);
    textoColor(10, 10, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    
    char confirmacion = toupper(_getch());
    
    if (confirmacion == 'S') {
        // Eliminar paciente usando la funci�n del Proyecto 2
        // CAMBIADO: pasar getId() en lugar de .id
        bool resultado = eliminarPaciente(paciente.getId());
        
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
        
        if (resultado) {
            textoColor(10, 5, "? Paciente eliminado exitosamente!", 10, 1);
            textoColor(10, 6, "El paciente fue marcado como eliminado (borrado logico)", 15, 1);
        } else {
            textoColor(10, 5, "? Error: No se pudo eliminar el paciente!", 12, 1);
        }
        
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return resultado;
    } else {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR PACIENTE", 14, 1);
        textoColor(10, 5, "? Eliminacion cancelada por el usuario", 10, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
    
    return false; 
}
