#ifndef INTERFAZ_PACIENTES_HPP
#define INTERFAZ_PACIENTES_HPP

#include "Paciente.hpp"
#include "operacionesPacientes.hpp"
#include <ctime>

void capturarDatosPacienteVisual(Paciente* pacienteExistente = nullptr, bool soloLectura = false);
void buscarPacientePorCedulaVisual(bool soloLectura);
void buscarPacientesPorNombreVisual();
void listarPacientesVisual();
bool eliminarPacienteVisual();


#endif

