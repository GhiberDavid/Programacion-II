#include "Paciente.hpp"
#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

// ============ CONSTRUCTORES ============

Paciente::Paciente() {
    // Inicializar valores por defecto
    id = -1;
    nombre[0] = '\0';
    apellido[0] = '\0';
    cedula[0] = '\0';
    edad = 0;
    sexo = 'M';
    tipoSangre[0] = '\0';
    telefono[0] = '\0';
    direccion[0] = '\0';
    email[0] = '\0';
    
    cantidadConsultas = 0;
    primerConsultaID = -1;
    cantidadCitas = 0;
    
    alergias[0] = '\0';
    observaciones[0] = '\0';
    activo = true;
    eliminado = false;
    
    fechaCreacion = time(nullptr);
    fechaModificacion = time(nullptr);
    
    // Inicializar array de citas
    for(int i = 0; i < 20; i++) {
        citasIDs[i] = -1;
    }
}

Paciente::Paciente(int id, const char* nombre, const char* apellido, const char* cedula) {
    // Llamar al constructor por defecto primero
    *this = Paciente();
    
    // Asignar valores principales
    this->id = id;
    setNombre(nombre);
    setApellido(apellido);
    setCedula(cedula);
}

Paciente::~Paciente() {
    // No hay memoria din�mica que liberar
}

// ============ GETTERS ============

int Paciente::getId() const {
    return id;
}

const char* Paciente::getNombre() const {
    return nombre;
}

const char* Paciente::getApellido() const {
    return apellido;
}

const char* Paciente::getCedula() const {
    return cedula;
}

int Paciente::getEdad() const {
    return edad;
}

char Paciente::getSexo() const {
    return sexo;
}

const char* Paciente::getTipoSangre() const {
    return tipoSangre;
}

const char* Paciente::getTelefono() const {
    return telefono;
}

const char* Paciente::getDireccion() const {
    return direccion;
}

const char* Paciente::getEmail() const {
    return email;
}

int Paciente::getCantidadConsultas() const {
    return cantidadConsultas;
}

int Paciente::getPrimerConsultaID() const {
    return primerConsultaID;
}

int Paciente::getCantidadCitas() const {
    return cantidadCitas;
}

const int* Paciente::getCitasIDs() const {
    return citasIDs;
}

const char* Paciente::getAlergias() const {
    return alergias;
}

const char* Paciente::getObservaciones() const {
    return observaciones;
}

bool Paciente::getActivo() const {
    return activo;
}

bool Paciente::getEliminado() const {
    return eliminado;
}

time_t Paciente::getFechaCreacion() const {
    return fechaCreacion;
}

time_t Paciente::getFechaModificacion() const {
    return fechaModificacion;
}

// ============ SETTERS ============

void Paciente::setId(int id) {
    this->id = id;
    fechaModificacion = time(nullptr);
}

void Paciente::setNombre(const char* nombre) {
    if (nombre) {
        strncpy(this->nombre, nombre, 49);
        this->nombre[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setApellido(const char* apellido) {
    if (apellido) {
        strncpy(this->apellido, apellido, 49);
        this->apellido[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setCedula(const char* cedula) {
    if (cedula) {
        strncpy(this->cedula, cedula, 19);
        this->cedula[19] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setEdad(int edad) {
    this->edad = edad;
    fechaModificacion = time(nullptr);
}

void Paciente::setSexo(char sexo) {
    this->sexo = sexo;
    fechaModificacion = time(nullptr);
}

void Paciente::setTipoSangre(const char* tipoSangre) {
    if (tipoSangre) {
        strncpy(this->tipoSangre, tipoSangre, 4);
        this->tipoSangre[4] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setTelefono(const char* telefono) {
    if (telefono) {
        strncpy(this->telefono, telefono, 14);
        this->telefono[14] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setDireccion(const char* direccion) {
    if (direccion) {
        strncpy(this->direccion, direccion, 99);
        this->direccion[99] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setEmail(const char* email) {
    if (email) {
        strncpy(this->email, email, 49);
        this->email[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setCantidadConsultas(int cantidad) {
    cantidadConsultas = cantidad;
    fechaModificacion = time(nullptr);
}

void Paciente::setPrimerConsultaID(int id) {
    primerConsultaID = id;
    fechaModificacion = time(nullptr);
}

void Paciente::setCantidadCitas(int cantidad) {
    cantidadCitas = cantidad;
    fechaModificacion = time(nullptr);
}

void Paciente::setCitaID(int index, int id) {
    if (index >= 0 && index < 20) {
        citasIDs[index] = id;
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setAlergias(const char* alergias) {
    if (alergias) {
        strncpy(this->alergias, alergias, 499);
        this->alergias[499] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setObservaciones(const char* observaciones) {
    if (observaciones) {
        strncpy(this->observaciones, observaciones, 499);
        this->observaciones[499] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Paciente::setActivo(bool activo) {
    this->activo = activo;
    fechaModificacion = time(nullptr);
}

void Paciente::setEliminado(bool eliminado) {
    this->eliminado = eliminado;
    fechaModificacion = time(nullptr);
}

void Paciente::setFechaCreacion(time_t fecha) {
    fechaCreacion = fecha;
}

void Paciente::setFechaModificacion(time_t fecha) {
    fechaModificacion = fecha;
}

// ============ M�TODOS DE GESTI�N DE CITAS ============

bool Paciente::agregarCitaID(int idCita) {
    if (cantidadCitas >= 20 || idCita <= 0) {
        return false;
    }
    
    // Verificar que no exista ya
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            return false; // Ya existe
        }
    }
    
    citasIDs[cantidadCitas] = idCita;
    cantidadCitas++;
    fechaModificacion = time(nullptr);
    
    return true;
}

bool Paciente::eliminarCitaID(int idCita) {
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            // Mover los elementos restantes
            for (int j = i; j < cantidadCitas - 1; j++) {
                citasIDs[j] = citasIDs[j + 1];
            }
            cantidadCitas--;
            citasIDs[cantidadCitas] = -1; // Limpiar �ltimo
            fechaModificacion = time(nullptr);
            return true;
        }
    }
    return false;
}

bool Paciente::tieneCitaID(int idCita) const {
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            return true;
        }
    }
    return false;
}

void Paciente::limpiarCitas() {
    for (int i = 0; i < 20; i++) {
        citasIDs[i] = -1;
    }
    cantidadCitas = 0;
    fechaModificacion = time(nullptr);
}


// ============ M�TODO EST�TICO ============

size_t Paciente::obtenerTamano() {
    return sizeof(Paciente);
}
