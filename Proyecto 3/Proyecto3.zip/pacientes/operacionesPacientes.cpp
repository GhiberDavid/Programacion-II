#include "operacionesPacientes.hpp"
#include "Paciente.hpp"
#include "../persistencia/GestorArchivos.hpp"
#include <cstring>


Paciente crearPaciente(const char* nombre, const char* apellido, 
                      const char* cedula, int edad, char sexo, const char* tipoSangre, 
                      const char* alergias, const char* telefono, const char* direccion, 
                      const char* email) {
    
    Paciente nuevoPaciente;
    
    // Configurar datos usando setters
    nuevoPaciente.setNombre(nombre);
    nuevoPaciente.setApellido(apellido);
    nuevoPaciente.setCedula(cedula);
    nuevoPaciente.setEdad(edad);
    nuevoPaciente.setSexo(sexo);
    nuevoPaciente.setTipoSangre(tipoSangre);
    nuevoPaciente.setAlergias(alergias);
    nuevoPaciente.setTelefono(telefono);
    nuevoPaciente.setDireccion(direccion);
    nuevoPaciente.setEmail(email);
    
    // Estado y relaciones
    nuevoPaciente.setActivo(true);
    nuevoPaciente.setEliminado(false);
    nuevoPaciente.setCantidadConsultas(0);
    nuevoPaciente.setPrimerConsultaID(-1);
    nuevoPaciente.setCantidadCitas(0);
    
    // Inicializar array de citas
    nuevoPaciente.limpiarCitas();
    
    // Los timestamps se configuran autom�ticamente en constructores/setters
    
    return nuevoPaciente;
}

bool registrarPacienteCompleto(const char* nombre, const char* apellido, 
                              const char* cedula, int edad, char sexo, const char* tipoSangre, 
                              const char* alergias, const char* telefono, const char* direccion, 
                              const char* email) {
    
    // Crear paciente en memoria
    Paciente nuevoPaciente = crearPaciente(nombre, apellido, cedula, edad, sexo,
                                          tipoSangre, alergias, telefono, direccion, email);
    
    // Guardar usando GestorArchivos
    return GestorArchivos::agregarPaciente(nuevoPaciente);
}

Paciente buscarPacientePorCedula(const char* cedula) {
  return GestorArchivos::buscarPacientePorCedula(cedula);
}

Paciente buscarPacientePorID(int id){
  return GestorArchivos::buscarPacientePorID(id);
}

bool actualizarPaciente(const Paciente& pacienteModificado) {
    return GestorArchivos::actualizarPaciente(pacienteModificado);
}

Paciente* buscarPacientesPorNombre(const char* nombreBuscado, int* cantidadResultados) {
    return GestorArchivos::buscarPacientesPorNombre(nombreBuscado, cantidadResultados);
}


Paciente* leerTodosPacientesActivos(int* cantidadActivos){
    return GestorArchivos::leerTodosPacientesActivos(cantidadActivos);
}

bool eliminarPaciente(int id){
    return GestorArchivos::eliminarPaciente(id);
}


