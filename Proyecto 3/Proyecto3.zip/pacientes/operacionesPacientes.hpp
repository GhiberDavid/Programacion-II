#ifndef OPERACIONES_PACIENTES_HPP
#define OPERACIONES_PACIENTES_HPP

#include "Paciente.hpp"
#include "../persistencia/GestorArchivos.hpp"
#include <ctime>

Paciente crearPaciente(const char* nombre, const char* apellido, 
                      const char* cedula, int edad, char sexo, const char* tipoSangre,
                      const char* alergias, const char* telefono, const char* direccion,
                      const char* email);
                      
bool registrarPacienteCompleto(const char* nombre, const char* apellido,
                              const char* cedula, int edad, char sexo, const char* tipoSangre,
                              const char* alergias, const char* telefono, const char* direccion,
                              const char* email);
                              
Paciente buscarPacientePorCedula(const char* cedula);


bool actualizarPaciente(const Paciente& pacienteModificado);  

Paciente* buscarPacientesPorNombre(const char* nombreBuscado, int* cantidadResultados);

Paciente* leerTodosPacientesActivos(int* cantidadActivos);  

bool eliminarPaciente(int id);

Paciente buscarPacientePorID(int id);

                    



#endif

