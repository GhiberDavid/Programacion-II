#ifndef OPERACIONES_DOCTORES_HPP
#define OPERACIONES_DOCTORES_HPP

#include "Doctor.hpp"
#include "../persistencia/GestorArchivos.hpp"
#include <ctime>

Doctor crearDoctor(const char* nombre, const char* apellido,
                  const char* cedula, const char* especialidad,
                  int aniosExperiencia, float costoConsulta,
                  const char* telefono = "0261-0000000",
                  const char* email = "doctor@hospital.com");
                  
bool registrarDoctorCompleto(const char* nombre, const char* apellido,
                           const char* cedula, const char* especialidad,
                           int aniosExperiencia, float costoConsulta,
                           const char* telefono, const char* email);
                           
bool asignarPacienteADoctor(int idPaciente, int idDoctor);   


Doctor buscarDoctorPorCedula(const char* cedula);

bool actualizarDoctor(const Doctor& doctorModificado);

Doctor* buscarDoctoresPorNombre(const char* nombreBuscado, int* cantidadResultados);


Doctor* leerTodosDoctoresActivos(int* cantidadActivos);

bool eliminarDoctor(int id);

Doctor buscarDoctorPorID(int id);

int buscarIndiceDoctorPorID(int id);

Doctor* buscarDoctoresPorEspecialidad(const char* especialidad, int* cantidadResultados);

bool asignarPacienteADoctorArchivos(int idPaciente, int idDoctor);

                    



#endif

