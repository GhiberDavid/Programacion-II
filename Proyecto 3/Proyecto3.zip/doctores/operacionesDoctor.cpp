#include "operacionesDoctor.hpp"
#include "Doctor.hpp"
#include "../persistencia/GestorArchivos.hpp"
#include <cstring>



using namespace std;

Doctor crearDoctor(const char* nombre, const char* apellido,
                  const char* cedula, const char* especialidad,
                  int aniosExperiencia, float costoConsulta,
                  const char* telefono, const char* email) {
    
    Doctor nuevoDoctor;
    
    // Configurar datos personales usando setters
    nuevoDoctor.setNombre(nombre);
    nuevoDoctor.setApellido(apellido);
    nuevoDoctor.setCedula(cedula);
    nuevoDoctor.setEspecialidad(especialidad);
    nuevoDoctor.setAniosExperiencia(aniosExperiencia);
    nuevoDoctor.setCostoConsulta(costoConsulta);
    
    // Configurar contacto (si se proporcion�)
    if (telefono != nullptr && strlen(telefono) > 0) {
        nuevoDoctor.setTelefono(telefono);
    }
    
    if (email != nullptr && strlen(email) > 0) {
        nuevoDoctor.setEmail(email);
    }
    
    // Estado y relaciones
    nuevoDoctor.setActivo(true);
    nuevoDoctor.setEliminado(false);
    nuevoDoctor.setDisponible(true);
    nuevoDoctor.setCantidadPacientes(0);
    nuevoDoctor.setCantidadCitas(0);
    
    // Inicializar arrays de pacientes y citas
    nuevoDoctor.limpiarPacientes();
    nuevoDoctor.limpiarCitas();
    
    // Timestamps
    nuevoDoctor.setFechaCreacion(time(0));
    nuevoDoctor.setFechaModificacion(time(0));
    
    return nuevoDoctor;
}

bool registrarDoctorCompleto(const char* nombre, const char* apellido,
                           const char* cedula, const char* especialidad,
                           int aniosExperiencia, float costoConsulta,
                           const char* telefono, const char* email) {
    
    // Crear doctor en memoria
    Doctor nuevoDoctor = crearDoctor(nombre, apellido, cedula, especialidad,
                                    aniosExperiencia, costoConsulta,
                                    telefono, email);
    
    // Guardar usando GestorArchivos
    return GestorArchivos::agregarDoctor(nuevoDoctor);
}

Doctor buscarDoctorPorCedula(const char* cedula) {
  return GestorArchivos::buscarDoctorPorCedula(cedula);;
}

bool actualizarDoctor(const Doctor& doctorModificado) {
    return GestorArchivos::actualizarDoctor(doctorModificado);
}

Doctor* buscarDoctoresPorNombre(const char* nombreBuscado, int* cantidadResultados) {
    return GestorArchivos::buscarDoctoresPorNombre(nombreBuscado, cantidadResultados);
}


Doctor* leerTodosDoctoresActivos(int* cantidadActivos){
    return GestorArchivos::leerTodosDoctoresActivos(cantidadActivos);
}

bool eliminarDoctor(int id){
    return GestorArchivos::eliminarDoctor(id);
}

Doctor buscarDoctorPorID(int id) {
    return GestorArchivos::buscarDoctorPorID(id);
}

int buscarIndiceDoctorPorID(int id) {
    return GestorArchivos::buscarIndiceDoctorPorID(id);
}

Doctor* buscarDoctoresPorEspecialidad(const char* especialidad, int* cantidadResultados) {
    return GestorArchivos::buscarDoctoresPorEspecialidad(especialidad, cantidadResultados);
}

bool asignarPacienteADoctorArchivos(int idPaciente, int idDoctor) {
    // 1. Obtener paciente y doctor actualizados usando GestorArchivos
    Paciente paciente = GestorArchivos::buscarPacientePorID(idPaciente);
    Doctor doctor = GestorArchivos::buscarDoctorPorID(idDoctor);
    
    if (paciente.getId() == -1 || doctor.getId() == -1) {
        return false;
    }
    
    // 2. Verificar que ambos est�n activos usando getters
    if (!paciente.getActivo() || paciente.getEliminado() || 
        !doctor.getActivo() || doctor.getEliminado()) {
        return false;
    }
    
    // 3. Verificar si ya est�n asignados
    bool yaAsignado = false;
    const int* pacientesIDs = doctor.getPacientesIDs();
    for (int i = 0; i < doctor.getCantidadPacientes(); i++) {
        if (pacientesIDs[i] == idPaciente) {
            yaAsignado = true;
            break;
        }
    }
    
    if (yaAsignado) {
        return false; // Ya asignado
    }
    
    // 4. Verificar si hay espacio en el array del doctor
    if (doctor.getCantidadPacientes() >= 20) { // Tama�o fijo del array
        return false; // No hay espacio
    }
    
    // 5. Verificar si hay espacio en el array del paciente (para citas)
    if (paciente.getCantidadCitas() >= 20) { // Tama�o fijo del array
        return false; // No hay espacio
    }
    
    // 6. Asignar paciente al doctor - NECESITAS UN M�TODO EN DOCTOR
    // Opci�n A: Si Doctor tiene m�todo agregarPacienteID
    if (!doctor.agregarPacienteID(idPaciente)) {
        return false;
    }
    
    // Opci�n B: Si NO tiene m�todo, hacerlo manualmente
    // doctor.setCantidadPacientes(doctor.getCantidadPacientes() + 1);
    // doctor.setPacienteID(doctor.getCantidadPacientes() - 1, idPaciente);
    
    // 7. Actualizar timestamp
    doctor.setFechaModificacion(time(0));
    
    // 8. Guardar cambios en archivos usando GestorArchivos
    if (!GestorArchivos::actualizarDoctor(doctor)) {
        return false;
    }
    
    return true;
}

