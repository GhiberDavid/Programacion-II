#include "interfazDoctor.hpp"
#include "Doctor.hpp"
#include "operacionesDoctor.hpp"
#include "../pacientes/operacionesPacientes.hpp"
#include "../utilidades/Formatos.hpp"
#include <cstring>
#include <string>
#include <conio.h> 


using namespace std;  // O usar std::to_string 


void capturarDatosDoctorVisual(Doctor* doctorExistente, bool soloLectura) {
    // Variables locales para capturar datos
    char nombre[50], apellido[50], cedula[20], especialidad[50];
    char telefono[15], email[50];
    int aniosExperiencia;
    float costoConsulta;
    
    // Si estamos editando, cargar los datos existentes
    bool esEdicion = (doctorExistente != nullptr);

    system("cls");
    system("color 1F");

    if (esEdicion) {
        // USAR GETTERS
        strcpy(nombre, doctorExistente->getNombre());
        strcpy(apellido, doctorExistente->getApellido());
        strcpy(cedula, doctorExistente->getCedula());
        strcpy(especialidad, doctorExistente->getEspecialidad());
        strcpy(telefono, doctorExistente->getTelefono());
        strcpy(email, doctorExistente->getEmail());
        aniosExperiencia = doctorExistente->getAniosExperiencia();
        costoConsulta = doctorExistente->getCostoConsulta();
        
        leerCampo(25, 5, 49, nombre, true);        
        leerCampo(25, 6, 49, apellido, true);        
        leerCampo(25, 7, 19, cedula, true); 
        leerCampo(25, 10, 49, especialidad, true);
        leerCampo(28, 11, 2, to_string(aniosExperiencia), true);
        leerCampo(26, 12, 6, to_string(costoConsulta), true);
        leerCampo(25, 15, 14, telefono, true);
        leerCampo(25, 16, 49, email, true);        
        
    } else {
        // Inicializar vac�os para nuevo doctor
        memset(nombre, 0, sizeof(nombre));
        memset(apellido, 0, sizeof(apellido));
        memset(cedula, 0, sizeof(cedula));
        memset(especialidad, 0, sizeof(especialidad));
        memset(telefono, 0, sizeof(telefono));
        memset(email, 0, sizeof(email));
        aniosExperiencia = 0;
        costoConsulta = 0.0f;
    }
    
    system("color 1F");
    dibujarCuadro(2, 3, 75, 20);
    
    string titulo;
    if (soloLectura) {
        titulo = "INFORMACI�N DEL DOCTOR";
    } else {
        titulo = esEdicion ? "MODIFICAR DATOS DEL DOCTOR" : "REGISTRO DE NUEVO DOCTOR";
    }
    textoColor(25 - titulo.length()/2, 3, titulo, 14, 1);
    
    // FORMULARIO DE CAPTURA
    textoColor(10, 4, "Datos Personales:", 14, 1);
    textoColor(10, 5, "Nombre:", 15, 1);
    textoColor(10, 6, "Apellido:", 15, 1);
    textoColor(10, 7, "C�dula:", 15, 1);
    
    textoColor(10, 9, "Datos Profesionales:", 14, 1);
    textoColor(10, 10, "Especialidad:", 15, 1);
    textoColor(10, 11, "A�os Experiencia:", 15, 1);
    textoColor(10, 12, "Costo Consulta:", 15, 1);
    
    textoColor(10, 14, "Contacto:", 14, 1);
    textoColor(10, 15, "Tel�fono:", 15, 1);
    textoColor(10, 16, "Email:", 15, 1);
    
    if (!soloLectura) {
        textoColor(10, 18, "Presione ESC en cualquier campo para cancelar", 14, 1);
    } else {
        textoColor(10, 18, "Presione cualquier tecla para continuar...", 14, 1);
    }
    
    // CAPTURAR DATOS
    string temp;
    
    // Nombre
    do {
        temp = leerCampo(25, 5, 49, esEdicion ? nombre : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(nombre, temp.c_str());
            break;
        }
        mostrarError(10, 18, "Error: El nombre no puede estar vac�o!");
    } while (true);
    
    // Apellido
    do {
        temp = leerCampo(25, 6, 49, esEdicion ? apellido : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(apellido, temp.c_str());
            break;
        }
        mostrarError(10, 18, "Error: El apellido no puede estar vac�o!");
    } while (true);
    
    // C�dula (solo validar duplicados si es nuevo doctor)
    do {
        temp = leerCampo(25, 7, 19, esEdicion ? cedula : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            if (!esEdicion) {
                // Solo verificar duplicados para nuevos doctores
                Doctor existente = buscarDoctorPorCedula(temp.c_str());
                // CAMBIADO: usar getId() en lugar de .id
                if (existente.getId() != -1) {
                    mostrarError(10, 18, "Error: Ya existe un doctor con esta c�dula!");
                    continue;
                }
            }
            strcpy(cedula, temp.c_str());
            break;
        }
        mostrarError(10, 18, "Error: La c�dula no puede estar vac�a!");
    } while (true);
    
    // Especialidad
    do {
        temp = leerCampo(25, 10, 49, esEdicion ? especialidad : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(especialidad, temp.c_str());
            break;
        }
        mostrarError(10, 18, "Error: La especialidad no puede estar vac�a!");
    } while (true);
    
    // A�os de Experiencia
    do {
        string expInicial = esEdicion ? to_string(aniosExperiencia) : "";
        temp = leerCampoNumerico(28, 11, 2, expInicial, soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            aniosExperiencia = atoi(temp.c_str());
            if (aniosExperiencia >= 0 && aniosExperiencia <= 50) {
                break;
            }
        }
        mostrarError(10, 18, "Error: A�os debe estar entre 0 y 50!");
    } while (true);
    
    // Costo Consulta
    do {
        string costoInicial = esEdicion ? to_string(costoConsulta) : "";
        temp = leerCampo(26, 12, 6, costoInicial, soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            costoConsulta = atof(temp.c_str());
            if (costoConsulta > 0) {
                break;
            }
        }
        mostrarError(10, 18, "Error: El costo debe ser mayor a 0!");
    } while (true);
    
    // Tel�fono
    do {
        temp = leerCampo(25, 15, 14, esEdicion ? telefono : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            strcpy(telefono, temp.c_str());
            break;
        }
        mostrarError(10, 18, "Error: El tel�fono no puede estar vac�o!");
    } while (true);
    
    // Email
    do {
        temp = leerCampo(25, 16, 49, esEdicion ? email : "", soloLectura);
        if (temp == "ESC" && !soloLectura) return;
        if (soloLectura) break;
        
        if (!temp.empty()) {
            size_t posArroba = temp.find('@');
            if (posArroba != string::npos) {
                // Verificar que hay al menos un punto despu�s del @
                size_t posPunto = temp.find('.', posArroba);
                if (posPunto != string::npos && posPunto > posArroba + 1 && posPunto < temp.length() - 1) {
                    strcpy(email, temp.c_str());
                    break;
                } else {
                    mostrarError(10, 18, "Error: Email v�lido (ej: usuario@dominio.com)!");
                }
            } else {
                mostrarError(10, 18, "Error: Email debe contener @!");
            }
        } else {
            mostrarError(10, 18, "Error: El email no puede estar vac�o!");
        }
    } while (true);
    
    // CREAR O ACTUALIZAR DOCTOR (solo si no es solo lectura)
    if (!soloLectura) {
        if (esEdicion) {
            // Actualizar doctor existente USANDO SETTERS
            doctorExistente->setNombre(nombre);
            doctorExistente->setApellido(apellido);
            doctorExistente->setCedula(cedula);
            doctorExistente->setEspecialidad(especialidad);
            doctorExistente->setAniosExperiencia(aniosExperiencia);
            doctorExistente->setCostoConsulta(costoConsulta);
            doctorExistente->setTelefono(telefono);
            doctorExistente->setEmail(email);
            doctorExistente->setFechaModificacion(time(0));
            
            // Guardar en archivo
            if (actualizarDoctor(*doctorExistente)) {
                mostrarMensajeExito(10, 18, "Datos actualizados exitosamente!");
            } else {
                mostrarError(10, 18, "Error al actualizar doctor en archivo!");
            }
        } else {
            // Crear nuevo doctor usando la funci�n que ya tenemos
            if (registrarDoctorCompleto(nombre, apellido, cedula, especialidad, 
                                      aniosExperiencia, costoConsulta, 
                                      telefono, email)) {
                mostrarMensajeExito(10, 18, "Doctor registrado exitosamente!");
            } else {
                mostrarError(10, 18, "Error al registrar doctor en archivo!");
            }
        }
    }
    
    if (soloLectura) {
        textoColor(10, 18, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
}

void buscarDoctorPorIdVisual() {
    // Verificar si hay doctores en el sistema usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
        textoColor(10, 5, "Error: No hay doctores registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
    textoColor(10, 5, "Ingrese el ID del doctor a buscar: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer ID
    string temp = leerCampoNumerico(45, 5, 5);
    
    if (temp == "ESC") {
        return; 
    }
    
    if (temp.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
        textoColor(10, 5, "Error: El ID no puede estar vacio!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    int idBuscado = atoi(temp.c_str());
    
    if (idBuscado <= 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
        textoColor(10, 5, "Error: El ID debe ser un numero positivo!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar doctor por ID usando operacionesDoctores
    Doctor doctor = buscarDoctorPorID(idBuscado);
    
    // CAMBIADO: usar getId() en lugar de .id
    if (doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
        textoColor(10, 5, "Error: No se encontro ningun doctor con ID: " + to_string(idBuscado), 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // CAMBIADO: usar getActivo() y getEliminado()
    if (!doctor.getActivo() || doctor.getEliminado()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTOR POR ID", 14, 1);
        textoColor(10, 5, "Error: El doctor est� inactivo o fue eliminado!", 12, 1);
        // CAMBIADO: usar getId(), getNombre(), getApellido()
        textoColor(10, 6, "ID: " + to_string(doctor.getId()) + " - " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Llamar a capturarDatosDoctorVisual en modo SOLO LECTURA
    capturarDatosDoctorVisual(&doctor, true); // true = solo lectura
}

void mostrarDoctoresEnTabla(Doctor* doctores, int cantidad, const string& titulo) {
 
    int startX = -6; 
    int startY = 0;

    if (doctores == nullptr || cantidad == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ERROR", 14, 1);
        textoColor(10, 5, "Error: No hay doctores para mostrar!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    
    int y = startY;
    
    // CABECERA DE LA TABLA CON T�TULO DIN�MICO
    textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
    textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + "                      " + LINEA_VE, 14, 1);
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 17) + CRUZ_DER, 14, 1);
    
    // ENCABEZADO DE COLUMNAS
    textoColor(startX + 16, y, "Id", 14, 1);
    textoColor(startX + 22, y, "Nombre Completo", 14, 1);
    textoColor(startX + 44, y, "C�dula", 14, 1);
    textoColor(startX + 57, y, "Especialidad", 14, 1);

    // L�neas verticales del encabezado
    textoColor(startX + 14, y, LINEA_VE, 14, 1);
    textoColor(startX + 19, y, LINEA_VE, 14, 1);
    textoColor(startX + 41, y, LINEA_VE, 14, 1);
    textoColor(startX + 56, y, LINEA_VE, 14, 1);
    textoColor(startX + 74, y, LINEA_VE, 14, 1);
    y++;
    
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 17) + CRUZ_DER, 14, 1);
    
    // LISTA DE DOCTORES
    for (int i = 0; i < cantidad; i++) {
        Doctor& doctor = doctores[i];  // Ahora usa referencia en lugar de puntero
        
        // Alternar colores para mejor legibilidad
        int colorFila = (i % 2 == 0) ? 15 : 7;
        
        // L�nea lateral izquierda
        textoColor(startX + 14, y, LINEA_VE, 14, 1);
        
        // ID - CAMBIADO: usar getId()
        textoColor(startX + 16, y, to_string(doctor.getId()), colorFila, 1);
        
        // Nombre completo - CAMBIADO: usar getNombre() y getApellido()
        string nombreCompleto = "Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido());
        if (nombreCompleto.length() > 19) {
            nombreCompleto = nombreCompleto.substr(0, 16) + "...";
        }
        textoColor(startX + 22, y, nombreCompleto, colorFila, 1);
        
        // C�dula - CAMBIADO: usar getCedula()
        textoColor(startX + 44, y, doctor.getCedula(), colorFila, 1);
        
        // Especialidad - CAMBIADO: usar getEspecialidad()
        string especialidad = doctor.getEspecialidad();
        if (especialidad.length() > 12) {
            especialidad = especialidad.substr(0, 9) + "...";
        }
        textoColor(startX + 57, y, especialidad, colorFila, 1);
        
        // L�neas verticales
        textoColor(startX + 19, y, LINEA_VE, 14, 1);
        textoColor(startX + 41, y, LINEA_VE, 14, 1);
        textoColor(startX + 56, y, LINEA_VE, 14, 1);
        textoColor(startX + 74, y, LINEA_VE, 14, 1);
        
        y++;
        
        // Paginaci�n (cada 10 doctores)
        if (y >= (startY + 15) && i < cantidad - 1) {
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 17) + CRUZ_DER, 14, 1);
            textoColor(startX + 19, y++, "Presione cualquier tecla para ver m�s...", 14, 1);
            _getch();
            
            // Nueva p�gina
            system("cls");
            system("color 1F");
            y = startY;
            textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
            textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + " (Cont.)              " + LINEA_VE, 14, 1);
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 17) + CRUZ_DER, 14, 1);
            
            // Re-dibujar encabezado
            textoColor(startX + 16, y, "Id", 14, 1);
            textoColor(startX + 22, y, "Nombre Completo", 14, 1);
            textoColor(startX + 44, y, "C�dula", 14, 1);
            textoColor(startX + 57, y, "Especialidad", 14, 1);
            
            textoColor(startX + 14, y, LINEA_VE, 14, 1);
            textoColor(startX + 19, y, LINEA_VE, 14, 1);
            textoColor(startX + 41, y, LINEA_VE, 14, 1);
            textoColor(startX + 56, y, LINEA_VE, 14, 1);
            textoColor(startX + 74, y, LINEA_VE, 14, 1);
            y++;
            
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 17) + CRUZ_DER, 14, 1);
        }
    }
    
    // PIE DE TABLA
    textoColor(startX + 14, y++, ES_IN_IZ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 17) + ES_IN_DE, 14, 1);
    textoColor(startX + 15, y++, "Total encontrados: " + to_string(cantidad), 14, 1);
    textoColor(startX + 15, y++, "Presione cualquier tecla para continuar...", 14, 1);
    
    _getch();
}

void buscarDoctoresPorEspecialidadVisual() {
    // Verificar si hay doctores usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTORES POR ESPECIALIDAD", 14, 1);
        textoColor(10, 5, "Error: No hay doctores registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "BUSCAR DOCTORES POR ESPECIALIDAD", 14, 1);
    textoColor(10, 5, "Ingrese la especialidad a buscar: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer especialidad a buscar
    char especialidadBuscada[100];
    string temp = leerCampo(45, 5, 15);
    
    if (temp == "ESC") {
        return; 
    }
    
    if (temp.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTORES POR ESPECIALIDAD", 14, 1);
        textoColor(10, 5, "Error: La especialidad no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    strcpy(especialidadBuscada, temp.c_str());
    
    // Buscar doctores usando operacionesDoctores
    int cantidadResultados = 0;
    Doctor* resultados = buscarDoctoresPorEspecialidad(especialidadBuscada, &cantidadResultados);
    
    if (resultados == nullptr || cantidadResultados == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "BUSCAR DOCTORES POR ESPECIALIDAD", 14, 1);
        textoColor(10, 5, "No se encontraron doctores con especialidad: '" + string(especialidadBuscada) + "'", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Mostrar resultados en tabla usando la versi�n adaptada
    string titulo = "DOCTORES DE: " + string(especialidadBuscada);
    mostrarDoctoresEnTabla(resultados, cantidadResultados, titulo);
    
    // Liberar memoria (usar operacionesDoctores::liberarArrayDoctores si existe)
    delete[] resultados;
}




void asignarPacienteADoctorVisual() {
    // Verificar si hay pacientes y doctores usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalPacientes == 0 || totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ASIGNAR PACIENTE A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No hay pacientes o doctores registrados!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    
    textoColor(25, 3, "ASIGNAR PACIENTE A DOCTOR", 14, 1);
    textoColor(10, 5, "C�dula del Paciente: ", 15, 1);
    textoColor(10, 6, "C�dula del Doctor: ", 15, 1);
    textoColor(10, 8, "Nota: Un paciente puede tener m�ltiples doctores", 8, 1);
    textoColor(10, 9, "y un doctor puede tener m�ltiples pacientes.", 8, 1);
    textoColor(10, 11, "Presione ESC para cancelar", 14, 1);
    
    // Variables para captura
    char cedulaPaciente[20], cedulaDoctor[20];
    memset(cedulaPaciente, 0, sizeof(cedulaPaciente));
    memset(cedulaDoctor, 0, sizeof(cedulaDoctor));
    
    string temp;
    Paciente paciente;
    Doctor doctor;
    
    // C�dula del Paciente
    do {
        temp = leerCampo(32, 5, 19);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            paciente = GestorArchivos::buscarPacientePorCedula(temp.c_str());
            // CAMBIAR: Usar getters en lugar de acceso directo
            if (paciente.getId() != -1 && paciente.getActivo() && !paciente.getEliminado()) {
                strcpy(cedulaPaciente, temp.c_str());
                break;
            } else {
                mostrarError(10, 12, "Error: No se encontr� paciente activo con esa c�dula!");
            }
        } else {
            mostrarError(10, 12, "Error: La c�dula del paciente no puede estar vac�a!");
        }
    } while (true);
    
    // C�dula del Doctor
    do {
        temp = leerCampo(32, 6, 19);
        if (temp == "ESC") return;
        
        if (!temp.empty()) {
            doctor = GestorArchivos::buscarDoctorPorCedula(temp.c_str());
            // CAMBIAR: Usar getters en lugar de acceso directo
            if (doctor.getId() != -1 && doctor.getActivo() && !doctor.getEliminado()) {
                strcpy(cedulaDoctor, temp.c_str());
                break;
            } else {
                mostrarError(10, 12, "Error: No se encontr� doctor activo con esa c�dula!");
            }
        } else {
            mostrarError(10, 12, "Error: La c�dula del doctor no puede estar vac�a!");
        }
    } while (true);
    
    // Verificar si ya est�n asignados - CAMBIAR: Usar m�todo
    bool yaAsignado = doctor.tienePacienteID(paciente.getId());
    
    if (yaAsignado) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "ASIGNAR PACIENTE A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: El paciente ya est� asignado a este doctor!", 12, 1);
        // CAMBIAR: Usar getters
        textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
        textoColor(10, 7, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 8, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // MOSTRAR CONFIRMACI�N
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    textoColor(25, 3, "CONFIRMAR ASIGNACI�N", 14, 1);
    textoColor(10, 5, "�Confirmar asignaci�n del siguiente paciente al doctor?", 15, 1);
    // CAMBIAR: Usar getters
    textoColor(10, 6, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
    textoColor(10, 7, "C�dula: " + string(paciente.getCedula()), 15, 1);
    textoColor(10, 8, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
    textoColor(10, 9, "Especialidad: " + string(doctor.getEspecialidad()), 15, 1);
    textoColor(10, 10, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    
    char confirmacion = _getch();
    
    if (confirmacion == 'S' || confirmacion == 's') {
        // Usar la funci�n adaptada
        bool resultado = asignarPacienteADoctorArchivos(paciente.getId(), doctor.getId());
        
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "ASIGNAR PACIENTE A DOCTOR", 14, 1);
        
        if (resultado) {
            textoColor(10, 5, "�Asignaci�n exitosa!", 10, 1);
            textoColor(10, 6, "Paciente asignado correctamente al doctor.", 10, 1);
            // CAMBIAR: Usar getters
            textoColor(10, 7, "Paciente: " + string(paciente.getNombre()) + " " + string(paciente.getApellido()), 15, 1);
            textoColor(10, 8, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        } else {
            textoColor(10, 5, "Error: No se pudo realizar la asignaci�n!", 12, 1);
            textoColor(10, 6, "Posibles causas:", 12, 1);
            textoColor(10, 7, "- El doctor ya tiene el m�ximo de pacientes", 12, 1);
            textoColor(10, 8, "- Error al guardar en archivo", 12, 1);
        }
        
        textoColor(10, 9, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
}

void mostrarPacientesDeDoctorEnTabla(Doctor* doctor, const string& titulo) {
    
    int startX = -6; 
    int startY = 0;

    // CAMBIADO: usar getters
    if (doctor == nullptr || doctor->getCantidadPacientes() == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "PACIENTES ASIGNADOS", 14, 1);
        textoColor(10, 5, "El doctor no tiene pacientes asignados.", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    
    int y = startY;
    
    // CABECERA DE LA TABLA CON T�TULO DIN�MICO
    textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
    textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + "                       " + LINEA_VE, 14, 1);
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 6) + CRUZ_SUP + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
    
    // ENCABEZADO DE COLUMNAS
    textoColor(startX + 16, y, "Id", 14, 1);
    textoColor(startX + 22, y, "Nombre Completo", 14, 1);
    textoColor(startX + 44, y, "C�dula", 14, 1);
    textoColor(startX + 57, y, "Edad", 14, 1);
    textoColor(startX + 64, y, "Sexo", 14, 1);

    // L�neas verticales del encabezado
    textoColor(startX + 14, y, LINEA_VE, 14, 1);
    textoColor(startX + 19, y, LINEA_VE, 14, 1);
    textoColor(startX + 41, y, LINEA_VE, 14, 1);
    textoColor(startX + 56, y, LINEA_VE, 14, 1);
    textoColor(startX + 63, y, LINEA_VE, 14, 1);
    textoColor(startX + 74, y, LINEA_VE, 14, 1);
    y++;
    
    textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 6) + CRUZ_CEN + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
    
    // LISTA DE PACIENTES ASIGNADOS
    int pacientesMostrados = 0;
    // CAMBIADO: usar getters
    int cantidadPacientes = doctor->getCantidadPacientes();
    const int* pacientesIDs = doctor->getPacientesIDs();
    
    for (int i = 0; i < cantidadPacientes; i++) {
        int idPaciente = pacientesIDs[i];
        
        // Buscar paciente usando operacionesPacientes
        Paciente paciente = buscarPacientePorID(idPaciente);
        
        // Verificar si el paciente existe y est� activo - CAMBIADO: usar getters
        if (paciente.getId() == -1 || !paciente.getActivo() || paciente.getEliminado()) {
            continue; // Saltar pacientes no encontrados o inactivos
        }
        
        // Alternar colores para mejor legibilidad
        int colorFila = (pacientesMostrados % 2 == 0) ? 15 : 7;
        
        // L�nea lateral izquierda
        textoColor(startX + 14, y, LINEA_VE, 14, 1);
        
        // ID - CAMBIADO: usar getter
        textoColor(startX + 16, y, to_string(paciente.getId()), colorFila, 1);
        
        // Nombre completo - CAMBIADO: usar getters
        string nombreCompleto = string(paciente.getNombre()) + " " + string(paciente.getApellido());
        if (nombreCompleto.length() > 19) {
            nombreCompleto = nombreCompleto.substr(0, 16) + "...";
        }
        textoColor(startX + 22, y, nombreCompleto, colorFila, 1);
        
        // C�dula - CAMBIADO: usar getter
        textoColor(startX + 44, y, paciente.getCedula(), colorFila, 1);
        
        // Edad - CAMBIADO: usar getter
        textoColor(startX + 59, y, to_string(paciente.getEdad()), colorFila, 1);
        
        // Sexo - CAMBIADO: usar getter
        textoColor(startX + 67, y, string(1, paciente.getSexo()), colorFila, 1);
        
        // L�neas verticales
        textoColor(startX + 19, y, LINEA_VE, 14, 1);
        textoColor(startX + 41, y, LINEA_VE, 14, 1);
        textoColor(startX + 56, y, LINEA_VE, 14, 1);
        textoColor(startX + 63, y, LINEA_VE, 14, 1);
        textoColor(startX + 74, y, LINEA_VE, 14, 1);
        
        y++;
        pacientesMostrados++;
        
        // Paginaci�n (cada 10 pacientes)
        if (y >= (startY + 15) && i < cantidadPacientes - 1) {
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 6) + CRUZ_INF + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
            textoColor(startX + 19, y++, "Presione cualquier tecla para ver m�s...", 14, 1);
            _getch();
            
            // Nueva p�gina
            system("cls");
            system("color 1F");
            y = startY;
            textoColor(startX + 14, y++, ES_SU_IZ + replicar(LINEA_HO[0], 59) + ES_SU_DE, 14, 1);
            textoColor(startX + 14, y++, LINEA_VE + "                    " + titulo + " (Cont.)             " + LINEA_VE, 14, 1);
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_SUP + replicar(LINEA_HO[0], 21) + CRUZ_SUP + replicar(LINEA_HO[0], 14) + CRUZ_SUP + replicar(LINEA_HO[0], 6) + CRUZ_SUP + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
            
            // Re-dibujar encabezado
            textoColor(startX + 16, y, "Id", 14, 1);
            textoColor(startX + 22, y, "Nombre Completo", 14, 1);
            textoColor(startX + 44, y, "C�dula", 14, 1);
            textoColor(startX + 57, y, "Edad", 14, 1);
            textoColor(startX + 64, y, "Sexo", 14, 1);
            
            textoColor(startX + 14, y, LINEA_VE, 14, 1);
            textoColor(startX + 19, y, LINEA_VE, 14, 1);
            textoColor(startX + 41, y, LINEA_VE, 14, 1);
            textoColor(startX + 56, y, LINEA_VE, 14, 1);
            textoColor(startX + 63, y, LINEA_VE, 14, 1);
            textoColor(startX + 74, y, LINEA_VE, 14, 1);
            y++;
            
            textoColor(startX + 14, y++, CRUZ_IZQ + replicar(LINEA_HO[0], 4) + CRUZ_CEN + replicar(LINEA_HO[0], 21) + CRUZ_CEN + replicar(LINEA_HO[0], 14) + CRUZ_CEN + replicar(LINEA_HO[0], 6) + CRUZ_CEN + replicar(LINEA_HO[0], 10) + CRUZ_DER, 14, 1);
        }
    }
    
    // PIE DE TABLA
    textoColor(startX + 14, y++, ES_IN_IZ + replicar(LINEA_HO[0], 4) + CRUZ_INF + replicar(LINEA_HO[0], 21) + CRUZ_INF + replicar(LINEA_HO[0], 14) + CRUZ_INF + replicar(LINEA_HO[0], 6) + CRUZ_INF + replicar(LINEA_HO[0], 10) + ES_IN_DE, 14, 1);
    textoColor(startX + 15, y++, "Total pacientes asignados: " + to_string(pacientesMostrados), 14, 1);
    textoColor(startX + 15, y++, "Presione cualquier tecla para continuar...", 14, 1);
    
    _getch();
}

void listarPacientesDeDoctorVisual() {
    // Verificar si hay doctores usando GestorArchivos
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores, &totalCitas, &totalHistoriales);
    
    if (totalDoctores == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "PACIENTES ASIGNADOS A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No hay doctores registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }

    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 8);
    
    textoColor(25, 3, "PACIENTES ASIGNADOS A DOCTOR", 14, 1);
    textoColor(10, 5, "Ingrese la c�dula del doctor: ", 15, 1);
    textoColor(10, 7, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula del doctor
    string cedula = leerCampo(42, 5, 19);
    
    if (cedula == "ESC") {
        return; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "PACIENTES ASIGNADOS A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: La c�dula no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Buscar doctor por c�dula usando operacionesDoctores
    Doctor doctor = buscarDoctorPorCedula(cedula.c_str());
    
    // CAMBIADO: usar getId()
    if (doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "PACIENTES ASIGNADOS A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No se encontr� doctor con c�dula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // CAMBIADO: usar getActivo() y getEliminado()
    if (!doctor.getActivo() || doctor.getEliminado()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "PACIENTES ASIGNADOS A DOCTOR", 14, 1);
        textoColor(10, 5, "Error: El doctor est� inactivo o fue eliminado!", 12, 1);
        // CAMBIADO: usar getters
        textoColor(10, 6, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    string titulo = "PACIENTES DE DR: " + string(doctor.getNombre()) + " " + string(doctor.getApellido());
    mostrarPacientesDeDoctorEnTabla(&doctor, titulo);
}


void listarDoctoresVisual() {
    int cantidadActivos = 0;
    
    // CAMBIADO: Usar GestorArchivos para leer doctores activos
    Doctor* todosDoctores = GestorArchivos::leerTodosDoctoresActivos(&cantidadActivos);
    
    if (todosDoctores == nullptr || cantidadActivos == 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "LISTA DE DOCTORES", 14, 1);
        textoColor(10, 5, "Error: No hay doctores registrados en el sistema!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return;
    }
    
    // Usar la versi�n corregida que recibe Doctor*
    mostrarDoctoresEnTabla(todosDoctores, cantidadActivos, "LISTA DE DOCTORES");
    
    // Liberar memoria usando GestorArchivos
    GestorArchivos::liberarArrayRegistros(todosDoctores);
}

bool eliminarDoctorVisual() {
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 10);
    
    textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
    textoColor(10, 5, "Ingrese la c�dula del doctor a eliminar: ", 15, 1);
    textoColor(10, 7, "ADVERTENCIA: Esta acci�n es un borrado l�gico!", 12, 1);
    textoColor(10, 8, "Presione ESC para cancelar", 14, 1);
    
    // Leer c�dula
    string cedula = leerCampo(52, 5, 19);
    
    if (cedula == "ESC") {
        return false; 
    }
    
    if (cedula.empty()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        textoColor(10, 5, "Error: La c�dula no puede estar vac�a!", 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // CAMBIADO: Usar GestorArchivos para buscar doctor
    Doctor doctor = GestorArchivos::buscarDoctorPorCedula(cedula.c_str());
    
    // CAMBIADO: Usar getter getId() en lugar de .id
    if (doctor.getId() == -1) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No se encontr� ning�n doctor con c�dula: " + cedula, 12, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // CAMBIADO: Usar getter getEliminado() en lugar de .eliminado
    if (doctor.getEliminado()) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        textoColor(10, 5, "Error: El doctor ya fue eliminado anteriormente!", 12, 1);
        // CAMBIADO: Usar getters para nombre y apellido
        textoColor(10, 6, "Doctor: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // CAMBIADO: Usar getter getCantidadPacientes() en lugar de .cantidadPacientes
    if (doctor.getCantidadPacientes() > 0) {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 10);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        textoColor(10, 5, "Error: No se puede eliminar el doctor porque tiene pacientes asignados!", 12, 1);
        textoColor(10, 6, "Pacientes asignados: " + to_string(doctor.getCantidadPacientes()), 15, 1);
        textoColor(10, 7, "Debe reasignar los pacientes a otro doctor primero.", 15, 1);
        textoColor(10, 8, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return false;
    }
    
    // Verificar si el doctor tiene citas pendientes
    bool tieneCitasPendientes = false;
    
    // CAMBIADO: Para verificar citas, necesitar�amos un m�todo espec�fico
    // Por ahora, asumimos que el m�todo getCantidadCitas() existe
    if (doctor.getCantidadCitas() > 0) {
        tieneCitasPendientes = true;
    }
    
    // Mostrar confirmaci�n
    system("cls");
    system("color 1F");
    dibujarCuadro(2, 3, 75, 12);
    textoColor(25, 3, "CONFIRMAR ELIMINACI�N", 14, 1);
    textoColor(10, 5, "�Est� seguro que desea eliminar al siguiente doctor?", 15, 1);
    // CAMBIADO: Usar getters
    textoColor(10, 6, "ID: " + to_string(doctor.getId()), 15, 1);
    textoColor(10, 7, "Nombre: Dr. " + string(doctor.getNombre()) + " " + string(doctor.getApellido()), 15, 1);
    textoColor(10, 8, "C�dula: " + string(doctor.getCedula()), 15, 1);
    textoColor(10, 9, "Especialidad: " + string(doctor.getEspecialidad()), 15, 1);
    
    if (tieneCitasPendientes) {
        textoColor(10, 10, "ADVERTENCIA: El doctor tiene citas que ser�n canceladas!", 12, 1);
        textoColor(10, 11, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    } else {
        textoColor(10, 10, "El doctor no tiene citas pendientes.", 10, 1);
        textoColor(10, 11, "Presione S para confirmar, cualquier otra tecla para cancelar", 14, 1);
    }
    
    char confirmacion = _getch();
    
    if (confirmacion == 'S' || confirmacion == 's') {
        // CAMBIADO: Usar GestorArchivos para eliminar doctor
        bool resultado = GestorArchivos::eliminarDoctor(doctor.getId());
        
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        
        if (resultado) {
            textoColor(10, 5, "? Doctor eliminado exitosamente!", 10, 1);
            textoColor(10, 6, "El doctor fue marcado como eliminado (borrado l�gico)", 15, 1);
        } else {
            textoColor(10, 5, "? Error: No se pudo eliminar el doctor!", 12, 1);
        }
        
        textoColor(10, 7, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
        return resultado;
    } else {
        system("cls");
        system("color 1F");
        dibujarCuadro(2, 3, 75, 8);
        textoColor(25, 3, "ELIMINAR DOCTOR", 14, 1);
        textoColor(10, 5, "? Eliminaci�n cancelada por el usuario", 10, 1);
        textoColor(10, 6, "Presione cualquier tecla para continuar...", 14, 1);
        _getch();
    }
    
    return false; 
}
