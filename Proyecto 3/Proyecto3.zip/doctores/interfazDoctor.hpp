#ifndef INTERFAZ_DOCTOR_HPP
#define INTERFAZ_DOCTOR_HPP

#include "Doctor.hpp"
#include "operacionesDoctor.hpp"
#include <ctime>

void capturarDatosDoctorVisual(Doctor* doctorExistente = nullptr, bool soloLectura = false);
void buscarDoctorPorIdVisual();
void buscarDoctoresPorEspecialidadVisual();
void asignarPacienteADoctorVisual();
void listarPacientesDeDoctorVisual();
void listarDoctoresVisual();
bool eliminarDoctorVisual();
void obtenerCitasDePacienteVisual();

#endif

