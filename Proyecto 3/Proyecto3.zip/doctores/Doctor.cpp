#include "Doctor.hpp"
#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

// ============ CONSTRUCTORES ============

Doctor::Doctor() {
    // Inicializar valores por defecto
    id = -1;
    nombre[0] = '\0';
    apellido[0] = '\0';
    cedula[0] = '\0';
    especialidad[0] = '\0';
    aniosExperiencia = 0;
    costoConsulta = 0.0f;
    horarioAtencion[0] = '\0';
    telefono[0] = '\0';
    email[0] = '\0';
    
    cantidadPacientes = 0;
    cantidadCitas = 0;
    
    disponible = true;
    activo = true;
    eliminado = false;
    
    fechaCreacion = time(nullptr);
    fechaModificacion = time(nullptr);
    
    // Inicializar arrays
    for(int i = 0; i < 50; i++) {
        pacientesIDs[i] = -1;
    }
    for(int i = 0; i < 30; i++) {
        citasIDs[i] = -1;
    }
}

Doctor::Doctor(int id, const char* nombre, const char* apellido, const char* cedula, const char* especialidad) {
    // Llamar al constructor por defecto primero
    *this = Doctor();
    
    // Asignar valores principales
    this->id = id;
    setNombre(nombre);
    setApellido(apellido);
    setCedula(cedula);
    setEspecialidad(especialidad);
}

Doctor::~Doctor() {
    // No hay memoria din�mica que liberar
}

// ============ GETTERS ============

int Doctor::getId() const {
    return id;
}

const char* Doctor::getNombre() const {
    return nombre;
}

const char* Doctor::getApellido() const {
    return apellido;
}

const char* Doctor::getCedula() const {
    return cedula;
}

const char* Doctor::getEspecialidad() const {
    return especialidad;
}

int Doctor::getAniosExperiencia() const {
    return aniosExperiencia;
}

float Doctor::getCostoConsulta() const {
    return costoConsulta;
}

const char* Doctor::getHorarioAtencion() const {
    return horarioAtencion;
}

const char* Doctor::getTelefono() const {
    return telefono;
}

const char* Doctor::getEmail() const {
    return email;
}

int Doctor::getCantidadPacientes() const {
    return cantidadPacientes;
}

const int* Doctor::getPacientesIDs() const {
    return pacientesIDs;
}

int Doctor::getCantidadCitas() const {
    return cantidadCitas;
}

const int* Doctor::getCitasIDs() const {
    return citasIDs;
}

bool Doctor::getDisponible() const {
    return disponible;
}

bool Doctor::getActivo() const {
    return activo;
}

bool Doctor::getEliminado() const {
    return eliminado;
}

time_t Doctor::getFechaCreacion() const {
    return fechaCreacion;
}

time_t Doctor::getFechaModificacion() const {
    return fechaModificacion;
}

// ============ SETTERS ============

void Doctor::setId(int id) {
    this->id = id;
    fechaModificacion = time(nullptr);
}

void Doctor::setNombre(const char* nombre) {
    if (nombre) {
        strncpy(this->nombre, nombre, 49);
        this->nombre[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setApellido(const char* apellido) {
    if (apellido) {
        strncpy(this->apellido, apellido, 49);
        this->apellido[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setCedula(const char* cedula) {
    if (cedula) {
        strncpy(this->cedula, cedula, 19);
        this->cedula[19] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setEspecialidad(const char* especialidad) {
    if (especialidad) {
        strncpy(this->especialidad, especialidad, 49);
        this->especialidad[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setAniosExperiencia(int anios) {
    this->aniosExperiencia = anios;
    fechaModificacion = time(nullptr);
}

void Doctor::setCostoConsulta(float costo) {
    this->costoConsulta = costo;
    fechaModificacion = time(nullptr);
}

void Doctor::setHorarioAtencion(const char* horario) {
    if (horario) {
        strncpy(this->horarioAtencion, horario, 49);
        this->horarioAtencion[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setTelefono(const char* telefono) {
    if (telefono) {
        strncpy(this->telefono, telefono, 14);
        this->telefono[14] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setEmail(const char* email) {
    if (email) {
        strncpy(this->email, email, 49);
        this->email[49] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setCantidadPacientes(int cantidad) {
    cantidadPacientes = cantidad;
    fechaModificacion = time(nullptr);
}

void Doctor::setPacienteID(int index, int id) {
    if (index >= 0 && index < 50) {
        pacientesIDs[index] = id;
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setCantidadCitas(int cantidad) {
    cantidadCitas = cantidad;
    fechaModificacion = time(nullptr);
}

void Doctor::setCitaID(int index, int id) {
    if (index >= 0 && index < 30) {
        citasIDs[index] = id;
        fechaModificacion = time(nullptr);
    }
}

void Doctor::setDisponible(bool disponible) {
    this->disponible = disponible;
    fechaModificacion = time(nullptr);
}

void Doctor::setActivo(bool activo) {
    this->activo = activo;
    fechaModificacion = time(nullptr);
}

void Doctor::setEliminado(bool eliminado) {
    this->eliminado = eliminado;
    fechaModificacion = time(nullptr);
}

void Doctor::setFechaCreacion(time_t fecha) {
    fechaCreacion = fecha;
}

void Doctor::setFechaModificacion(time_t fecha) {
    fechaModificacion = fecha;
}

// ============ M�TODOS DE GESTI�N DE PACIENTES ============

bool Doctor::agregarPacienteID(int idPaciente) {
    if (cantidadPacientes >= 50 || idPaciente <= 0) {
        return false;
    }
    
    // Verificar que no exista ya
    for (int i = 0; i < cantidadPacientes; i++) {
        if (pacientesIDs[i] == idPaciente) {
            return false; // Ya existe
        }
    }
    
    pacientesIDs[cantidadPacientes] = idPaciente;
    cantidadPacientes++;
    fechaModificacion = time(nullptr);
    
    return true;
}

bool Doctor::eliminarPacienteID(int idPaciente) {
    for (int i = 0; i < cantidadPacientes; i++) {
        if (pacientesIDs[i] == idPaciente) {
            // Mover los elementos restantes
            for (int j = i; j < cantidadPacientes - 1; j++) {
                pacientesIDs[j] = pacientesIDs[j + 1];
            }
            cantidadPacientes--;
            pacientesIDs[cantidadPacientes] = -1; // Limpiar �ltimo
            fechaModificacion = time(nullptr);
            return true;
        }
    }
    return false;
}

bool Doctor::tienePacienteID(int idPaciente) const {
    for (int i = 0; i < cantidadPacientes; i++) {
        if (pacientesIDs[i] == idPaciente) {
            return true;
        }
    }
    return false;
}

void Doctor::limpiarPacientes() {
    for (int i = 0; i < 50; i++) {
        pacientesIDs[i] = -1;
    }
    cantidadPacientes = 0;
    fechaModificacion = time(nullptr);
}

// ============ M�TODOS DE GESTI�N DE CITAS ============

bool Doctor::agregarCitaID(int idCita) {
    if (cantidadCitas >= 30 || idCita <= 0) {
        return false;
    }
    
    // Verificar que no exista ya
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            return false; // Ya existe
        }
    }
    
    citasIDs[cantidadCitas] = idCita;
    cantidadCitas++;
    fechaModificacion = time(nullptr);
    
    return true;
}

bool Doctor::eliminarCitaID(int idCita) {
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            // Mover los elementos restantes
            for (int j = i; j < cantidadCitas - 1; j++) {
                citasIDs[j] = citasIDs[j + 1];
            }
            cantidadCitas--;
            citasIDs[cantidadCitas] = -1; // Limpiar �ltimo
            fechaModificacion = time(nullptr);
            return true;
        }
    }
    return false;
}

bool Doctor::tieneCitaID(int idCita) const {
    for (int i = 0; i < cantidadCitas; i++) {
        if (citasIDs[i] == idCita) {
            return true;
        }
    }
    return false;
}

void Doctor::limpiarCitas() {
    for (int i = 0; i < 30; i++) {
        citasIDs[i] = -1;
    }
    cantidadCitas = 0;
    fechaModificacion = time(nullptr);
}



// ============ M�TODO EST�TICO ============

size_t Doctor::obtenerTamano() {
    return sizeof(Doctor);
}
