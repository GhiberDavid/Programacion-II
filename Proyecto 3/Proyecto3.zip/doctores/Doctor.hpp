#ifndef DOCTOR_HPP
#define DOCTOR_HPP

#include <cstring>
#include <ctime>

class Doctor {
private:
    // Atributos (PRIVADOS)
    int id;
    char nombre[50];
    char apellido[50];
    char cedula[20];
    char especialidad[50];
    int aniosExperiencia;
    float costoConsulta;
    char horarioAtencion[50];
    char telefono[15];
    char email[50];
    
    // Relaciones
    int cantidadPacientes;
    int pacientesIDs[50];
    int cantidadCitas;
    int citasIDs[30];
    
    // Estado
    bool disponible;
    bool activo;
    bool eliminado;
    
    // Metadata
    time_t fechaCreacion;
    time_t fechaModificacion;

public:
    // ============ CONSTRUCTORES ============
    Doctor(); // Constructor por defecto
    Doctor(int id, const char* nombre, const char* apellido, const char* cedula, const char* especialidad);
    ~Doctor(); // Destructor
    
    // ============ GETTERS ============
    int getId() const;
    const char* getNombre() const;
    const char* getApellido() const;
    const char* getCedula() const;
    const char* getEspecialidad() const;
    int getAniosExperiencia() const;
    float getCostoConsulta() const;
    const char* getHorarioAtencion() const;
    const char* getTelefono() const;
    const char* getEmail() const;
    
    int getCantidadPacientes() const;
    const int* getPacientesIDs() const;
    int getCantidadCitas() const;
    const int* getCitasIDs() const;
    
    bool getDisponible() const;
    bool getActivo() const;
    bool getEliminado() const;
    
    time_t getFechaCreacion() const;
    time_t getFechaModificacion() const;
    
    // ============ SETTERS ============
    void setId(int id);
    void setNombre(const char* nombre);
    void setApellido(const char* apellido);
    void setCedula(const char* cedula);
    void setEspecialidad(const char* especialidad);
    void setAniosExperiencia(int anios);
    void setCostoConsulta(float costo);
    void setHorarioAtencion(const char* horario);
    void setTelefono(const char* telefono);
    void setEmail(const char* email);
    
    void setCantidadPacientes(int cantidad);
    void setPacienteID(int index, int id);
    void setCantidadCitas(int cantidad);
    void setCitaID(int index, int id);
    
    void setDisponible(bool disponible);
    void setActivo(bool activo);
    void setEliminado(bool eliminado);
    
    void setFechaCreacion(time_t fecha);
    void setFechaModificacion(time_t fecha);
    
    // ============ M�TODOS DE GESTI�N DE PACIENTES ============
    bool agregarPacienteID(int idPaciente);
    bool eliminarPacienteID(int idPaciente);
    bool tienePacienteID(int idPaciente) const;
    void limpiarPacientes();
    
    // ============ M�TODOS DE GESTI�N DE CITAS ============
    bool agregarCitaID(int idCita);
    bool eliminarCitaID(int idCita);
    bool tieneCitaID(int idCita) const;
    void limpiarCitas();
    
    
    // ============ M�TODO EST�TICO ============
    static size_t obtenerTamano();
};

#endif
