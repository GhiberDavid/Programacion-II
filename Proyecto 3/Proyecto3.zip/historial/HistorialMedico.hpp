#ifndef HISTORIAL_MEDICO_HPP
#define HISTORIAL_MEDICO_HPP

#include <cstring>
#include <ctime>

class HistorialMedico {
private:
    // Atributos (PRIVADOS)
    int id;
    char fecha[11];        // DD-MM-YYYY
    char hora[6];          // HH:MM
    char diagnostico[200];
    char tratamiento[200];
    char medicamentos[150];
    int idDoctor;
    float costo;
    
    // Metadata
    bool eliminado;
    time_t fechaCreacion;
    time_t fechaModificacion;
    int idConsulta;
    int idPaciente;

public:
    // ============ CONSTRUCTORES ============
    HistorialMedico(); // Constructor por defecto
    HistorialMedico(int id, int idPaciente, int idDoctor, const char* fecha, const char* hora);
    ~HistorialMedico(); // Destructor
    
    // ============ GETTERS ============
    int getId() const;
    const char* getFecha() const;
    const char* getHora() const;
    const char* getDiagnostico() const;
    const char* getTratamiento() const;
    const char* getMedicamentos() const;
    int getIdDoctor() const;
    float getCosto() const;
    
    bool getEliminado() const;
    time_t getFechaCreacion() const;
    time_t getFechaModificacion() const;
    int getIdConsulta() const;
    int getIdPaciente() const;
    
    // ============ SETTERS ============
    void setId(int id);
    void setFecha(const char* fecha);
    void setHora(const char* hora);
    void setDiagnostico(const char* diagnostico);
    void setTratamiento(const char* tratamiento);
    void setMedicamentos(const char* medicamentos);
    void setIdDoctor(int idDoctor);
    void setCosto(float costo);
    
    void setEliminado(bool eliminado);
    void setFechaCreacion(time_t fecha);
    void setFechaModificacion(time_t fecha);
    void setIdConsulta(int id);
    void setIdPaciente(int id);
    

    
    // ============ M�TODO EST�TICO ============
    static size_t obtenerTamano();
};

#endif
