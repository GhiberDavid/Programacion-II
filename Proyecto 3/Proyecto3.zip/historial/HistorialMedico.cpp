#include "HistorialMedico.hpp"
#include <iostream>
#include <cstring>
#include <ctime>

using namespace std;

// ============ CONSTRUCTORES ============

HistorialMedico::HistorialMedico() {
    // Inicializar valores por defecto
    id = -1;
    fecha[0] = '\0';
    hora[0] = '\0';
    diagnostico[0] = '\0';
    tratamiento[0] = '\0';
    medicamentos[0] = '\0';
    idDoctor = -1;
    costo = 0.0f;
    
    eliminado = false;
    fechaCreacion = time(nullptr);
    fechaModificacion = time(nullptr);
    idConsulta = -1;
    idPaciente = -1;
}

HistorialMedico::HistorialMedico(int id, int idPaciente, int idDoctor, const char* fecha, const char* hora) {
    // Llamar al constructor por defecto primero
    *this = HistorialMedico();
    
    // Asignar valores principales
    this->id = id;
    this->idPaciente = idPaciente;
    this->idDoctor = idDoctor;
    setFecha(fecha);
    setHora(hora);
}

HistorialMedico::~HistorialMedico() {
    // No hay memoria din�mica que liberar
}

// ============ GETTERS ============

int HistorialMedico::getId() const {
    return id;
}

const char* HistorialMedico::getFecha() const {
    return fecha;
}

const char* HistorialMedico::getHora() const {
    return hora;
}

const char* HistorialMedico::getDiagnostico() const {
    return diagnostico;
}

const char* HistorialMedico::getTratamiento() const {
    return tratamiento;
}

const char* HistorialMedico::getMedicamentos() const {
    return medicamentos;
}

int HistorialMedico::getIdDoctor() const {
    return idDoctor;
}

float HistorialMedico::getCosto() const {
    return costo;
}

bool HistorialMedico::getEliminado() const {
    return eliminado;
}

time_t HistorialMedico::getFechaCreacion() const {
    return fechaCreacion;
}

time_t HistorialMedico::getFechaModificacion() const {
    return fechaModificacion;
}

int HistorialMedico::getIdConsulta() const {
    return idConsulta;
}

int HistorialMedico::getIdPaciente() const {
    return idPaciente;
}

// ============ SETTERS ============

void HistorialMedico::setId(int id) {
    this->id = id;
    fechaModificacion = time(nullptr);
}

void HistorialMedico::setFecha(const char* fecha) {
    if (fecha) {
        strncpy(this->fecha, fecha, 10);
        this->fecha[10] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void HistorialMedico::setHora(const char* hora) {
    if (hora) {
        strncpy(this->hora, hora, 5);
        this->hora[5] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void HistorialMedico::setDiagnostico(const char* diagnostico) {
    if (diagnostico) {
        strncpy(this->diagnostico, diagnostico, 199);
        this->diagnostico[199] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void HistorialMedico::setTratamiento(const char* tratamiento) {
    if (tratamiento) {
        strncpy(this->tratamiento, tratamiento, 199);
        this->tratamiento[199] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void HistorialMedico::setMedicamentos(const char* medicamentos) {
    if (medicamentos) {
        strncpy(this->medicamentos, medicamentos, 149);
        this->medicamentos[149] = '\0';
        fechaModificacion = time(nullptr);
    }
}

void HistorialMedico::setIdDoctor(int idDoctor) {
    this->idDoctor = idDoctor;
    fechaModificacion = time(nullptr);
}

void HistorialMedico::setCosto(float costo) {
    this->costo = costo;
    fechaModificacion = time(nullptr);
}

void HistorialMedico::setEliminado(bool eliminado) {
    this->eliminado = eliminado;
    fechaModificacion = time(nullptr);
}

void HistorialMedico::setFechaCreacion(time_t fecha) {
    fechaCreacion = fecha;
}

void HistorialMedico::setFechaModificacion(time_t fecha) {
    fechaModificacion = fecha;
}

void HistorialMedico::setIdConsulta(int id) {
    idConsulta = id;
    fechaModificacion = time(nullptr);
}

void HistorialMedico::setIdPaciente(int id) {
    idPaciente = id;
    fechaModificacion = time(nullptr);
}


// ============ M�TODO EST�TICO ============

size_t HistorialMedico::obtenerTamano() {
    return sizeof(HistorialMedico);
}
