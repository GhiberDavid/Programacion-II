#include <iostream>
#include <cstdlib>
#include <conio.h>  
#include "hospital/Hospital.hpp"
#include "persistencia/GestorArchivos.hpp"

// Incluir funciones de operaciones
#include "pacientes/interfazPacientes.hpp"
#include "doctores/interfazDoctor.hpp"
#include "citas/operacionescitas.hpp"

// Incluir tus funciones de interfaz visual
#include "utilidades/Formatos.hpp"

using namespace std;


void menuPacientes(Hospital* hospital);
void menuDoctores(Hospital* hospital);
void menuCitas(Hospital* hospital);



// Tu funci�n de men� principal EXACTA
int mostrarMenuPrincipal(Hospital* hospital) {
    
    system("cls");
    system("color 1F"); // Fondo azul, texto blanco
    dibujarCuadro(5, 2, 70, 17);
    
    // T�tulo principal en amarillo
    textoColor(23, 1, "SISTEMA DE GESTION HOSPITALARIA v3", 14, 1);
    
    // Nombre del hospital en verde claro
    textoColor(28, 3, hospital->getNombre(), 10, 1);
    
    // Opciones del men� en blanco
    textoColor(20, 5, "1. Gestion de Pacientes", 15, 1);
    textoColor(20, 6, "2. Gestion de Doctores", 15, 1);
    textoColor(20, 7, "3. Gestion de Citas", 15, 1);
    textoColor(20, 8, "4. Generar Datos de Prueba", 15, 1);
    textoColor(20, 9, "ESC. Salir", 12, 1); // Salir en rojo

    // L�nea separadora en gris
    textoColor(10, 12, "================================================", 7, 1);
    
    // OBTENER ESTAD�STICAS ACTUALIZADAS USANDO TUS FUNCIONES
    int totalPacientes, totalDoctores, totalCitas, totalHistoriales;
    
    GestorArchivos::obtenerEstadisticasSistema(&totalPacientes, &totalDoctores,
                                              &totalCitas, &totalHistoriales);
    
    // OBTENER PR�XIMOS IDs USANDO TUS FUNCIONES
    int proxIDPaciente = GestorArchivos::obtenerProximoIDPaciente();
    int proxIDDoctor = GestorArchivos::obtenerProximoIDDoctor();
    int proxIDCita = GestorArchivos::obtenerProximoIDCita();
    int proxIDHistorial = GestorArchivos::obtenerProximoIDHistorial();
    
    // ESTADISTICAS con colores (MISMA POSICI�N QUE ANTES)
    textoColor(10, 13, "Estadisticas:", 14, 1); // T�tulo en amarillo
    
    textoColor(10, 14, "Pacientes registrados: ", 15, 1);
    textoColor(35, 14, to_string(totalPacientes), 10, 1); // N�mero en verde
    
    textoColor(10, 15, "Doctores registrados:  ", 15, 1);
    textoColor(35, 15, to_string(totalDoctores), 10, 1);
    
    textoColor(10, 16, "Citas agendadas:       ", 15, 1);
    textoColor(35, 16, to_string(totalCitas), 10, 1);
    
    // PR�XIMOS IDS con colores (MISMA POSICI�N QUE ANTES)
    textoColor(40, 13, "Proximos IDs:", 14, 1);
    
    textoColor(40, 14, "ID Paciente: ", 15, 1);
    textoColor(54, 14, to_string(proxIDPaciente), 11, 1); // Aguamarina
    
    textoColor(40, 15, "ID Doctor:   ", 15, 1);
    textoColor(54, 15, to_string(proxIDDoctor), 11, 1);
    
    textoColor(40, 16, "ID Cita:     ", 15, 1);
    textoColor(54, 16, to_string(proxIDCita), 11, 1);
    
    // Solicitar opci�n
    textoColor(20, 11, "Seleccione una opcion: ", 15, 1);
    
    string opcion = leerCampoNumerico(44, 11, 1);
    
    if (opcion == "ESC") {
        return 0;
    }
    
    return atoi(opcion.c_str());
}


int main() {
	
    // 1. Inicializar sistema de archivos
    if (!GestorArchivos::inicializarSistemaArchivos()) {
        cerr << "Error al inicializar archivos" << endl;
        return 1;
    }
    
    // 2. Cargar hospital (informaci�n b�sica)
    Hospital hospital;
    if (!GestorArchivos::cargarHospital(hospital)) {
        // Crear hospital por defecto si no existe
        hospital = Hospital("Hospital General URU", "Av. Principal #123", "555-1234");
        GestorArchivos::guardarHospital(hospital);
    }
    
    // 3. Loop principal
    int opcion;
    do {
        opcion = mostrarMenuPrincipal(&hospital); 
        
        if (opcion != 0) 
        switch(opcion) {
            case 1:
                menuPacientes(&hospital);
                break;
            case 2:
                menuDoctores(&hospital);
                break;
            case 3:
                menuCitas(&hospital);
                break;
            case 4:
                //generarDatosPrueba();                                           ;
                break;
            default:
                textoColor(20, 16, "Opcion invalida. Presione una tecla...", 12, 1);
                _getch();
        }
    } while (opcion != 0);
    
    
    // 4. Guardar hospital antes de salir
    if (GestorArchivos::guardarHospital(hospital)) {
        textoColor(20, 18, "Datos guardados. Hasta pronto!", 10, 1);
    } else {
        textoColor(20, 18, "Error al guardar datos", 12, 1);
    }
    
    _getch();
    return 0;
}

//---------------------------------------------
// MENU DE PACIENTES (igual al tuyo)
//---------------------------------------------
void menuPacientes(Hospital* hospital) {
    int opcion;
    do {
        system("cls");
        system("color 1F");
        dibujarCuadro(5, 2, 70, 18);
        
        textoColor(28, 3, "GESTION DE PACIENTES", 14, 1);
        
        // Opciones ID�NTICAS a las tuyas
        textoColor(20, 6, "1. Registrar nuevo paciente", 15, 1);
        textoColor(20, 7, "2. Buscar paciente por cedula", 15, 1);
        textoColor(20, 8, "3. Buscar paciente por nombre", 15, 1);
        textoColor(20, 9, "4. Ver historial medico completo", 15, 1);
        textoColor(20, 10, "5. Actualizar datos del paciente", 15, 1);
        textoColor(20, 11, "6. Listar todos los pacientes", 15, 1);
        textoColor(20, 12, "7. Eliminar paciente", 15, 1);
        textoColor(20, 13, "ESC. Volver al menu principal", 12, 1);
        
        textoColor(20, 16, "Seleccione una opcion: ", 15, 1);
        
        string opcionStr = leerCampoNumerico(44, 16, 1);
        opcion = atoi(opcionStr.c_str());
        
        if (opcionStr == "ESC") {
            return;
        }
        
        switch(opcion) {
            case 1:
                 capturarDatosPacienteVisual();
                break;
            case 2:
                 buscarPacientePorCedulaVisual(true);
                break;
            case 3:
                 buscarPacientesPorNombreVisual();
                break;
            case 4:
                 mostrarHistorialMedicoVisual();
                break;
            case 5:
                 buscarPacientePorCedulaVisual(false);
                break;
            case 6:
                 listarPacientesVisual();
                break;
            case 7:
                 eliminarPacienteVisual();
                break;
            default:
                textoColor(20, 17, "Opcion invalida. Presione una tecla...", 12, 1);
                _getch();
        }
    } while (opcion != 0);
}

//---------------------------------------------
// MENU DE DOCTORES (igual al tuyo)
//---------------------------------------------
void menuDoctores(Hospital* hospital) {
    int opcion;
    do {
        system("cls");
        system("color 1F");
        dibujarCuadro(5, 2, 70, 18);
        
        textoColor(28, 3, "GESTION DE DOCTORES", 14, 1);
        
        // Opciones ID�NTICAS
        textoColor(20, 6, "1. Registrar nuevo doctor", 15, 1);
        textoColor(20, 7, "2. Buscar doctor por ID", 15, 1);
        textoColor(20, 8, "3. Buscar doctores por especialidad", 15, 1);
        textoColor(20, 9, "4. Asignar paciente a doctor", 15, 1);
        textoColor(20, 10, "5. Ver pacientes asignados a doctor", 15, 1);
        textoColor(20, 11, "6. Listar todos los doctores", 15, 1);
        textoColor(20, 12, "7. Eliminar doctor", 15, 1);
        textoColor(20, 13, "ESC. Volver al menu principal", 12, 1);
        
        textoColor(20, 16, "Seleccione una opcion: ", 15, 1);
        
        string opcionStr = leerCampoNumerico(44, 16, 1);
        opcion = atoi(opcionStr.c_str());
        
        if (opcionStr == "ESC") {
            return;
        }
        
        switch(opcion) {
            case 1:
                 capturarDatosDoctorVisual();
                break;
            case 2:
                 buscarDoctorPorIdVisual();
                break;
            case 3:
                 buscarDoctoresPorEspecialidadVisual();
                break;
            case 4:
                 asignarPacienteADoctorVisual();
                break;
            case 5:
                 listarPacientesDeDoctorVisual();
                break;
            case 6:
                 listarDoctoresVisual();
                break;
            case 7:
                 eliminarDoctorVisual();
                break;
            default:
                textoColor(20, 17, "Opcion invalida. Presione una tecla...", 12, 1);
                _getch();
        }
    } while (opcion != 0);
}

//---------------------------------------------
// MENU DE CITAS (igual al tuyo)
//---------------------------------------------
void menuCitas(Hospital* hospital) {
    int opcion;
    do {
        system("cls");
        system("color 1F");
        dibujarCuadro(5, 2, 70, 18);
        
        textoColor(28, 3, "GESTION DE CITAS", 14, 1);
        
        // Opciones ID�NTICAS
        textoColor(20, 6, "1. Agendar nueva cita", 15, 1);
        textoColor(20, 7, "2. Cancelar cita", 15, 1);
        textoColor(20, 8, "3. Atender cita", 15, 1);
        textoColor(20, 9, "4. Ver citas de un paciente", 15, 1);
        textoColor(20, 10, "5. Ver citas de un doctor", 15, 1);
        textoColor(20, 11, "6. Ver citas de una fecha", 15, 1);
        textoColor(20, 12, "7. Ver citas pendientes", 15, 1);
        textoColor(20, 13, "ESC. Volver al menu principal", 12, 1);
        
        textoColor(20, 16, "Seleccione una opcion: ", 15, 1);
        
        string opcionStr = leerCampoNumerico(44, 16, 1);
        opcion = atoi(opcionStr.c_str());
        
        if (opcionStr == "ESC") {
            return;
        }
        
        switch(opcion) {
            case 1:
                 agendarCitaVisual();
                break;
            case 2:
                 cancelarCitaVisual();
                break;
            case 3:
                 atenderCitaVisual();
                break;
            case 4:
                 obtenerCitasDePacienteVisual();
                break;
            case 5:
                 obtenerCitasDeDoctorVisual();
                break;
            case 6:
                 obtenerCitasPorFechaVisual();
                break;
            case 7:
                 listarCitasPendientes();
                break;
            default:
                textoColor(20, 17, "Opcion invalida. Presione una tecla...", 12, 1);
                _getch();
        }
    } while (opcion != 0);
}
