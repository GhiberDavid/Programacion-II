#ifndef FORMATOS_HPP
#define FORMATOS_HPP

// ============ INCLUDES NECESARIOS ============
#include <cstring>    // Para funciones de strings estilo C
#include <cctype>     // Para tolower, toupper, isdigit, etc.
#include <string>     // Para std::string (necesario para las funciones que lo usan)
#include <windows.h>  // Para gotoxy (si est�s en Windows)

using namespace std;  // Necesario para usar 'string' sin std::

const string ES_SU_IZ = "\xDA";      // +
const string ES_SU_DE = "\xBF";      // +  
const string ES_IN_IZ = "\xC0";      // +
const string ES_IN_DE = "\xD9";      // +
const string LINEA_HO = "\xC4";      // -
const string LINEA_VE = "\xB3";      // �
const string CRUZ_SUP = "\xC2";      // -
const string CRUZ_INF = "\xC1";      // -
const string CRUZ_IZQ = "\xC3";      // �
const string CRUZ_DER = "\xB4";      // �
const string CRUZ_CEN = "\xC5";      // +

void stringToLower(char* dest, const char* src);
bool compararStrings(const char* str1, const char* str2);
bool contieneSubstringCaseInsensitive(const char* str, const char* substr);

std::string replicar(char caracter, int cantidad);  // Necesita <string>
bool validarFecha(const char* fecha);
bool validarHora(const char* hora);
void mostrarError(int x, int y, const char* mensaje); 
void mostrarMensajeExito(int x, int y, const char* mensaje);


void gotoxy(int x, int y);
void dibujarCuadro(int x1, int y1, int x2, int y2);
void textoColor(int x, int y, const std::string& texto, int textoColor = 15, int fondoColor = 1);
std::string leerCampo(int x, int y, int maxlen, const std::string& valorInicial = "", bool soloLectura = false);
std::string leerCampoNumerico(int x, int y, int maxlen, const std::string& valorInicial = "", bool soloLectura = false);


#endif
