#include "Formatos.hpp"

#include <iostream>
#include <fstream>
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <cstdlib> 
#include <ctime> 
 


using namespace std;




void stringToLower(char* dest, const char* src) {
    int i = 0;
    while (src[i] != '\0' && i < 499) { // l�mite por seguridad
        dest[i] = tolower(src[i]);
        i++;
    }
    dest[i] = '\0';
}


bool compararStrings(const char* str1, const char* str2) {
    if (str1 == nullptr || str2 == nullptr) {
        return false;
    }
    
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {
        if (tolower(str1[i]) != tolower(str2[i])) {
            return false;
        }
        i++;
    }
    
    // Ambos deben terminar al mismo tiempo
    return (str1[i] == '\0' && str2[i] == '\0');
}


bool contieneSubstringCaseInsensitive(const char* str, const char* substr) {
    if (str == nullptr || substr == nullptr) return false;
    
    char strLower[500];
    char substrLower[500];
    
    stringToLower(strLower, str);
    stringToLower(substrLower, substr);
    
    return strstr(strLower, substrLower) != nullptr;
}


void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void dibujarCuadro(int x1, int y1, int x2, int y2) {
    gotoxy(x1, y1); cout << char(201);
    gotoxy(x2, y1); cout << char(187);
    gotoxy(x1, y2); cout << char(200);
    gotoxy(x2, y2); cout << char(188);

    for (int i = x1 + 1; i < x2; i++) {
        gotoxy(i, y1); cout << char(205);
        gotoxy(i, y2); cout << char(205);
    }
    for (int i = y1 + 1; i < y2; i++) {
        gotoxy(x1, i); cout << char(186);
        gotoxy(x2, i); cout << char(186);
    }
}

string replicar(char caracter, int cantidad) {
    string resultado = "";
    for (int i = 0; i < cantidad; i++) {
        resultado += caracter;
    }
    return resultado;
}


void textoColor(int x, int y, const std::string& texto, int textoColor, int fondoColor) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, fondoColor * 16 + textoColor);
    gotoxy(x, y);
    cout << texto;
    SetConsoleTextAttribute(hConsole, 15); // Reset al color por defecto (blanco/azul)
}


string leerCampo(int x, int y, int maxlen, const std::string& valorInicial, bool soloLectura) {
    string texto = valorInicial;
    char c;
    
    // Limpiar Area con fondo azul y mostrar valor inicial
    textoColor(x, y, replicar(' ', maxlen), 15, 1);
    
    if (soloLectura) {
        // Modo solo lectura - mostrar en color diferente (gris)
        textoColor(x, y, texto, 8, 1);
    } else {
        // Modo editable - mostrar en color normal
        textoColor(x, y, texto, 15, 1);
    }
    
    gotoxy(x + texto.size(), y);
    
    // Si es solo lectura, salir inmediatamente
    if (soloLectura) {
        return texto;
    }
    
    while (true) {
        gotoxy(x + texto.size(), y);
        c = _getch();
        
        if (c == 13) break; // Enter
        if (c == 27) {      // ESC - siempre permitido
            texto = "ESC";
            break;
        }
        if (c == 8 && !texto.empty()) { // Backspace
            texto.pop_back();
            // Borrar carácter con fondo azul
            textoColor(x + texto.size(), y, " ", 15, 1);
        }
        else if (isprint((unsigned char)c) && texto.size() < maxlen) {
            texto.push_back(c);
            // Escribir carácter con color correcto
            textoColor(x + texto.size() - 1, y, string(1, c), 15, 1);
        }
    }
    return texto;
}

std::string leerCampoNumerico(int x, int y, int maxlen, const std::string& valorInicial, bool soloLectura) {
    string texto = valorInicial;
    char c;
    
    // Limpiar área antes de leer (fondo azul, texto blanco)
    textoColor(x, y, replicar(' ', maxlen), 15, 1);
    
    if (soloLectura) {
        // Modo solo lectura - mostrar en color diferente (gris)
        textoColor(x, y, texto, 8, 1);
    } else {
        // Modo editable - mostrar en color normal
        textoColor(x, y, texto, 15, 1);
    }
    
    gotoxy(x + texto.size(), y);
    
    // Si es solo lectura, salir inmediatamente
    if (soloLectura) {
        return texto;
    }
    
    while (true) {
        gotoxy(x + texto.size(), y);
        c = _getch();
        
        if (c == 13) { // Enter
            // No permitir Enter si el campo está vacío
            if (!texto.empty()) {
                break;
            }
            // Si está vacío, ignorar Enter y continuar
            continue;
        }
        if (c == 27) { // ESC - siempre permitido
            texto = "ESC";
            break;
        }
        if (c == 8 && !texto.empty()) { // Backspace
            texto.pop_back();
            // Borrar carácter con fondo azul
            textoColor(x + texto.size(), y, " ", 15, 1);
            gotoxy(x + texto.size(), y);
        }
        else if (isdigit((unsigned char)c) && texto.size() < maxlen) {
            texto.push_back(c);
            // Escribir dígito con color correcto
            textoColor(x + texto.size() - 1, y, string(1, c), 15, 1);
            
            // Si maxlen es 1 y ya tenemos un dígito, salir automáticamente
            if (maxlen == 1 && texto.size() == 1) {
                break;
            }
        }
    }
    return texto;
}


bool validarFecha(const char* fecha) {
    if (fecha == NULL || strlen(fecha) != 10)
        return false;

    // Verificar formato DD-MM-YYYY
    if (fecha[2] != '-' || fecha[5] != '-')
        return false;

    // Verificar que los demás caracteres sean dígitos
    for (int i = 0; i < 10; i++) {
        if (i != 2 && i != 5 && !isdigit((unsigned char)fecha[i]))
            return false;
    }

    // Extraer dia, mes y a�O
    char diaStr[3], mesStr[3], anioStr[5];
    strncpy(diaStr, fecha, 2);    diaStr[2] = '\0';
    strncpy(mesStr, fecha + 3, 2); mesStr[2] = '\0';
    strncpy(anioStr, fecha + 6, 4); anioStr[4] = '\0';

    int dia = atoi(diaStr);
    int mes = atoi(mesStr);
    int anio = atoi(anioStr);

    // Validar año (2020-2030)
    if (anio < 2020 || anio > 2030) return false;
    
    // Validar mes (1-12)
    if (mes < 1 || mes > 12) return false;
    
    // Validar día (mínimo 1)
    if (dia < 1) return false;

    // Días por mes
    int diasMes[] = {31,28,31,30,31,30,31,31,30,31,30,31};

    // Año bisiesto
    bool bisiesto = (anio % 4 == 0 && (anio % 100 != 0 || anio % 400 == 0));
    if (bisiesto && mes == 2) diasMes[1] = 29;

    // Validar día según el mes
    if (dia > diasMes[mes - 1]) return false;

    return true;
}

//---------------------------------------------
// VALIDAR FORMATO DE HORA (HH:MM)
//---------------------------------------------
bool validarHora(const char* hora) {
    if (hora == nullptr || strlen(hora) != 5) {
        return false;
    }
    
    // Verificar formato HH:MM
    if (hora[2] != ':') {
        return false;
    }
    
    // Verificar que sean d�gitos
    for (int i = 0; i < 5; i++) {
        if (i != 2 && !isdigit(hora[i])) {
            return false;
        }
    }
    
    int horas = atoi(hora);
    int minutos = atoi(hora + 3);
    
    if (horas < 0 || horas > 23) return false;
    if (minutos < 0 || minutos > 59) return false;
    
    return true;
}


void mostrarError(int x, int y, const char* mensaje) {

    // Limpiar Texto Anterior
    textoColor(x, y, replicar(' ', 60), 12, 1);

    // Mostrar mensaje de error
    textoColor(x, y, mensaje, 12, 1);
    _getch();
    
    // Mostrar instrucci�n para cancelar
    textoColor(x, y, "Presione ESC en cualquier campo para cancelar", 14, 1);
}

void mostrarMensajeExito(int x, int y, const char* mensaje) {
    // Limpiar Texto Anterior
    textoColor(x, y, replicar(' ', 60), 10, 1);

    // Mostrar mensaje de �xito (color verde)
    textoColor(x, y, mensaje, 10, 1);
    _getch();
    
    // Limpiar el mensaje despu�s de presionar una tecla
    textoColor(x, y, replicar(' ', 60), 10, 1);
}


